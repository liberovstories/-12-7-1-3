import { notFound } from "next/navigation";
import { db } from "@/db";
import { novels, chapters, chapterComments, chapterPurchases } from "@/db/schema";
import { eq, asc, desc, inArray } from "drizzle-orm";
import { ReaderView } from "@/components/ReaderView";
import { DEFAULT_USER_ID, getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

interface ChapterPageProps {
  params: Promise<{
    slug: string;
    chapterNumber: string;
  }>;
}

export default async function ChapterPage({ params }: ChapterPageProps) {
  const { slug, chapterNumber } = await params;
  const num = parseFloat(chapterNumber);

  const novelRecords = await db
    .select()
    .from(novels)
    .where(eq(novels.slug, slug))
    .limit(1);

  if (novelRecords.length === 0) {
    notFound();
  }

  const novel = novelRecords[0];

  const allChapters = await db
    .select()
    .from(chapters)
    .where(eq(chapters.novelId, novel.id))
    .orderBy(asc(chapters.chapterNumber));

  if (allChapters.length === 0) {
    notFound();
  }

  const currentChapter =
    allChapters.find((c) => c.chapterNumber === num) ?? allChapters[0];

  const chapterIds = allChapters.map((c) => c.id);

  const [purchases, settings, initialComments] = await Promise.all([
    db
      .select()
      .from(chapterPurchases)
      .where(
        chapterIds.length > 0
          ? inArray(chapterPurchases.chapterId, chapterIds)
          : eq(chapterPurchases.userId, DEFAULT_USER_ID)
      ),
    getOrCreateUserSettings(),
    db
      .select()
      .from(chapterComments)
      .where(eq(chapterComments.chapterId, currentChapter.id))
      .orderBy(desc(chapterComments.createdAt)),
  ]);

  const purchasedChapterIds = purchases
    .filter((purchase) => purchase.userId === DEFAULT_USER_ID)
    .map((purchase) => purchase.chapterId);

  return (
    <ReaderView
      novel={novel}
      chapter={currentChapter}
      allChapters={allChapters}
      purchasedChapterIds={purchasedChapterIds}
      initialComments={initialComments}
      initialBalance={settings.balance}
    />
  );
}
