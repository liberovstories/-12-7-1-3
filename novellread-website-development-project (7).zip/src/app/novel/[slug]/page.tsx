import { notFound } from "next/navigation";
import { db } from "@/db";
import { novels, chapters, reviews, bookmarks } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";
import { NovelDetailsView } from "@/components/NovelDetailsView";

export const dynamic = "force-dynamic";

interface NovelPageProps {
  params: Promise<{ slug: string }>;
}

export default async function NovelPage({ params }: NovelPageProps) {
  const { slug } = await params;

  const novelRecords = await db
    .select()
    .from(novels)
    .where(eq(novels.slug, slug))
    .limit(1);

  if (novelRecords.length === 0) {
    notFound();
  }

  const novel = novelRecords[0];

  const chaptersList = await db
    .select()
    .from(chapters)
    .where(eq(chapters.novelId, novel.id))
    .orderBy(asc(chapters.chapterNumber));

  const reviewsList = await db
    .select()
    .from(reviews)
    .where(eq(reviews.novelId, novel.id))
    .orderBy(desc(reviews.createdAt));

  const bookmarkRecord = await db
    .select()
    .from(bookmarks)
    .where(eq(bookmarks.novelId, novel.id))
    .limit(1);

  return (
    <NovelDetailsView
      novel={novel}
      chapters={chaptersList}
      reviews={reviewsList}
      initialBookmarkStatus={bookmarkRecord[0]?.status || null}
      initialLastReadChapter={bookmarkRecord[0]?.lastReadChapter || 1}
    />
  );
}
