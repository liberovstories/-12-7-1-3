import { CreatorRequestView } from "@/components/CreatorRequestView";

export default function SuggestTranslationPage() {
  return <CreatorRequestView kind="translation" />;
}
