import { CollectionsView } from "@/components/CollectionsView";

export default function CollectionsPage() {
  return <CollectionsView />;
}
