import { db } from "@/db";
import { bookmarks, novels } from "@/db/schema";
import { eq } from "drizzle-orm";
import { Bookmark, Novel } from "@/types";
import { ProfileView } from "@/components/ProfileView";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const userId = "default_user";

  const userBookmarks = await db
    .select({
      bookmark: bookmarks,
      novel: novels,
    })
    .from(bookmarks)
    .innerJoin(novels, eq(bookmarks.novelId, novels.id))
    .where(eq(bookmarks.userId, userId));

  const formatted: (Bookmark & { novel: Novel })[] = userBookmarks.map((item) => ({
    ...item.bookmark,
    status: item.bookmark.status as Bookmark["status"],
    lastReadChapter: item.bookmark.lastReadChapter ?? 1,
    novel: item.novel,
  }));

  const allNovels = await db.select().from(novels);
  const settings = await getOrCreateUserSettings();

  return (
    <ProfileView
      bookmarks={formatted}
      translatedNovels={allNovels.slice(0, 3)}
      profile={{
        displayName: settings.displayName,
        username: settings.username,
        bio: settings.bio,
        avatarUrl: settings.avatarUrl,
        bannerUrl: settings.bannerUrl,
        privateProfile: settings.privateProfile,
        balance: settings.balance,
      }}
    />
  );
}
