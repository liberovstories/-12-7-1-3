import { CreatorRequestView } from "@/components/CreatorRequestView";

export default function StartPublishingPage() {
  return <CreatorRequestView kind="publication" />;
}
