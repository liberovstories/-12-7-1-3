import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ThemeProvider } from "@/components/ThemeProvider";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const metadata: Metadata = {
  title: "NovellRead — Читать веб-новеллы, ранобэ и фанфики онлайн на русском",
  description:
    "Крупнейшая онлайн библиотека восточных веб-новелл, корейских новелл, китайских сянься, японских ранобэ и фанфиков с удобной читалкой и ежедневными обновлениями.",
  keywords: [
    "новеллы",
    "ранобэ",
    "веб новеллы",
    "читать онлайн",
    "корейские новеллы",
    "китайские новеллы",
    "сянься",
    "фанфики",
    "NovellRead",
    "ReManga каталог",
  ],
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const settings = await getOrCreateUserSettings();

  return (
    <html
      lang="ru"
      className={settings.themeMode === "dark" ? "dark" : ""}
      data-theme-mode={settings.themeMode}
      data-color-scheme={settings.colorScheme}
      suppressHydrationWarning
    >
      <body className="site-body min-h-screen flex flex-col antialiased selection:bg-emerald-500 selection:text-black">
        <ThemeProvider
          initialMode={settings.themeMode}
          initialScheme={settings.colorScheme}
        />
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
