import { db } from "@/db";
import { novels } from "@/db/schema";
import { getOrCreateUserSettings } from "@/lib/user-settings";
import { TopView } from "@/components/TopView";

export const dynamic = "force-dynamic";

export default async function TopPage() {
  const library = await db.select().from(novels);
  const settings = await getOrCreateUserSettings();

  const filtered = library.filter((novel) => {
    if (settings.contentType === "novels" && novel.type === "Фанфик") return false;
    if (settings.contentType === "fanfiction" && novel.type !== "Фанфик") return false;
    if (settings.adultContent === "hide" && novel.ageRating === "18+") return false;
    if (settings.adultContent === "only" && novel.ageRating !== "18+") return false;
    return true;
  });

  const ranked = [...filtered].sort((a, b) => {
    if (b.rating !== a.rating) return b.rating - a.rating;
    return b.bookmarksCount - a.bookmarksCount;
  });

  return <TopView novels={ranked} />;
}
