import { db } from "@/db";
import { bookmarks, novels } from "@/db/schema";
import { eq } from "drizzle-orm";
import { BookmarksView } from "@/components/BookmarksView";
import { Bookmark, Novel } from "@/types";

export const dynamic = "force-dynamic";

export default async function BookmarksPage() {
  const userId = "default_user";

  const userBookmarks = await db
    .select({
      bookmark: bookmarks,
      novel: novels,
    })
    .from(bookmarks)
    .innerJoin(novels, eq(bookmarks.novelId, novels.id))
    .where(eq(bookmarks.userId, userId));

  const formatted: (Bookmark & { novel: Novel })[] = userBookmarks.map((item) => ({
    ...item.bookmark,
    status: item.bookmark.status as Bookmark["status"],
    lastReadChapter: item.bookmark.lastReadChapter ?? 1,
    novel: item.novel,
  }));

  return <BookmarksView initialBookmarks={formatted} />;
}
