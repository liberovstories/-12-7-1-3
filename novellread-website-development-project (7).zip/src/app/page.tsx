import { db } from "@/db";
import { novels } from "@/db/schema";
import { seedDatabase, seedFreeOriginalNovels } from "@/db/seed";
import { sql } from "drizzle-orm";
import { HomeView } from "@/components/HomeView";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Ensure database has initial seeded novels
  const countCheck = await db.select({ count: sql<number>`count(*)` }).from(novels);
  if (Number(countCheck[0]?.count) === 0) {
    await seedDatabase();
  }
  await seedFreeOriginalNovels();

  const library = await db.select().from(novels);
  const settings = await getOrCreateUserSettings();
  const allNovels = library.filter((novel) => {
    if (settings.contentType === "novels" && novel.type === "Фанфик") return false;
    if (settings.contentType === "fanfiction" && novel.type !== "Фанфик") return false;
    if (settings.adultContent === "hide" && novel.ageRating === "18+") return false;
    if (settings.adultContent === "only" && novel.ageRating !== "18+") return false;
    return true;
  });

  return <HomeView novels={allNovels} />;
}
