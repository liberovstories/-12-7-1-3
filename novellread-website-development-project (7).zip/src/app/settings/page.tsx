import { SettingsView, type SettingsTab } from "@/components/SettingsView";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

const validTabs = new Set<SettingsTab>([
  "profile",
  "theme",
  "content",
  "notifications",
  "subscription",
  "security",
  "privacy",
]);

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string | string[] }>;
}) {
  const params = await searchParams;
  const requestedTab = Array.isArray(params.tab) ? params.tab[0] : params.tab;
  const initialTab =
    requestedTab && validTabs.has(requestedTab as SettingsTab)
      ? (requestedTab as SettingsTab)
      : "profile";
  const settings = await getOrCreateUserSettings();

  return (
    <SettingsView
      initialSettings={settings}
      initialTab={initialTab}
    />
  );
}
