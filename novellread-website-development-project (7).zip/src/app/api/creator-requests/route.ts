import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { creatorRequests } from "@/db/schema";
import { DEFAULT_USER_ID } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const kind = body.kind === "publication" ? "publication" : "translation";
    const title = typeof body.title === "string" ? body.title.trim().slice(0, 160) : "";
    const description =
      typeof body.description === "string"
        ? body.description.trim().slice(0, 2000)
        : "";
    const sourceUrl =
      typeof body.sourceUrl === "string"
        ? body.sourceUrl.trim().slice(0, 600)
        : null;
    const language =
      typeof body.language === "string"
        ? body.language.trim().slice(0, 80)
        : null;

    if (title.length < 2 || description.length < 10) {
      return NextResponse.json(
        { error: "Заполните название и подробное описание" },
        { status: 400 }
      );
    }

    const inserted = await db
      .insert(creatorRequests)
      .values({
        userId: DEFAULT_USER_ID,
        kind,
        title,
        sourceUrl,
        language,
        description,
      })
      .returning();

    return NextResponse.json({ request: inserted[0] }, { status: 201 });
  } catch (error) {
    console.error("API /api/creator-requests error:", error);
    return NextResponse.json(
      { error: "Не удалось отправить заявку" },
      { status: 500 }
    );
  }
}
