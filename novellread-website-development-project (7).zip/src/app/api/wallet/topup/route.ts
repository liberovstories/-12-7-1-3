import { NextRequest, NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { userSettings } from "@/db/schema";
import { DEFAULT_USER_ID, getOrCreateUserSettings } from "@/lib/user-settings";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const coinPackages = [
  { id: "p100", coins: 100, bonus: 0, priceRub: 100 },
  { id: "p220", coins: 220, bonus: 21, priceRub: 199 },
  { id: "p390", coins: 390, bonus: 41, priceRub: 349, hit: true },
  { id: "p560", coins: 560, bonus: 61, priceRub: 499 },
  { id: "p1150", coins: 1150, bonus: 151, priceRub: 999 },
  { id: "p2500", coins: 2500, bonus: 501, priceRub: 1999 },
] as const;

export async function GET() {
  return NextResponse.json({ packages: coinPackages });
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      packageId?: string;
      customAmountRub?: number;
    };

    let coins = 0;
    let priceRub = 0;

    if (body.packageId) {
      const selectedPackage = coinPackages.find(
        (item) => item.id === body.packageId
      );
      if (!selectedPackage) {
        return NextResponse.json(
          { error: "Неизвестный пакет монет" },
          { status: 400 }
        );
      }
      coins = selectedPackage.coins;
      priceRub = selectedPackage.priceRub;
    } else {
      const customAmount = Number(body.customAmountRub);
      if (!Number.isFinite(customAmount) || customAmount < 20) {
        return NextResponse.json(
          { error: "Минимальная сумма пополнения — 20 ₽" },
          { status: 400 }
        );
      }
      priceRub = Math.round(customAmount);
      coins = priceRub;
    }

    // Ensure the settings row exists before crediting the wallet.
    await getOrCreateUserSettings();

    const updated = await db
      .update(userSettings)
      .set({
        balance: sql`${userSettings.balance} + ${coins}`,
        updatedAt: new Date(),
      })
      .where(eq(userSettings.userId, DEFAULT_USER_ID))
      .returning();

    return NextResponse.json({
      settings: updated[0],
      credited: coins,
      priceRub,
    });
  } catch (error) {
    console.error("API /api/wallet/topup error:", error);
    return NextResponse.json(
      { error: "Не удалось выполнить пополнение" },
      { status: 500 }
    );
  }
}
