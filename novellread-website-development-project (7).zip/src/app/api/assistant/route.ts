import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { novels } from "@/db/schema";
import type { Novel } from "@/types";

export const dynamic = "force-dynamic";

/**
 * A conversational history turn sent from the client so the assistant can
 * resolve follow-up questions ("а подешевле?", "ещё что-нибудь", "не хочу
 * фэнтези") without the client re-sending full state every time.
 */
interface HistoryTurn {
  role: "user" | "assistant";
  text: string;
}

interface KeywordRule {
  patterns?: RegExp[];
  words?: string[];
  genres?: string[];
  tags?: string[];
  countries?: string[];
  types?: string[];
  label: string;
}

// A broad synonym/keyword dictionary. Each rule maps something a reader
// might naturally type to real catalog values (genre/tag/country/type), so
// the assistant can understand phrasing far beyond a fixed set of buttons.
const KEYWORD_RULES: KeywordRule[] = [
  { patterns: [/фэнтез/i, /fantasy/i, /волшебств/i, /магическ/i], genres: ["Фэнтези"], label: "фэнтези" },
  { patterns: [/культивац/i, /сянься/i, /даос/i, /бессмерти/i], genres: ["Сянься"], tags: ["Культивация", "Бессмертие"], label: "культивация" },
  { patterns: [/боев[ыи]х? искусств/i, /кунг.?фу/i, /уся/i, /воинских? искусств/i], genres: ["Боевые искусства", "Уся"], label: "боевые искусства" },
  { patterns: [/систем/i], tags: ["Система"], genres: ["ЛитРПГ"], label: "система" },
  { patterns: [/литрпг/i, /игров(ой|ая|ые)/i, /геймер/i], words: ["игра", "игры", "игру", "игре"], genres: ["ЛитРПГ", "Игра"], tags: ["Игровой элемент", "Прокачка"], label: "игровые элементы" },
  { patterns: [/попадан/i, /перерожд/i, /реинкарнац/i, /регресс/i, /переселил/i, /другой мир/i, /исекай/i], tags: ["Перерождение", "Реинкарнация", "Попаданец"], genres: ["Исекай"], label: "перерождение / попаданчество" },
  { patterns: [/непобедим/i, /имба/i, /оп[\s-]?гг/i, /сильн(ый|ейший) гг/i, /читер/i], tags: ["Непобедимый ГГ"], label: "непобедимый герой" },
  { patterns: [/умн(ый|ая) гг/i, /стратег/i, /хитр(ый|ая)/i, /расчётлив/i], tags: ["Умный ГГ"], label: "умный герой" },
  { patterns: [/антигеро/i, /злоде/i, /тёмн(ый|ая) сторон/i], tags: ["Антигерой"], label: "антигерой / злодей" },
  { patterns: [/подземель/i, /данж/i, /башн/i, /лабиринт/i], tags: ["Владыка подземелий"], genres: ["ЛитРПГ"], label: "подземелья / башни" },
  { patterns: [/академ/i, /школ/i, /универ/i, /студент/i], genres: ["Школа"], tags: ["Академия"], label: "академия / школа" },
  { patterns: [/романтик/i, /любов/i, /гарем/i, /свидан/i], genres: ["Романтика", "Гарем"], label: "романтика" },
  { patterns: [/комеди/i, /юмор/i, /смешн/i, /весел(ое|ье)/i, /посмеят/i], genres: ["Комедия", "Юмор"], label: "комедия" },
  { patterns: [/ужас/i, /хоррор/i, /страшн/i, /жутк/i, /пощекотат.{0,4}нерв/i], genres: ["Ужасы", "Хоррор"], label: "ужасы" },
  { patterns: [/детектив/i, /расследован/i, /загадк/i, /разгада/i], genres: ["Детектив", "Мистика"], label: "детектив" },
  { patterns: [/тайн/i, /мистик/i, /сверхъестествен/i], genres: ["Мистика", "Сверхъестественное"], label: "мистика" },
  { patterns: [/драм/i, /груст/i, /трагед/i, /поплакат/i, /слёз/i, /слез/i], genres: ["Драма", "Психология"], label: "драма" },
  { patterns: [/постапокалипс/i, /апокалипс/i, /выживан/i, /руин[аы]/i, /зомби/i], genres: ["Постапокалипсис"], tags: ["Выживание"], label: "постапокалипсис / выживание" },
  { patterns: [/приключен/i, /путешеств/i, /экспедиц/i], genres: ["Приключения"], label: "приключения" },
  { patterns: [/фантастик/i, /космос/i, /киберпанк/i, /галактик/i], genres: ["Научная фантастика", "Киберпанк"], label: "фантастика" },
  { patterns: [/дракон/i], tags: ["Драконы"], label: "драконы" },
  { patterns: [/божеств/i], words: ["бог", "боги", "богов", "богиня"], tags: ["Боги"], label: "боги" },
  { patterns: [/месть/i, /предательств/i, /отомстит/i], tags: ["Месть", "Предательство"], label: "месть / предательство" },
  { patterns: [/крафт/i, /ремесл/i, /кузнец/i, /алхим/i], tags: ["Крафтинг"], label: "крафтинг" },
  { patterns: [/дворянств/i, /аристократ/i, /герцог/i, /принц(есс)?/i, /королевств/i], tags: ["Дворянство"], label: "дворянство" },
  { patterns: [/экшен/i, /боевик/i, /драйв/i, /адреналин/i, /сражени/i, /битв/i], genres: ["Боевик"], label: "боевик" },
  { patterns: [/повседневн/i, /без напряга/i, /расслаб/i, /чилл/i, /перед сном/i, /лёгк(ое|ая) чтени/i], genres: ["Повседневность"], label: "лёгкое повседневное чтение" },
  { patterns: [/психолог/i, /философ/i, /подума/i], genres: ["Психология"], label: "психологическая история" },
  { patterns: [/корейск/i, /корея/i, /manhwa/i, /манхв/i], countries: ["Корея"], label: "корейские новеллы" },
  { patterns: [/китайск/i, /китай/i, /manhua/i, /маньхуа/i], countries: ["Китай"], label: "китайские новеллы" },
  { patterns: [/японск/i, /япони/i, /manga/i], countries: ["Япония"], label: "японские ранобэ" },
  { patterns: [/русскояз/i, /снг/i, /отечествен/i, /наши автор/i], countries: ["СНГ"], label: "русскоязычные новеллы" },
  { patterns: [/запад(ную|ная|ных)?\b/i, /западн(ую|ая|ых)?/i], countries: ["Запад"], label: "западные новеллы" },
  { patterns: [/фанфик/i], types: ["Фанфик"], label: "фанфики" },
  { patterns: [/ранобэ/i], types: ["Ранобэ"], label: "ранобэ" },
];

// Common ways a reader phrases *what they don't want*, so the assistant can
// subtract a category instead of only ever adding filters.
const NEGATION_PATTERN =
  /(не\s+хочу|не\s+люблю|без\s|кроме\s|надоел[оа]?\s|устал[а]?\s+от\s|терпеть не могу)/i;

const GREETING_WORDS = [
  "привет",
  "приветик",
  "здравствуй",
  "здравствуйте",
  "хай",
  "ку",
  "йо",
  "добрый",
  "доброе",
  "прив",
];

// "пока" alone is ambiguous in Russian ("goodbye" vs. "for now" as in "пока
// не знаю") and JS regex word boundaries (\b) do not work reliably with
// Cyrillic text, so a naive /^пока/i prefix match would also fire on
// unrelated words like "покажи" ("show me"). Farewell words are therefore
// only treated as such when the whole message is just that short word (or
// an unambiguous multi-word phrase), checked via exact tokens below.
const FAREWELL_WORDS = ["пока", "бб", "бай", "споки", "прощай"];
const FAREWELL_PHRASE_PATTERN = /^(до свидания|до встречи|увидимся)/i;
const THANKS_PATTERN = /(спасибо|благодар|спс|thx|thanks)/i;
const SELF_INTRO_PATTERN =
  /(кто ты|как тебя зовут|что ты умеешь|что умеешь|представься|расскажи о себе|ты кто|ты бот|ты живая|ты настоящая|ты человек)/i;
const HOW_ARE_YOU_PATTERN = /(как дела|как ты|как настроение|как сама)/i;
const SURPRISE_ME_PATTERN =
  /(удиви меня|на твой вкус|что посоветуешь|что-нибудь почитать|не знаю что почитать|выбери за меня|доверяю тебе выбор|что бы почитать)/i;
const MORE_PATTERN =
  /(ещё|другие варианты|покажи другое|давай ещё|другое что-нибудь|новую подборку|перезагрузи|другие книги)/i;
const RESET_PATTERN = /(сменим тему|другая тема|забудь|неважно|начнём заново|сначала)/i;

// "лучш" as a bare stem would also match the unrelated word "лучше"
// ("rather" / "instead"), so the superlative forms are spelled out
// explicitly instead of using a short stem.
const TOP_PATTERN =
  /(топ|лучш(ий|ая|ие|ую|его|их)|популярн|высок(ий|ая|ие) рейтинг|легендарн|культов)/i;
const NEW_PATTERN = /(нов(ый|ые|инк)|свеж|последн|недавн)/i;
const FREE_PATTERN = /(бесплатн)/i;
const ADULT_PATTERN = /(18\+|только взросл|для взрослых)/i;
const KIDS_PATTERN = /(детск|для всех|0\+|без взросл|семейн)/i;
const SHORT_PATTERN = /(коротк|на один вечер|немного глав|быстро прочита|небольш(ая|ое))/i;
const LONG_PATTERN = /(длинн|эпичн|надолго|много глав|масштабн)/i;
const HIDDEN_GEM_PATTERN = /(малоизвестн|андеграунд|немейнстримн|скрыт(ая|ый) жемчужин|редк(ая|ое))/i;

// A much larger FAQ / help knowledge base covering nearly every feature of
// the site, so the assistant can answer general questions, not only give
// recommendations from the quick-suggestion buttons.
const HELP_TOPICS: Array<{ patterns: RegExp[]; replies: string[] }> = [
  {
    patterns: [/закладк/i],
    replies: [
      "Закладки находятся в верхнем меню сайта. Там можно распределять новеллы по категориям «Читаю», «Буду читать», «Прочитано», «Брошено», «Отложено», «Не интересно» и «Любимое», а также быстро продолжать чтение с последней главы.",
    ],
  },
  {
    patterns: [/баланс/i, /монет/i, /пополн/i, /валют/i, /кошел[её]к/i],
    replies: [
      "Ваш баланс монет отображается в шапке сайта рядом с аватаром. Пополнить его можно через кнопку «Пополнить» в меню профиля — доступно несколько пакетов монет и вариант с произвольной суммой.",
    ],
  },
  {
    patterns: [/купить главу/i, /платн(ая|ую) глав/i, /покупк(а|у) глав/i],
    replies: [
      "Платные главы отмечены значком замка. Откройте такую главу — появится окно с ценой в монетах и кнопкой покупки. После оплаты глава останется открытой для вас навсегда.",
    ],
  },
  {
    patterns: [/коммент/i],
    replies: [
      "Комментарии к главе открываются через первую из четырёх плавающих кнопок справа во время чтения — там можно оставить свой комментарий и пометить его как спойлер.",
    ],
  },
  {
    patterns: [/скачат/i, /загруз(ить|ка) глав/i],
    replies: [
      "Скачать главу можно из панели «Оглавление» в читалке — рядом с каждой главой есть отдельная кнопка загрузки.",
    ],
  },
  {
    patterns: [/тем[ауы] читалк/i, /шрифт/i, /бионическ/i, /размер текста/i, /ширина текста/i],
    replies: [
      "Настройки читалки открываются через кнопку с шестерёнкой во время чтения: там можно выбрать тему оформления, шрифт, размер и ширину текста, а ещё включить «Бионическое чтение», которое выделяет начала слов жирным для более быстрого чтения.",
    ],
  },
  {
    patterns: [/тем[ауы] сайта/i, /цвет(овая)? схем/i, /светл(ая|ую) тем/i, /тёмн(ая|ую) тем/i],
    replies: [
      "Тема всего сайта настраивается в разделе «Настройки» → «Тема сайта»: можно выбрать светлый или тёмный режим и одну из девяти цветовых палитр — от «Сакуры» до «AMOLED».",
    ],
  },
  {
    patterns: [/автоскролл/i],
    replies: [
      "Автоскролл включается четвёртой плавающей кнопкой в читалке (иконка play). Скорость прокрутки настраивается ползунком в панели настроек читалки.",
    ],
  },
  {
    patterns: [/аватар/i, /фото профил/i, /баннер профил/i],
    replies: [
      "Сменить аватар или баннер профиля можно в разделе «Настройки» → «Профиль»: там открывается редактор, где можно загрузить своё фото и обрезать нужную область, либо выбрать один из готовых вариантов.",
    ],
  },
  {
    patterns: [/поиск/i, /найти книгу/i, /как искать/i],
    replies: [
      "Поиск открывается по клику на строку «Что ищем, семпай?» в шапке сайта или сочетанием клавиш Ctrl+K. Там же можно искать не только новеллы, но и команды переводчиков, персонажей и создателей.",
    ],
  },
  {
    patterns: [/фильтр (в )?каталог/i, /каталог/i],
    replies: [
      "В каталоге слева расположены фильтры: тип произведения, жанры, теги, статус оригинала и перевода, количество глав, возрастной рейтинг, год выпуска и минимальная оценка — их можно комбинировать одновременно.",
    ],
  },
  {
    patterns: [/топ 100/i, /страница топ/i, /рейтинг новелл/i],
    replies: [
      "Полный рейтинг всех новелл сайта по оценке читателей доступен на странице «Топ» в верхнем меню — там собраны 100 лучших произведений.",
    ],
  },
  {
    patterns: [/подборк/i],
    replies: [
      "Тематические подборки собраны на отдельной странице «Подборки» — например, «Культовые новеллы», «Перерождение и Регрессия» или «Ужасы и Выживание». Там же есть поиск по подборкам.",
    ],
  },
  {
    patterns: [/фандом/i],
    replies: [
      "Раздел «Фандомы» показывает произведения по любимым вселенным — Гарри Поттер, Наруто, Marvel и другие. Открыть его можно из верхнего меню.",
    ],
  },
  {
    patterns: [/рецензи/i, /отзыв/i, /оцен(ить|ка) книг/i],
    replies: [
      "Оставить рецензию можно на странице любой новеллы во вкладке «Рецензии»: там же можно поставить оценку от 1 до 10 и написать отзыв, который увидят другие читатели.",
    ],
  },
  {
    patterns: [/уведомлен/i],
    replies: [
      "Уведомления открываются по клику на колокольчик в шапке сайта. Там есть вкладки «Главы», «Социальное» и «Важное», а также фильтр «Новые» / «Прочитанные». Настроить, о чём именно уведомлять, можно в «Настройках» → «Уведомления».",
    ],
  },
  {
    patterns: [/подписк/i, /premium/i, /премиум/i],
    replies: [
      "Premium-подписка оформляется в разделе «Настройки» → «Подписка»: она даёт доступ к части платных глав, скидку на покупки, отключение рекламы и эксклюзивный значок в профиле.",
    ],
  },
  {
    patterns: [/парол/i, /email/i, /почт/i, /привяз(ать|ка) аккаунт/i],
    replies: [
      "Изменить пароль, email или привязать аккаунты Google, Яндекс, ВКонтакте и Telegram можно в разделе «Настройки» → «Безопасность и данные».",
    ],
  },
  {
    patterns: [/приватн/i, /конфиденциальност/i, /очистить истори/i],
    replies: [
      "В разделе «Настройки» → «Конфиденциальность» можно включить приватный профиль (закладки и комментарии будут видны только вам), а также очистить историю чтения и поиска.",
    ],
  },
  {
    patterns: [/фильтр контента/i, /скрыть 18/i, /возрастной фильтр/i],
    replies: [
      "В разделе «Настройки» → «Фильтр контента» можно выбрать, показывать только новеллы, только фанфики или всё вместе, а также настроить отображение контента 18+ — показывать, скрывать или показывать только его.",
    ],
  },
  {
    patterns: [/предложить перевод/i, /хочу переводить/i],
    replies: [
      "Форма «Предложить перевод» находится в меню профиля (аватар → «Другое» → «Предложить перевод») — там можно указать название произведения, ссылку на оригинал и описание.",
    ],
  },
  {
    patterns: [/начать публиковать/i, /опубликовать (своё|свою) книгу/i, /стать автором/i],
    replies: [
      "Чтобы предложить собственное произведение или перевод к публикации, откройте меню профиля → «Другое» → «Начать публиковать» и заполните форму заявки.",
    ],
  },
  {
    patterns: [/случайн(ая|ую) новелл/i, /удиви случайной книгой/i],
    replies: [
      "Кнопка случайной новеллы находится в разделе «Быстрые действия» (иконка перемешивания рядом с поиском в шапке сайта).",
    ],
  },
  {
    patterns: [/продолжить чтение/i, /где я остановил/i],
    replies: [
      "Быстро вернуться к последней прочитанной главе можно через «Быстрые действия» в шапке сайта — пункт «Продолжить чтение» ведёт прямо на нужную страницу.",
    ],
  },
  {
    patterns: [/кто ты (такая|такой)? как ии/i, /ты (это )?ии/i],
    replies: [
      "Да, я виртуальный книжный помощник NovellRead — отвечаю на вопросы о каталоге и подсказываю по функциям сайта.",
    ],
  },
];

function normalize(text: string) {
  return text.toLocaleLowerCase("ru-RU").trim();
}

function tokenize(text: string): string[] {
  return text.match(/[a-zа-яё0-9]+/gi)?.map((w) => w.toLowerCase()) ?? [];
}

/** Deterministic-ish pick so results feel a little less robotic without
 * requiring external randomness sources that would break test reproducibility
 * too badly (still uses Math.random, which is fine for a chat assistant). */
function pick<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

interface MatchedContext {
  genres: Set<string>;
  tags: Set<string>;
  countries: Set<string>;
  types: Set<string>;
  labels: Set<string>;
}

function createEmptyContext(): MatchedContext {
  return {
    genres: new Set(),
    tags: new Set(),
    countries: new Set(),
    types: new Set(),
    labels: new Set(),
  };
}

/** Extracts genre/tag/country/type matches from a single message, returning
 * both the "positive" matches and, if the message contains a negation cue
 * (e.g. "не хочу ужасов"), the same rule's values as things to *remove*
 * from any accumulated context instead of add. */
function extractFromMessage(message: string) {
  const words = tokenize(message);
  const positive = createEmptyContext();
  const negative = createEmptyContext();
  const isNegatedMessage = NEGATION_PATTERN.test(message);

  for (const rule of KEYWORD_RULES) {
    const patternHit = rule.patterns?.some((pattern) => pattern.test(message)) ?? false;
    const wordHit = rule.words?.some((word) => words.includes(word)) ?? false;
    if (!patternHit && !wordHit) continue;

    const target = isNegatedMessage ? negative : positive;
    rule.genres?.forEach((g) => target.genres.add(g));
    rule.tags?.forEach((t) => target.tags.add(t));
    rule.countries?.forEach((c) => target.countries.add(c));
    rule.types?.forEach((t) => target.types.add(t));
    target.labels.add(rule.label);
  }

  return { positive, negative, words };
}

function mergeInto(target: MatchedContext, source: MatchedContext) {
  source.genres.forEach((v) => target.genres.add(v));
  source.tags.forEach((v) => target.tags.add(v));
  source.countries.forEach((v) => target.countries.add(v));
  source.types.forEach((v) => target.types.add(v));
  source.labels.forEach((v) => target.labels.add(v));
}

function subtractFrom(target: MatchedContext, source: MatchedContext) {
  source.genres.forEach((v) => target.genres.delete(v));
  source.tags.forEach((v) => target.tags.delete(v));
  source.countries.forEach((v) => target.countries.delete(v));
  source.types.forEach((v) => target.types.delete(v));
  source.labels.forEach((v) => target.labels.delete(v));
}

function scoreNovel(novel: Novel, ctx: MatchedContext, freeTextTokens: string[]) {
  let score = 0;
  const novelGenres = novel.genres.map((g) => g.toLowerCase());
  const novelTags = novel.tags.map((t) => t.toLowerCase());

  ctx.genres.forEach((g) => {
    if (novelGenres.includes(g.toLowerCase())) score += 3;
  });
  ctx.tags.forEach((t) => {
    if (novelTags.includes(t.toLowerCase())) score += 3;
  });
  if (ctx.countries.has(novel.country)) score += 2;
  if (ctx.types.has(novel.type)) score += 2;

  const haystack = normalize(
    `${novel.title} ${novel.englishTitle ?? ""} ${novel.author} ${novel.description}`
  );
  freeTextTokens.forEach((token) => {
    if (token.length >= 4 && haystack.includes(token)) score += 1;
  });

  return score;
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      message?: string;
      history?: HistoryTurn[];
      excludeSlugs?: string[];
    };
    const rawMessage = (body.message ?? "").trim().slice(0, 500);
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    const excludeSlugs = new Set(
      Array.isArray(body.excludeSlugs) ? body.excludeSlugs.slice(0, 40) : []
    );

    if (!rawMessage) {
      return NextResponse.json(
        { error: "Сообщение не может быть пустым" },
        { status: 400 }
      );
    }

    const message = normalize(rawMessage);
    const library = (await db.select().from(novels)) as Novel[];
    const messageWords = tokenize(message);

    // A short message consisting only of a farewell word (e.g. just "пока")
    // is treated as goodbye, but the same word inside a longer sentence
    // ("пока не знаю, что почитать") is not, since "пока" also means "for
    // now" in Russian.
    const isFarewell =
      (messageWords.length <= 2 &&
        messageWords.length > 0 &&
        FAREWELL_WORDS.includes(messageWords[0])) ||
      FAREWELL_PHRASE_PATTERN.test(message);

    // Small talk & self-description take priority over everything else —
    // these are conversational, not catalog queries.
    if (isFarewell) {
      return NextResponse.json({
        reply: pick([
          "До встречи! Возвращайтесь, если понадобится подсказка с выбором книги 👋",
          "Пока! Хорошего чтения, и заходите ещё, если появятся вопросы.",
        ]),
        novels: [],
      });
    }

    if (THANKS_PATTERN.test(message)) {
      return NextResponse.json({
        reply: pick([
          "Пожалуйста! Рада была помочь 📚",
          "Всегда рада! Обращайтесь, если нужна ещё подборка.",
        ]),
        novels: [],
      });
    }

    if (SELF_INTRO_PATTERN.test(message)) {
      return NextResponse.json({
        reply:
          "Меня зовут Нова, я книжный помощник NovellRead. Умею подбирать новеллы по жанру, стране, настроению или конкретным тегам, а ещё отвечаю на вопросы о том, как устроен сайт — от закладок и покупки глав до настроек читалки.",
        novels: [],
      });
    }

    if (HOW_ARE_YOU_PATTERN.test(message)) {
      return NextResponse.json({
        reply: pick([
          "Отлично, особенно когда есть с кем обсудить новеллы! А как ваши дела с чтением — нашли что-то интересное в последнее время?",
          "Всё хорошо, спасибо! Готова подобрать вам что-нибудь почитать, если настроение располагает.",
        ]),
        novels: [],
      });
    }

    // General site FAQ — checked before catalog logic so questions about
    // features aren't accidentally treated as a book search.
    const helpMatch = HELP_TOPICS.find((topic) =>
      topic.patterns.some((pattern) => pattern.test(message))
    );
    if (helpMatch) {
      return NextResponse.json({ reply: pick(helpMatch.replies), novels: [] });
    }

    // --- Conversation context resolution ---
    const current = extractFromMessage(message);
    const context = createEmptyContext();

    const wantsReset = RESET_PATTERN.test(message);
    if (!wantsReset) {
      // Merge matches from recent user turns so follow-ups like "а
      // подешевле?" keep remembering the previously discussed genre.
      for (const turn of history) {
        if (turn.role !== "user") continue;
        const extracted = extractFromMessage(normalize(turn.text));
        mergeInto(context, extracted.positive);
        subtractFrom(context, extracted.negative);
      }
    }
    mergeInto(context, current.positive);
    subtractFrom(context, current.negative);

    const isGreeting = current.words.length > 0 && GREETING_WORDS.includes(current.words[0]);
    const wantsTop = TOP_PATTERN.test(message);
    const wantsNew = NEW_PATTERN.test(message);
    const wantsFree = FREE_PATTERN.test(message);
    const wantsAdult = ADULT_PATTERN.test(message);
    const wantsKids = KIDS_PATTERN.test(message);
    const wantsShort = SHORT_PATTERN.test(message);
    const wantsLong = LONG_PATTERN.test(message);
    const wantsHidden = HIDDEN_GEM_PATTERN.test(message);
    const wantsSurprise = SURPRISE_ME_PATTERN.test(message);
    const wantsMore = MORE_PATTERN.test(message);

    const hasFilters =
      context.genres.size > 0 ||
      context.tags.size > 0 ||
      context.countries.size > 0 ||
      context.types.size > 0;

    let pool = library;
    if (wantsMore && excludeSlugs.size > 0) {
      const withoutSeen = library.filter((n) => !excludeSlugs.has(n.slug));
      // Only actually exclude previously shown novels if enough remain —
      // otherwise fall back to the full library so we don't return nothing.
      if (withoutSeen.length >= 4) pool = withoutSeen;
    }

    let scoredEntries = pool.map((novel) => ({
      novel,
      score: scoreNovel(novel, context, current.words),
    }));

    const hasAnyPositiveScore = scoredEntries.some((entry) => entry.score > 0);

    let ranked: Novel[];
    if (wantsSurprise || (isGreeting && !hasFilters)) {
      ranked = [...pool].sort((a, b) => b.rating - a.rating || b.bookmarksCount - a.bookmarksCount);
      // Shuffle the top slice a little so "surprise me" doesn't always
      // return the exact same four novels.
      const topSlice = ranked.slice(0, 10);
      for (let i = topSlice.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [topSlice[i], topSlice[j]] = [topSlice[j], topSlice[i]];
      }
      ranked = topSlice;
    } else if (hasAnyPositiveScore) {
      ranked = scoredEntries
        .sort((a, b) => b.score - a.score || b.novel.rating - a.novel.rating)
        .filter((entry) => entry.score > 0)
        .map((entry) => entry.novel);
    } else {
      ranked = [...pool].sort((a, b) => b.rating - a.rating);
    }

    if (wantsFree) ranked = ranked.filter((n) => n.ageRating !== "18+");
    if (wantsAdult) ranked = ranked.filter((n) => n.ageRating === "18+");
    if (wantsKids) ranked = ranked.filter((n) => n.ageRating !== "18+");

    if (wantsTop) {
      ranked = [...ranked].sort((a, b) => b.rating - a.rating);
    } else if (wantsNew) {
      ranked = [...ranked].sort((a, b) => b.releaseYear - a.releaseYear);
    } else if (wantsShort) {
      ranked = [...ranked].sort((a, b) => a.chaptersCount - b.chaptersCount);
    } else if (wantsLong) {
      ranked = [...ranked].sort((a, b) => b.chaptersCount - a.chaptersCount);
    } else if (wantsHidden) {
      ranked = [...ranked].sort((a, b) => a.bookmarksCount - b.bookmarksCount);
    }

    const recommendations = ranked.slice(0, 4);

    let reply: string;

    if (isGreeting && !hasFilters) {
      reply = pick([
        "Привет! Я книжный помощник NovellRead 📚 Расскажите, что вам интересно почитать — жанр, страну происхождения или настроение — и я подберу подходящие новеллы. Вот несколько популярных вариантов для начала:",
        "Здравствуйте! Готова помочь с выбором новеллы. Можете описать жанр, настроение или конкретную деталь сюжета — а пока вот немного популярного:",
      ]);
    } else if (wantsSurprise) {
      reply = pick([
        "Доверяете мне выбор? Отлично, вот моя личная подборка на сегодня:",
        "Люблю такие запросы! Вот что я бы предложила почитать прямо сейчас:",
      ]);
    } else if (wantsMore) {
      reply = recommendations.length
        ? "Конечно, вот ещё несколько вариантов:"
        : "Кажется, я уже показала всё подходящее по этой теме — может, попробуем другой жанр?";
    } else if (hasFilters) {
      const labelText = Array.from(context.labels).slice(0, 3).join(", ");
      reply = recommendations.length
        ? `Судя по вашему запросу (${labelText}), вот что может понравиться:`
        : `Я поняла, что вас интересует «${labelText}», но точных совпадений в каталоге пока нет. Вот похожие варианты:`;
    } else if (wantsTop) {
      reply = "Вот новеллы с самым высоким рейтингом читателей:";
    } else if (wantsNew) {
      reply = "Вот самые свежие произведения в каталоге:";
    } else if (wantsHidden) {
      reply = "Вот немного менее раскрученные, но достойные внимания варианты:";
    } else if (hasAnyPositiveScore) {
      reply = "Вот что удалось найти по вашему запросу:";
    } else {
      reply = pick([
        "Не совсем поняла запрос, но вот несколько популярных новелл — уточните жанр (фэнтези, культивация, романтика и т.д.), и я подберу точнее:",
        "Хм, не нашла точного совпадения. Расскажите чуть подробнее — например, какое настроение вы ищете или какую страну предпочитаете — и я подберу вариант получше:",
      ]);
    }

    return NextResponse.json({
      reply,
      novels: recommendations,
    });
  } catch (error) {
    console.error("API /api/assistant error:", error);
    return NextResponse.json(
      { error: "Не удалось получить ответ ассистента" },
      { status: 500 }
    );
  }
}
