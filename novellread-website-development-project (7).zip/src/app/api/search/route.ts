import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { novels } from "@/db/schema";
import type { Novel, SearchDirectoryItem } from "@/types";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

const directoryProfiles = {
  characters: [
    ["Ким Докча", "Главный герой новеллы «Точка зрения Всеведущего читателя»", "Dokja", "omniscient-readers-viewpoint"],
    ["Ю Джунхёк", "Регрессор из «Точки зрения Всеведущего читателя»", "Junghyeok", "omniscient-readers-viewpoint"],
    ["Лейлин Фарлье", "Чернокнижник и учёный из Мира Магов", "Leylin", "warlock-of-the-magus-world"],
    ["Сон Джин-Ву", "Теневой монарх из «Поднятия уровня в одиночку»", "Jinwoo", "solo-leveling"],
    ["Пенелопа Экхарт", "Главная героиня новеллы о злодейке", "Penelope", "death-is-the-only-ending-for-the-villainess"],
    ["Хань Сяо", "Легендарный механик и межзвёздный игрок", "HanXiao", "the-legendary-mechanic"],
    ["Не Ли", "Заклинатель демонов, вернувшийся в прошлое", "NieLi", "tales-of-demons-and-gods"],
    ["Ян Кай", "Мастер боевых искусств, достигший вершины", "YangKai", "martial-peak"],
  ],
  users: [
    ["Dmitry", "Читатель и переводчик • #575882", "Reader575882", "profile"],
    ["Докча_читатель", "Читает «Точку зрения Всеведущего читателя»", "DokjaReader", "profile"],
    ["ТеневойМонарх", "Поклонник «Поднятия уровня в одиночку»", "ShadowMonarch", "profile"],
    ["MagusReader", "Читает «Чернокнижника в Мире Магов»", "MagusReader", "profile"],
    ["NovelHunter", "Коллекционер корейских веб-новелл", "NovelHunter", "profile"],
    ["Cultivator", "Знаток китайских новелл и культивации", "Cultivator", "profile"],
  ],
} as const;

function normalize(value: string) {
  return value.toLocaleLowerCase("ru-RU").replace(/ё/g, "е").trim();
}

function isMatch(query: string, ...fields: Array<string | null | undefined>) {
  if (!query) return true;
  return fields.some((field) => normalize(field ?? "").includes(query));
}

function rankNovel(novel: Novel, query: string) {
  const title = normalize(novel.title);
  const englishTitle = normalize(novel.englishTitle ?? "");
  const originalTitle = normalize(novel.originalTitle ?? "");

  if (title === query || englishTitle === query || originalTitle === query) return 0;
  if (title.startsWith(query) || englishTitle.startsWith(query)) return 1;
  if (
    title.split(/\s+/).some((word) => word.startsWith(query)) ||
    englishTitle.split(/\s+/).some((word) => word.startsWith(query))
  ) {
    return 2;
  }
  return 3;
}

function createDirectoryItem(
  category: "characters" | "users",
  values: readonly [string, string, string, string]
): SearchDirectoryItem {
  const [title, subtitle, seed, target] = values;
  return {
    id: `${category}-${normalize(title).replace(/\s+/g, "-")}`,
    category,
    title,
    subtitle,
    image: `https://api.dicebear.com/7.x/${category === "characters" ? "adventurer" : "bottts"}/svg?seed=${encodeURIComponent(seed)}`,
    href: category === "characters" ? `/novel/${target}` : "/profile",
  };
}

export async function GET(request: NextRequest) {
  try {
    const query = normalize(request.nextUrl.searchParams.get("q") ?? "");
    const limit = Math.min(
      20,
      Math.max(1, Number(request.nextUrl.searchParams.get("limit")) || 10)
    );
    const settings = await getOrCreateUserSettings();
    const library = (await db.select().from(novels)) as Novel[];
    const allNovels = library.filter((novel) => {
      if (settings.contentType === "novels" && novel.type === "Фанфик") {
        return false;
      }
      if (settings.contentType === "fanfiction" && novel.type !== "Фанфик") {
        return false;
      }
      if (settings.adultContent === "hide" && novel.ageRating === "18+") {
        return false;
      }
      if (settings.adultContent === "only" && novel.ageRating !== "18+") {
        return false;
      }
      return true;
    });

    const popular = [...allNovels]
      .sort((a, b) => b.bookmarksCount - a.bookmarksCount)
      .slice(0, 4);

    const novelResults = query
      ? allNovels
          .filter((novel) =>
            isMatch(
              query,
              novel.title,
              novel.englishTitle,
              novel.originalTitle
            )
          )
          .sort((a, b) => {
            const rankDifference = rankNovel(a, query) - rankNovel(b, query);
            return rankDifference || b.bookmarksCount - a.bookmarksCount;
          })
          .slice(0, limit)
      : [];

    const uniqueTeams = Array.from(
      new Map(
        allNovels.map((novel) => [
          normalize(novel.translator),
          {
            name: novel.translator,
            novel,
          },
        ])
      ).values()
    );

    const teams: SearchDirectoryItem[] = query
      ? uniqueTeams
          .filter(({ name, novel }) =>
            isMatch(query, name, novel.title, novel.englishTitle)
          )
          .map(({ name, novel }, index) => ({
            id: `team-${index}-${normalize(name).replace(/\s+/g, "-")}`,
            category: "teams" as const,
            title: name,
            subtitle: `Команда перевода • ${novel.title}`,
            image: `https://api.dicebear.com/7.x/shapes/svg?seed=${encodeURIComponent(name)}`,
            href: `/novel/${novel.slug}`,
          }))
          .slice(0, limit)
      : [];

    const uniqueCreators = Array.from(
      new Map(
        allNovels.map((novel) => [
          normalize(novel.author),
          {
            name: novel.author,
            novel,
          },
        ])
      ).values()
    );

    const creators: SearchDirectoryItem[] = query
      ? uniqueCreators
          .filter(({ name, novel }) =>
            isMatch(query, name, novel.title, novel.englishTitle)
          )
          .map(({ name, novel }, index) => ({
            id: `creator-${index}-${normalize(name).replace(/\s+/g, "-")}`,
            category: "creators" as const,
            title: name,
            subtitle: `Автор • ${novel.title}`,
            image: `https://api.dicebear.com/7.x/personas/svg?seed=${encodeURIComponent(name)}`,
            href: `/novel/${novel.slug}`,
          }))
          .slice(0, limit)
      : [];

    const characterItems = directoryProfiles.characters.map((item) =>
      createDirectoryItem("characters", item)
    );
    const characters = query
      ? characterItems
          .filter((item) => isMatch(query, item.title, item.subtitle))
          .slice(0, limit)
      : [];

    const userItems = directoryProfiles.users.map((item) =>
      createDirectoryItem("users", item)
    );
    const users = query
      ? userItems
          .filter((item) => isMatch(query, item.title, item.subtitle))
          .slice(0, limit)
      : [];

    return NextResponse.json({
      query: request.nextUrl.searchParams.get("q")?.trim() ?? "",
      novels: novelResults,
      teams,
      characters,
      creators,
      users,
      popular,
    });
  } catch (error) {
    console.error("API /api/search error:", error);
    return NextResponse.json(
      { error: "Не удалось выполнить поиск" },
      { status: 500 }
    );
  }
}
