import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { userSettings } from "@/db/schema";
import {
  DEFAULT_USER_ID,
  getOrCreateUserSettings,
} from "@/lib/user-settings";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const themeModes = new Set(["dark", "light"]);
const colorSchemes = new Set([
  "honey",
  "book",
  "amoled",
  "slate",
  "lavender",
  "sakura",
  "ocean",
  "sunset",
  "forest",
]);
const contentTypes = new Set(["all", "novels", "fanfiction"]);
const adultContentModes = new Set(["show", "hide", "only"]);

function cleanText(value: unknown, maxLength: number) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : null;
}

export async function GET() {
  try {
    const settings = await getOrCreateUserSettings();
    return NextResponse.json({ settings });
  } catch (error) {
    console.error("API /api/settings GET error:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить настройки" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const current = await getOrCreateUserSettings();
    const body = (await request.json()) as Record<string, unknown>;
    const update: Partial<typeof userSettings.$inferInsert> = {
      updatedAt: new Date(),
    };

    const displayName = cleanText(body.displayName, 40);
    if (displayName) update.displayName = displayName;

    const username = cleanText(body.username, 32);
    if (username) {
      update.username = username
        .replace(/^@/, "")
        .replace(/[^a-zA-Z0-9_.-]/g, "")
        .slice(0, 32);
    }

    if (typeof body.bio === "string") {
      update.bio = body.bio.trim().slice(0, 500);
    }

    const avatarUrl = cleanText(body.avatarUrl, 2000);
    if (avatarUrl) update.avatarUrl = avatarUrl;

    if (body.bannerUrl === null) {
      update.bannerUrl = null;
    } else {
      const bannerUrl = cleanText(body.bannerUrl, 2000);
      if (bannerUrl) update.bannerUrl = bannerUrl;
    }

    const email = cleanText(body.email, 160);
    if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      update.email = email;
      if (email !== current.email) update.emailVerified = false;
    }

    if (typeof body.emailVerified === "boolean") {
      update.emailVerified = body.emailVerified;
    }

    if (
      typeof body.themeMode === "string" &&
      themeModes.has(body.themeMode)
    ) {
      update.themeMode = body.themeMode;
    }

    if (
      typeof body.colorScheme === "string" &&
      colorSchemes.has(body.colorScheme)
    ) {
      update.colorScheme = body.colorScheme;
    }

    if (
      typeof body.contentType === "string" &&
      contentTypes.has(body.contentType)
    ) {
      update.contentType = body.contentType;
    }

    if (
      typeof body.adultContent === "string" &&
      adultContentModes.has(body.adultContent)
    ) {
      update.adultContent = body.adultContent;
    }

    if (
      body.notificationPreferences &&
      typeof body.notificationPreferences === "object" &&
      !Array.isArray(body.notificationPreferences)
    ) {
      const incoming = body.notificationPreferences as Record<string, unknown>;
      const allowedKeys = [
        "reading",
        "planned",
        "completed",
        "paused",
        "dropped",
        "chaptersAvailable",
        "likes",
        "replies",
        "browserPush",
        "telegram",
      ];
      const safeValues = { ...current.notificationPreferences };
      for (const key of allowedKeys) {
        if (typeof incoming[key] === "boolean") {
          safeValues[key] = incoming[key] as boolean;
        }
      }
      update.notificationPreferences = safeValues;
    }

    if (
      body.linkedAccounts &&
      typeof body.linkedAccounts === "object" &&
      !Array.isArray(body.linkedAccounts)
    ) {
      const incoming = body.linkedAccounts as Record<string, unknown>;
      const safeValues = { ...current.linkedAccounts };
      for (const key of ["google", "yandex", "vk", "telegram"]) {
        if (typeof incoming[key] === "boolean") {
          safeValues[key] = incoming[key] as boolean;
        }
      }
      update.linkedAccounts = safeValues;
    }

    if (typeof body.premium === "boolean") update.premium = body.premium;
    if (typeof body.privateProfile === "boolean") {
      update.privateProfile = body.privateProfile;
    }

    const updated = await db
      .update(userSettings)
      .set(update)
      .where(eq(userSettings.userId, DEFAULT_USER_ID))
      .returning();

    return NextResponse.json({ settings: updated[0] });
  } catch (error) {
    console.error("API /api/settings PATCH error:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить настройки" },
      { status: 500 }
    );
  }
}
