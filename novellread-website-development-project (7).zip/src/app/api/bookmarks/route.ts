import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bookmarks, novels } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

const allowedStatuses = new Set([
  "reading",
  "planned",
  "completed",
  "dropped",
  "paused",
  "uninterested",
  "favorite",
]);

export async function GET(request: NextRequest) {
  try {
    const userId = "default_user";
    const userBookmarks = await db
      .select({
        bookmark: bookmarks,
        novel: novels,
      })
      .from(bookmarks)
      .innerJoin(novels, eq(bookmarks.novelId, novels.id))
      .where(eq(bookmarks.userId, userId));

    const formatted = userBookmarks.map((item) => ({
      ...item.bookmark,
      novel: item.novel,
    }));

    return NextResponse.json({ bookmarks: formatted });
  } catch (error) {
    console.error("API /api/bookmarks GET error:", error);
    return NextResponse.json({ error: "Failed to fetch bookmarks" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { novelId, status, lastReadChapter } = body;
    const userId = "default_user";

    if (!novelId) {
      return NextResponse.json({ error: "novelId is required" }, { status: 400 });
    }

    if (status && status !== "remove" && !allowedStatuses.has(status)) {
      return NextResponse.json(
        { error: "Unknown bookmark status" },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.novelId, novelId)))
      .limit(1);

    if (existing.length > 0) {
      if (!status || status === "remove") {
        await db.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
        return NextResponse.json({ success: true, removed: true });
      } else {
        const updated = await db
          .update(bookmarks)
          .set({
            status,
            lastReadChapter: lastReadChapter ?? existing[0].lastReadChapter,
            updatedAt: new Date(),
          })
          .where(eq(bookmarks.id, existing[0].id))
          .returning();
        return NextResponse.json({ success: true, bookmark: updated[0] });
      }
    } else {
      if (status && status !== "remove") {
        const inserted = await db
          .insert(bookmarks)
          .values({
            userId,
            novelId,
            status: status || "reading",
            lastReadChapter: lastReadChapter || 1,
          })
          .returning();
        return NextResponse.json({ success: true, bookmark: inserted[0] });
      }
      return NextResponse.json({ success: true, removed: true });
    }
  } catch (error) {
    console.error("API /api/bookmarks POST error:", error);
    return NextResponse.json({ error: "Failed to update bookmark" }, { status: 500 });
  }
}
