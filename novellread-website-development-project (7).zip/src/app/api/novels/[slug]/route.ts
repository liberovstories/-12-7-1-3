import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { novels, chapters, reviews, bookmarks } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await context.params;

    const novelRecord = await db
      .select()
      .from(novels)
      .where(eq(novels.slug, slug))
      .limit(1);

    if (novelRecord.length === 0) {
      return NextResponse.json({ error: "Novel not found" }, { status: 404 });
    }

    const novel = novelRecord[0];

    // Fetch chapters
    const chaptersList = await db
      .select()
      .from(chapters)
      .where(eq(chapters.novelId, novel.id))
      .orderBy(asc(chapters.chapterNumber));

    // Fetch reviews
    const reviewsList = await db
      .select()
      .from(reviews)
      .where(eq(reviews.novelId, novel.id))
      .orderBy(desc(reviews.createdAt));

    // Fetch bookmark status for default user
    const bookmarkRecord = await db
      .select()
      .from(bookmarks)
      .where(eq(bookmarks.novelId, novel.id))
      .limit(1);

    return NextResponse.json({
      novel,
      chapters: chaptersList,
      reviews: reviewsList,
      userBookmark: bookmarkRecord[0] || null,
    });
  } catch (error) {
    console.error("API /api/novels/[slug] error:", error);
    return NextResponse.json({ error: "Failed to fetch novel" }, { status: 500 });
  }
}
