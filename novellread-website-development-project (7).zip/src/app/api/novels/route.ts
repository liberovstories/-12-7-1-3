import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { novels } from "@/db/schema";
import { sql, desc, asc } from "drizzle-orm";
import { seedDatabase, seedFreeOriginalNovels } from "@/db/seed";
import { getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    // Ensure database is seeded if needed
    const checkCount = await db.select({ count: sql<number>`count(*)` }).from(novels);
    if (Number(checkCount[0]?.count) === 0) {
      await seedDatabase();
    }
    await seedFreeOriginalNovels();

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search")?.trim().toLowerCase() || "";
    const type = searchParams.get("type") || "all";
    const country = searchParams.get("country") || "all";
    const status = searchParams.get("status") || "all";
    const translationStatus = searchParams.get("translationStatus") || "all";
    const ageRating = searchParams.get("ageRating") || "all";
    const chaptersRange = searchParams.get("chaptersRange") || "all";
    const releaseYear = searchParams.get("releaseYear") || "all";
    const minRating = searchParams.get("minRating") || "all";
    const sortBy = searchParams.get("sortBy") || "popularity";
    const fandom = searchParams.get("fandom") || "";
    const isFeatured = searchParams.get("featured") === "true";
    const isRecommendation = searchParams.get("recommendation") === "true";
    const fullyFreeOnly = searchParams.get("fullyFree") === "true";
    const genresParam = searchParams.get("genres");
    const tagsParam = searchParams.get("tags");

    const selectedGenres = genresParam ? genresParam.split(",").filter(Boolean) : [];
    const selectedTags = tagsParam ? tagsParam.split(",").filter(Boolean) : [];

    // Apply the user's global content preferences before catalog filters.
    // Ordering explicitly by id guarantees a deterministic base order from
    // PostgreSQL (which does not promise row order without ORDER BY), so the
    // list never visually reshuffles between identical requests.
    const settings = await getOrCreateUserSettings();
    const library = await db.select().from(novels).orderBy(asc(novels.id));
    const allNovels = library.filter((novel) => {
      if (settings.contentType === "novels" && novel.type === "Фанфик") {
        return false;
      }
      if (settings.contentType === "fanfiction" && novel.type !== "Фанфик") {
        return false;
      }
      if (settings.adultContent === "hide" && novel.ageRating === "18+") {
        return false;
      }
      if (settings.adultContent === "only" && novel.ageRating !== "18+") {
        return false;
      }
      return true;
    });

    let filtered = allNovels.filter((n) => {
      // Search
      if (search) {
        const titleMatch = n.title.toLowerCase().includes(search);
        const engMatch = n.englishTitle ? n.englishTitle.toLowerCase().includes(search) : false;
        const authorMatch = n.author.toLowerCase().includes(search);
        if (!titleMatch && !engMatch && !authorMatch) return false;
      }

      // Type
      if (type !== "all" && n.type !== type) return false;

      // Country
      if (country !== "all" && n.country !== country) return false;

      // Status
      if (status !== "all" && n.status !== status) return false;

      // Translation status
      if (translationStatus !== "all" && n.translationStatus !== translationStatus) return false;

      // Age rating
      if (ageRating !== "all" && n.ageRating !== ageRating) return false;

      // Release year
      if (releaseYear !== "all") {
        if (releaseYear.includes("-")) {
          const [start, end] = releaseYear.split("-").map(Number);
          if (n.releaseYear < start || n.releaseYear > end) return false;
        } else if (releaseYear === "old") {
          if (n.releaseYear > 2019) return false;
        } else {
          if (n.releaseYear !== Number(releaseYear)) return false;
        }
      }

      // Rating
      if (minRating !== "all") {
        const minVal = parseFloat(minRating);
        if (n.rating < minVal) return false;
      }

      // Chapters range
      if (chaptersRange !== "all") {
        if (chaptersRange === "lt50" && n.chaptersCount >= 50) return false;
        if (chaptersRange === "50-200" && (n.chaptersCount < 50 || n.chaptersCount > 200)) return false;
        if (chaptersRange === "200-500" && (n.chaptersCount < 200 || n.chaptersCount > 500)) return false;
        if (chaptersRange === "500-1000" && (n.chaptersCount < 500 || n.chaptersCount > 1000)) return false;
        if (chaptersRange === "gt1000" && n.chaptersCount <= 1000) return false;
      }

      // Fandom
      if (fandom) {
        if (!n.fandom || !n.fandom.toLowerCase().includes(fandom.toLowerCase())) return false;
      }

      // Featured / Recommendation
      if (isFeatured && !n.isFeatured) return false;
      if (isRecommendation && !n.isRecommendation) return false;
      if (fullyFreeOnly && !n.fullyFree) return false;

      // Genres (must include all selected genres)
      if (selectedGenres.length > 0) {
        const itemGenres = n.genres || [];
        const hasAllGenres = selectedGenres.every((g) =>
          itemGenres.some((ig) => ig.toLowerCase() === g.toLowerCase())
        );
        if (!hasAllGenres) return false;
      }

      // Tags (must include all selected tags)
      if (selectedTags.length > 0) {
        const itemTags = n.tags || [];
        const hasAllTags = selectedTags.every((t) =>
          itemTags.some((it) => it.toLowerCase() === t.toLowerCase())
        );
        if (!hasAllTags) return false;
      }

      return true;
    });

    // Sorting. A stable `id` tiebreaker is appended to every branch so that
    // novels with equal sort-key values always keep the same relative order
    // across requests instead of visually reshuffling.
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "rating":
          return b.rating - a.rating || a.id - b.id;
        case "newest":
          return b.releaseYear - a.releaseYear || a.id - b.id;
        case "chapters":
          return b.chaptersCount - a.chaptersCount || a.id - b.id;
        case "views":
          return b.viewsCount - a.viewsCount || a.id - b.id;
        case "alphabet":
          return a.title.localeCompare(b.title, "ru") || a.id - b.id;
        case "popularity":
        default:
          return b.bookmarksCount - a.bookmarksCount || a.id - b.id;
      }
    });

    return NextResponse.json({
      items: filtered,
      total: filtered.length,
    });
  } catch (error) {
    console.error("API /api/novels error:", error);
    return NextResponse.json({ error: "Failed to fetch novels" }, { status: 500 });
  }
}
