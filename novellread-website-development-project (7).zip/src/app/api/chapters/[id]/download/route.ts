import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chapters, chapterPurchases, novels } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { DEFAULT_USER_ID } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

/**
 * Serves a chapter as a real downloadable file via a server response with a
 * `Content-Disposition: attachment` header.
 *
 * The reader used to build a `blob:` URL client-side and trigger it with a
 * synthesized `<a>` click. That approach is blocked in several browsers and,
 * importantly, inside sandboxed preview iframes that don't grant
 * `allow-downloads` — which is exactly the kind of environment this app is
 * often previewed in. A genuine top-level navigation to a server endpoint
 * that returns `Content-Disposition: attachment` is downloaded reliably
 * everywhere a normal link click is allowed.
 */
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);

    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const chapterRecord = await db
      .select()
      .from(chapters)
      .where(eq(chapters.id, chapterId))
      .limit(1);

    if (chapterRecord.length === 0) {
      return NextResponse.json({ error: "Глава не найдена" }, { status: 404 });
    }

    const chapter = chapterRecord[0];

    let unlocked = chapter.isFree;
    if (!unlocked) {
      const purchase = await db
        .select()
        .from(chapterPurchases)
        .where(
          and(
            eq(chapterPurchases.chapterId, chapterId),
            eq(chapterPurchases.userId, DEFAULT_USER_ID)
          )
        )
        .limit(1);
      unlocked = purchase.length > 0;
    }

    if (!unlocked) {
      return NextResponse.json(
        { error: "Эта глава ещё не куплена" },
        { status: 403 }
      );
    }

    const novelRecord = await db
      .select({ title: novels.title })
      .from(novels)
      .where(eq(novels.id, chapter.novelId))
      .limit(1);

    const novelTitle = novelRecord[0]?.title ?? "NovellRead";
    const safeFileName = `${novelTitle} - ${chapter.title}`
      .replace(/[\\/:*?"<>|]+/g, "")
      .trim()
      .slice(0, 150);

    const fileContent = `${chapter.title}\n\n${chapter.content}`;
    const encodedFileName = encodeURIComponent(`${safeFileName}.txt`);

    return new NextResponse(fileContent, {
      status: 200,
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        // RFC 5987 filename* covers Cyrillic titles; the plain `filename`
        // fallback keeps older clients working with a safe generic name.
        "Content-Disposition": `attachment; filename="chapter.txt"; filename*=UTF-8''${encodedFileName}`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("API /api/chapters/[id]/download error:", error);
    return NextResponse.json(
      { error: "Не удалось скачать главу" },
      { status: 500 }
    );
  }
}
