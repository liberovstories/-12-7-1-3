import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chapters, chapterPurchases, userSettings } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { DEFAULT_USER_ID, getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);
    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const chapterRecord = await db
      .select()
      .from(chapters)
      .where(eq(chapters.id, chapterId))
      .limit(1);

    if (chapterRecord.length === 0) {
      return NextResponse.json({ error: "Глава не найдена" }, { status: 404 });
    }

    const chapter = chapterRecord[0];

    if (chapter.isFree) {
      return NextResponse.json({ success: true, alreadyFree: true });
    }

    const existingPurchase = await db
      .select()
      .from(chapterPurchases)
      .where(
        and(
          eq(chapterPurchases.userId, DEFAULT_USER_ID),
          eq(chapterPurchases.chapterId, chapterId)
        )
      )
      .limit(1);

    if (existingPurchase.length > 0) {
      const settings = await getOrCreateUserSettings();
      return NextResponse.json({
        success: true,
        alreadyPurchased: true,
        balance: settings.balance,
      });
    }

    const settings = await getOrCreateUserSettings();
    if (settings.balance < chapter.price) {
      return NextResponse.json(
        { error: "Недостаточно монет для покупки главы" },
        { status: 400 }
      );
    }

    const updatedSettings = await db
      .update(userSettings)
      .set({
        balance: sql`${userSettings.balance} - ${chapter.price}`,
        updatedAt: new Date(),
      })
      .where(eq(userSettings.userId, DEFAULT_USER_ID))
      .returning();

    await db.insert(chapterPurchases).values({
      userId: DEFAULT_USER_ID,
      chapterId,
      novelId: chapter.novelId,
      pricePaid: chapter.price,
    });

    return NextResponse.json({
      success: true,
      balance: updatedSettings[0].balance,
    });
  } catch (error) {
    console.error("API /api/chapters/[id]/purchase error:", error);
    return NextResponse.json(
      { error: "Не удалось выполнить покупку" },
      { status: 500 }
    );
  }
}
