import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chapterNotes } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { DEFAULT_USER_ID } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);
    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const notes = await db
      .select()
      .from(chapterNotes)
      .where(
        and(
          eq(chapterNotes.chapterId, chapterId),
          eq(chapterNotes.userId, DEFAULT_USER_ID)
        )
      )
      .orderBy(desc(chapterNotes.updatedAt));

    return NextResponse.json({ notes });
  } catch (error) {
    console.error("API /api/chapters/[id]/notes GET error:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить заметки" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);
    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const body = (await request.json()) as { text?: string };
    const text = (body.text ?? "").trim().slice(0, 2000);
    if (text.length < 1) {
      return NextResponse.json(
        { error: "Заметка не может быть пустой" },
        { status: 400 }
      );
    }

    const inserted = await db
      .insert(chapterNotes)
      .values({
        chapterId,
        userId: DEFAULT_USER_ID,
        text,
      })
      .returning();

    return NextResponse.json({ note: inserted[0] }, { status: 201 });
  } catch (error) {
    console.error("API /api/chapters/[id]/notes POST error:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить заметку" },
      { status: 500 }
    );
  }
}
