import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chapterNotes } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { DEFAULT_USER_ID } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string; noteId: string }> }
) {
  try {
    const { noteId } = await context.params;
    const id = Number(noteId);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ error: "Некорректный id заметки" }, { status: 400 });
    }

    const body = (await request.json()) as { text?: string };
    const text = (body.text ?? "").trim().slice(0, 2000);
    if (text.length < 1) {
      return NextResponse.json(
        { error: "Заметка не может быть пустой" },
        { status: 400 }
      );
    }

    const updated = await db
      .update(chapterNotes)
      .set({ text, updatedAt: new Date() })
      .where(
        and(eq(chapterNotes.id, id), eq(chapterNotes.userId, DEFAULT_USER_ID))
      )
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ error: "Заметка не найдена" }, { status: 404 });
    }

    return NextResponse.json({ note: updated[0] });
  } catch (error) {
    console.error("API /api/chapters/[id]/notes/[noteId] PATCH error:", error);
    return NextResponse.json(
      { error: "Не удалось обновить заметку" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  context: { params: Promise<{ id: string; noteId: string }> }
) {
  try {
    const { noteId } = await context.params;
    const id = Number(noteId);
    if (!Number.isFinite(id)) {
      return NextResponse.json({ error: "Некорректный id заметки" }, { status: 400 });
    }

    await db
      .delete(chapterNotes)
      .where(
        and(eq(chapterNotes.id, id), eq(chapterNotes.userId, DEFAULT_USER_ID))
      );

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("API /api/chapters/[id]/notes/[noteId] DELETE error:", error);
    return NextResponse.json(
      { error: "Не удалось удалить заметку" },
      { status: 500 }
    );
  }
}
