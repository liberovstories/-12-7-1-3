import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chapterComments } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { DEFAULT_USER_ID, getOrCreateUserSettings } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);
    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const comments = await db
      .select()
      .from(chapterComments)
      .where(eq(chapterComments.chapterId, chapterId))
      .orderBy(desc(chapterComments.createdAt));

    return NextResponse.json({ comments });
  } catch (error) {
    console.error("API /api/chapters/[id]/comments GET error:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить комментарии" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const chapterId = Number(id);
    if (!Number.isFinite(chapterId)) {
      return NextResponse.json({ error: "Некорректный id главы" }, { status: 400 });
    }

    const body = (await request.json()) as {
      text?: string;
      isSpoiler?: boolean;
    };

    const text = (body.text ?? "").trim().slice(0, 1000);
    if (text.length < 1) {
      return NextResponse.json(
        { error: "Комментарий не может быть пустым" },
        { status: 400 }
      );
    }

    // Always use the reader's real NovellRead profile name and avatar
    // (including any custom uploaded photo) instead of a client-supplied
    // name and a freshly generated placeholder avatar — otherwise the
    // comment shows a different avatar than the one in the header/profile.
    const settings = await getOrCreateUserSettings();

    const inserted = await db
      .insert(chapterComments)
      .values({
        chapterId,
        userId: DEFAULT_USER_ID,
        userName: settings.displayName,
        userAvatar: settings.avatarUrl,
        text,
        isSpoiler: Boolean(body.isSpoiler),
      })
      .returning();

    return NextResponse.json({ comment: inserted[0] }, { status: 201 });
  } catch (error) {
    console.error("API /api/chapters/[id]/comments POST error:", error);
    return NextResponse.json(
      { error: "Не удалось отправить комментарий" },
      { status: 500 }
    );
  }
}
