import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { uploadedImages } from "@/db/schema";
import { DEFAULT_USER_ID } from "@/lib/user-settings";

export const dynamic = "force-dynamic";

const allowedTypes = new Set(["avatar", "banner"]);
const allowedMimeTypes = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
]);

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      dataUrl?: string;
      type?: string;
    };

    const kind = allowedTypes.has(body.type ?? "") ? body.type! : "avatar";
    const dataUrl = body.dataUrl;

    if (!dataUrl || !dataUrl.startsWith("data:image/")) {
      return NextResponse.json(
        { error: "Некорректное изображение" },
        { status: 400 }
      );
    }

    const match = dataUrl.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
    if (!match) {
      return NextResponse.json(
        { error: "Не удалось прочитать изображение" },
        { status: 400 }
      );
    }

    const [, mimeType, base64Content] = match;
    if (!allowedMimeTypes.has(mimeType)) {
      return NextResponse.json(
        { error: "Неподдерживаемый формат изображения" },
        { status: 400 }
      );
    }

    const approximateBytes = Math.ceil((base64Content.length * 3) / 4);
    const maxSizeBytes = 8 * 1024 * 1024;
    if (approximateBytes > maxSizeBytes) {
      return NextResponse.json(
        { error: "Файл слишком большой (максимум 8 МБ)" },
        { status: 400 }
      );
    }

    // Store the image inside PostgreSQL and serve it through a dynamic API
    // route. Writing to the public/ folder at runtime is not reliable here
    // because the production server only serves files that existed at build
    // time, so a database-backed route guarantees the image is always
    // reachable right after upload.
    const inserted = await db
      .insert(uploadedImages)
      .values({
        userId: DEFAULT_USER_ID,
        kind,
        mimeType,
        data: base64Content,
      })
      .returning({ id: uploadedImages.id });

    const imageId = inserted[0].id;
    return NextResponse.json({ url: `/api/uploads/image/${imageId}` });
  } catch (error) {
    console.error("API /api/uploads error:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить изображение" },
      { status: 500 }
    );
  }
}
