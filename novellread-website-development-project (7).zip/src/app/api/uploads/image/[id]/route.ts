import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { uploadedImages } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const imageId = Number(id);

    if (!Number.isFinite(imageId)) {
      return NextResponse.json({ error: "Некорректный id" }, { status: 400 });
    }

    const record = await db
      .select()
      .from(uploadedImages)
      .where(eq(uploadedImages.id, imageId))
      .limit(1);

    if (record.length === 0) {
      return NextResponse.json(
        { error: "Изображение не найдено" },
        { status: 404 }
      );
    }

    const buffer = Buffer.from(record[0].data, "base64");
    return new NextResponse(new Uint8Array(buffer), {
      status: 200,
      headers: {
        "Content-Type": record[0].mimeType,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (error) {
    console.error("API /api/uploads/image/[id] error:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить изображение" },
      { status: 500 }
    );
  }
}
