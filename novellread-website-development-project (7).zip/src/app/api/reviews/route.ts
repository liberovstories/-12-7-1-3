import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { novelId, userName, rating, text } = body;

    if (!novelId || !text || !rating) {
      return NextResponse.json(
        { error: "novelId, rating, and text are required" },
        { status: 400 }
      );
    }

    const inserted = await db
      .insert(reviews)
      .values({
        novelId,
        userName: userName || "Читатель",
        userAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
          userName || "Reader"
        )}`,
        rating: Math.min(10, Math.max(1, Number(rating))),
        text,
        likesCount: 0,
      })
      .returning();

    return NextResponse.json({ success: true, review: inserted[0] });
  } catch (error) {
    console.error("API /api/reviews POST error:", error);
    return NextResponse.json({ error: "Failed to post review" }, { status: 500 });
  }
}
