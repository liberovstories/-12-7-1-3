import { Suspense } from "react";
import { db } from "@/db";
import { novels } from "@/db/schema";
import { CatalogView } from "@/components/CatalogView";
import { getOrCreateUserSettings } from "@/lib/user-settings";
import { seedFreeOriginalNovels } from "@/db/seed";

export const dynamic = "force-dynamic";

export default async function CatalogPage() {
  await seedFreeOriginalNovels();
  const library = await db.select().from(novels);
  const settings = await getOrCreateUserSettings();
  const initialNovels = library.filter((novel) => {
    if (settings.contentType === "novels" && novel.type === "Фанфик") return false;
    if (settings.contentType === "fanfiction" && novel.type !== "Фанфик") return false;
    if (settings.adultContent === "hide" && novel.ageRating === "18+") return false;
    if (settings.adultContent === "only" && novel.ageRating !== "18+") return false;
    return true;
  });

  return (
    <Suspense
      fallback={
        <div className="max-w-7xl mx-auto px-4 py-12 text-center text-slate-400">
          Загрузка каталога ReManga...
        </div>
      }
    >
      <CatalogView initialNovels={initialNovels} />
    </Suspense>
  );
}
