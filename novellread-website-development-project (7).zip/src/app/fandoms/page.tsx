import { FandomsView } from "@/components/FandomsView";

export default function FandomsPage() {
  return <FandomsView />;
}
