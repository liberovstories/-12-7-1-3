import { db } from "./index";
import { novels, chapters, reviews, bookmarks } from "./schema";
import { sql } from "drizzle-orm";

export async function seedDatabase() {
  const existing = await db.select({ count: sql<number>`count(*)` }).from(novels);
  if (Number(existing[0]?.count) > 0) {
    return;
  }

  console.log("Seeding initial novels library...");

  const novelList = [
    {
      slug: "omniscient-readers-viewpoint",
      title: "Точка зрения Всеведущего читателя",
      englishTitle: "Omniscient Reader's Viewpoint",
      originalTitle: "전지적 독자 시점",
      description:
        "«Это развитие событий, которое я знаю». В тот момент, когда он подумал об этом, мир разрушился, и открылся новый сценарий. Единственный читатель веб-романа, который длился более десяти лет, теперь живет в мире апокалиптической истории, где ему предстоит выжить, зная финал этой вселенной до самого конца.",
      coverUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1400&auto=format&fit=crop&q=80",
      rating: 9.8,
      ratingCount: 14200,
      viewsCount: 384000,
      bookmarksCount: 28400,
      chaptersCount: 551,
      country: "Корея",
      type: "Новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "16+",
      releaseYear: 2020,
      author: "Sing-Shong",
      translator: "Rainbow Turtle & NovellRead",
      fandom: null,
      genres: ["Фэнтези", "Приключения", "Боевик", "Психология", "Драма"],
      tags: ["Система", "Апокалипсис", "Умный ГГ", "Выживание", "Боги", "Антигерой"],
      isFeatured: true,
      isRecommendation: true,
    },
    {
      slug: "running-away-from-the-hero",
      title: "Убегая от героя!",
      englishTitle: "Running Away From The Hero! (Remake)",
      originalTitle: "용사에게서 도망치는 법",
      description:
        "История про человека с нестандартным взглядом на мир, волею судьбы ставшего инструктором в Имперской Организации Зла. Его ученики — будущие злодеи и герои, а его единственная цель — спокойно дожить до пенсии, избегая безумных учеников и праведных героев.",
      coverUrl: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&auto=format&fit=crop&q=80",
      rating: 9.6,
      ratingCount: 8400,
      viewsCount: 195000,
      bookmarksCount: 16800,
      chaptersCount: 340,
      country: "Корея",
      type: "Новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2021,
      author: "Carne",
      translator: "NovellRead Team",
      fandom: null,
      genres: ["Фэнтези", "Комедия", "Приключения", "Юмор"],
      tags: ["Антигерой", "Умный ГГ", "Академия", "Ирония", "Магия"],
      isFeatured: true,
      isRecommendation: true,
    },
    {
      slug: "warlock-of-the-magus-world",
      title: "Чернокнижник в Мире Магов",
      englishTitle: "Warlock of the Magus World",
      originalTitle: "巫界术士",
      description:
        "Что происходит, когда ученый из высокоразвитого мира перевоплощается в мире магии и монстров? Лейлин перерождается в теле молодого дворянина, обладая чипом искусственного интеллекта ИИ БиоЧИП. Холодный расчет, жажда знаний и безжалостный путь к высшему могуществу.",
      coverUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1519074069444-1ba4ea16e6f0?w=1400&auto=format&fit=crop&q=80",
      rating: 9.5,
      ratingCount: 19800,
      viewsCount: 520000,
      bookmarksCount: 34100,
      chaptersCount: 1200,
      country: "Китай",
      type: "Веб-новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "18+",
      releaseYear: 2018,
      author: "Plagiarist (Вэнь Чао Гун)",
      translator: "Dark Magus TL",
      fandom: null,
      genres: ["Фэнтези", "Боевик", "Приключения", "Сверхъестественное", "Триллер"],
      tags: ["Культивация", "Система", "Антигерой", "Умный ГГ", "Магия", "Хладнокровный ГГ"],
      isFeatured: true,
      isRecommendation: true,
    },
    {
      slug: "the-legendary-mechanic",
      title: "Легендарный механик",
      englishTitle: "The Legendary Mechanic",
      originalTitle: "超神机械师",
      description:
        "Хань Сяо был опытным прокачивателем аккаунтов в популярной межзвездной игре. Неожиданно проснувшись, он обнаруживает себя запертым в теле подопытного киборга в исследовательской лаборатории внутри самой игры, за десять лет до открытия официальных серверов!",
      coverUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1400&auto=format&fit=crop&q=80",
      rating: 9.6,
      ratingCount: 16700,
      viewsCount: 460000,
      bookmarksCount: 31200,
      chaptersCount: 1463,
      country: "Китай",
      type: "Веб-новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "16+",
      releaseYear: 2019,
      author: "Chocolion",
      translator: "MechEmpire",
      fandom: null,
      genres: ["Научная фантастика", "Боевик", "ЛитРПГ", "Комедия", "Приключения"],
      tags: ["Игровой элемент", "Система", "Непобедимый ГГ", "Космос", "Крафтинг", "Технологии"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "death-is-the-only-ending-for-the-villainess",
      title: "Смерть — единственный конец для злодейки",
      englishTitle: "Villains Are Destined to Die",
      originalTitle: "악역의 엔딩은 죽음뿐",
      description:
        "Я перевоплотилась в главную злодейку сложнейшего отомэ-симулятора свиданий в режиме хардкор! Независимо от того, какой выбор я сделаю, меня ждет смерть от руки одного из мужских персонажей. Чтобы выжить, мне нужно завоевать благосклонность хотя бы одного из них.",
      coverUrl: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=1400&auto=format&fit=crop&q=80",
      rating: 9.7,
      ratingCount: 18900,
      viewsCount: 410000,
      bookmarksCount: 39500,
      chaptersCount: 231,
      country: "Корея",
      type: "Новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "16+",
      releaseYear: 2020,
      author: "Gwon Gyeoeul",
      translator: "Imperial Garden",
      fandom: null,
      genres: ["Романтика", "Фэнтези", "Драма", "Психология"],
      tags: ["Перерождение", "Попаданец", "Дворянство", "Выживание", "Умная героиня"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "solo-leveling",
      title: "Поднятие уровня в одиночку",
      englishTitle: "Solo Leveling / Only I Level Up",
      originalTitle: "나 혼자만 레벨업",
      description:
        "10 лет назад открылись «Врата», соединившие реальный мир со смертоносными подземельями. Сон Джин-Ву был известен как самый слабый охотник E-ранга. Находясь на грани смерти в двойном подземелье, он неожиданно получает доступ к уникальной Системе Игрока, позволяющей повышать уровень без ограничений.",
      coverUrl: "https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&auto=format&fit=crop&q=80",
      rating: 9.8,
      ratingCount: 32000,
      viewsCount: 890000,
      bookmarksCount: 65000,
      chaptersCount: 270,
      country: "Корея",
      type: "Новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "16+",
      releaseYear: 2018,
      author: "Chugong",
      translator: "D&C Media / Rulate Team",
      fandom: null,
      genres: ["Боевик", "Фэнтези", "Приключения", "Сверхъестественное"],
      tags: ["Система", "Непобедимый ГГ", "Прокачка", "Гильдии", "Магия", "Охотники"],
      isFeatured: true,
      isRecommendation: true,
    },
    {
      slug: "harry-potter-rebirth-as-sirius-black",
      title: "Гарри Поттер: Перерождение в Сириуса Блэка",
      englishTitle: "Harry Potter: Rebirth into Sirius Black",
      originalTitle: "Harry Potter: The Black Heir",
      description:
        "Наш современник, досконально знающий канон и тайны магии, оказывается в теле молодого Сириуса Блэка в преддверии Первой Магической Войны. Древняя магия рода Блэк, родовые проклятия и исправление былых ошибок. Судьба Хогвартса и всего волшебного мира изменится навсегда.",
      coverUrl: "https://images.unsplash.com/photo-1532012164546-f432f2e3edd4?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1514894780887-121968d00567?w=1400&auto=format&fit=crop&q=80",
      rating: 9.3,
      ratingCount: 6200,
      viewsCount: 145000,
      bookmarksCount: 11200,
      chaptersCount: 185,
      country: "СНГ",
      type: "Фанфик",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2023,
      author: "BlackCrown",
      translator: "Авторский",
      fandom: "Гарри Поттер",
      genres: ["Фэнтези", "Приключения", "Драма", "Мистика"],
      tags: ["Магия", "Попаданец", "Академия", "Дворянство", "Умный ГГ"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "writer-regression-copy-future-masterpieces",
      title: "Регрессия Писателя: Я скопирую все шедевры будущего!",
      englishTitle: "Writer's Regression: I Will Copy Future Masterpieces",
      originalTitle: "작가의 회귀: 미래의 명작들을 베끼겠다",
      description:
        "Провалившийся бесталанный писатель возвращается на двадцать лет назад с полным архивом бестселлеров, сценариев и шедевров будущего в своей памяти. Он намерен стать величайшим культурным титаном XXI века и покорить литературный Олимп.",
      coverUrl: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=1400&auto=format&fit=crop&q=80",
      rating: 9.4,
      ratingCount: 5100,
      viewsCount: 120000,
      bookmarksCount: 9400,
      chaptersCount: 210,
      country: "Корея",
      type: "Новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2022,
      author: "Kim Mun-Hak",
      translator: "NovellRead Trans",
      fandom: null,
      genres: ["Повседневность", "Драма", "Комедия", "Психология"],
      tags: ["Перерождение", "Умный ГГ", "Шоу-бизнес", "Современность"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "high-ranking-undead-suicidal-tendencies",
      title: "Высокоранговая нежить с суицидальными наклонностями",
      englishTitle: "High-Rank Undead With Suicidal Tendencies",
      originalTitle: "自殺志願の最上位アンデッド",
      description:
        "Он переродился сильнейшим Владыкой Нежити десятого ранга с бесконечной регенерацией и абсолютным иммунитетом. Проблема лишь в том, что он отчаянно хочет спокойно уйти на покой, однако каждый его шаг лишь укрепляет культ его величия среди смертных и богов.",
      coverUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&auto=format&fit=crop&q=80",
      rating: 9.1,
      ratingCount: 4300,
      viewsCount: 98000,
      bookmarksCount: 7800,
      chaptersCount: 160,
      country: "Япония",
      type: "Ранобэ",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2023,
      author: "Shironeko",
      translator: "AnimeLover TL",
      fandom: null,
      genres: ["Фэнтези", "Комедия", "Исекай", "Сверхъестественное"],
      tags: ["Непобедимый ГГ", "Ирония", "Демоны", "Владыка подземелий"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "my-magical-system",
      title: "Моя Магическая Система",
      englishTitle: "My Magical System in a Fantasy World",
      originalTitle: "My Magical System",
      description:
        "Обычный парень попадает в мрачный мир магии меча и волшебства, получая интерфейс системного помощника с неограниченным древом навыков. Пока другие маги тратят десятилетия на изучение одного заклинания, он осваивает высшие круги магии за считанные секунды.",
      coverUrl: "https://images.unsplash.com/photo-1514539079130-25950c84af65?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&auto=format&fit=crop&q=80",
      rating: 8.8,
      ratingCount: 3800,
      viewsCount: 82000,
      bookmarksCount: 6500,
      chaptersCount: 410,
      country: "Запад",
      type: "Веб-новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2022,
      author: "ArcaneMaster",
      translator: "NovellRead TL",
      fandom: null,
      genres: ["Фэнтези", "Боевик", "Приключения", "Романтика"],
      tags: ["Система", "Магия", "Прокачка", "Попаданец"],
      isFeatured: false,
      isRecommendation: false,
    },
    {
      slug: "paradise-among-nightmares",
      title: "Рай среди Кошмаров",
      englishTitle: "Paradise Among Nightmares",
      originalTitle: "Рай среди Кошмаров",
      description:
        "Земля превратилась в полигон потусторонних сущностей. Каждый день человечество сталкивается с лабиринтами кошмаров, где любая ошибка стоит жизни. Главный герой открывает в себе дар поглощать кошмары и превращать страх противников в чистую силу.",
      coverUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1400&auto=format&fit=crop&q=80",
      rating: 9.0,
      ratingCount: 2900,
      viewsCount: 71000,
      bookmarksCount: 5300,
      chaptersCount: 320,
      country: "СНГ",
      type: "Авторский",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "18+",
      releaseYear: 2024,
      author: "Артем Воронов",
      translator: "Авторский",
      fandom: null,
      genres: ["Ужасы", "Триллер", "Боевик", "Хоррор", "Мистика"],
      tags: ["Апокалипсис", "Выживание", "Антигерой", "Психология"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "martial-peak",
      title: "Пик боевых искусств",
      englishTitle: "Martial Peak",
      originalTitle: "武炼巅峰",
      description:
        "Вершина боевых искусств — это одинокое и нескончаемое путешествие. Ян Кай был скромным уборщиком в секте Линсяо. Однажды он случайно находит Черную Книгу без слов, которая открывает ему путь к абсолютному восхождению на вершину мироздания.",
      coverUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1400&auto=format&fit=crop&q=80",
      rating: 9.2,
      ratingCount: 24500,
      viewsCount: 1100000,
      bookmarksCount: 42000,
      chaptersCount: 6000,
      country: "Китай",
      type: "Веб-новелла",
      status: "Завершен",
      translationStatus: "Завершен",
      ageRating: "16+",
      releaseYear: 2017,
      author: "Momo (Момо)",
      translator: "Martial Scan",
      fandom: null,
      genres: ["Боевые искусства", "Сянься", "Уся", "Боевик", "Гарем"],
      tags: ["Культивация", "Бессмертие", "Война кланов", "Прокачка"],
      isFeatured: false,
      isRecommendation: false,
    },
    {
      slug: "tales-of-demons-and-gods",
      title: "Сказания о демонах и богах",
      englishTitle: "Tales of Demons and Gods",
      originalTitle: "妖神记",
      description:
        "Не Ли, сильнейший Заклинатель Демонов, пал в смертельной битве с Мудрецом-Императором. Однако благодаря таинственной Книге Пространства и Времени его душа переносится назад в тринадцатилетний возраст. Зная будущее, он намерен защитить любимых и отомстить за разрушенный родной город.",
      coverUrl: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400&auto=format&fit=crop&q=80",
      rating: 9.3,
      ratingCount: 21000,
      viewsCount: 780000,
      bookmarksCount: 38000,
      chaptersCount: 496,
      country: "Китай",
      type: "Веб-новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "12+",
      releaseYear: 2016,
      author: "Mad Snail (Бешеный Улитка)",
      translator: "TDG Team",
      fandom: null,
      genres: ["Сянься", "Боевые искусства", "Фэнтези", "Приключения", "Гарем"],
      tags: ["Перерождение", "Умный ГГ", "Культивация", "Академия", "Боги"],
      isFeatured: false,
      isRecommendation: true,
    },
    {
      slug: "marvel-warcraft-crossing",
      title: "Marvel: Пересечение миров с навыками из Warcraft",
      englishTitle: "Marvel: Crossing Worlds with Warcraft Skills",
      originalTitle: "漫威：带着魔兽技能穿越",
      description:
        "Главный герой попадает во вселенную Марвел прямо в разгар событий Первого Мстителя, обладая способностями Паладина Света и Чернокнижника Скверны из мира Warcraft. Тони Старк, Щ.И.Т. и Танос будут вынуждены считаться с силой Азерота.",
      coverUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1400&auto=format&fit=crop&q=80",
      rating: 9.2,
      ratingCount: 3900,
      viewsCount: 94000,
      bookmarksCount: 7200,
      chaptersCount: 220,
      country: "Китай",
      type: "Фанфик",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2023,
      author: "AzerothHero",
      translator: "MarvelNovels",
      fandom: "Marvel Comics",
      genres: ["Фэнтези", "Боевик", "Приключения", "Комедия"],
      tags: ["Попаданец", "Супергерои", "Магия", "Непобедимый ГГ"],
      isFeatured: false,
      isRecommendation: false,
    },
    {
      slug: "naruto-shadow-of-hokage",
      title: "Наруто: Тень Хокаге",
      englishTitle: "Naruto: The Shadow of Hokage",
      originalTitle: "火影之暗影火影",
      description:
        "Переродившись сиротой в Конохе во время Второй Мировой Войны Шиноби, он понимает, что Воля Огня — это не только красивые речи, но и суровая борьба за выживание в тени. Овладев редким стилем клинка и контролем чакры, он строит свою тайную империю.",
      coverUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1400&auto=format&fit=crop&q=80",
      rating: 9.1,
      ratingCount: 4700,
      viewsCount: 112000,
      bookmarksCount: 8900,
      chaptersCount: 140,
      country: "СНГ",
      type: "Фанфик",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2023,
      author: "ShinobiMaster",
      translator: "Авторский",
      fandom: "Наруто",
      genres: ["Боевик", "Приключения", "Драма", "Боевые искусства"],
      tags: ["Шиноби", "Попаданец", "Ниндзя", "Война кланов", "Умный ГГ"],
      isFeatured: false,
      isRecommendation: false,
    },
  ];

  // Insert novels
  const insertedNovels = await db.insert(novels).values(novelList).returning();
  console.log(`Inserted ${insertedNovels.length} novels`);

  // Insert chapters for novels
  for (const novel of insertedNovels) {
    const chaptersData = [
      {
        novelId: novel.id,
        volumeNumber: 1,
        chapterNumber: 1,
        title: "Глава 1: Пролог. Начало неизбежного",
        content: `Холодный осенний ветер хлестал по стеклам вагонов метро. Часы на дисплее смартфона показывали 18:55.\n\n«Это последнее обновление». Сообщение от автора романа висело в верхней части экрана. Десять лет ежедневного чтения, тысячи глав, миллионы строк текста — и всё это ради одного-единственного читателя.\n\n— Неужели это действительно конец? — прошептал я себе под нос, листая последние строки эпилога.\n\nВнезапно свет в вагоне мигнул. Поезд со скрежетом затормозил прямо посреди темного туннеля. Люди вокруг начали тревожно переговариваться, проверяя свои телефоны.\n\n«Сеть пропала...» — услышал я голос женщины рядом.\n\nИ тут раздался звук, словно гигантский стеклянный купол треснул над всем городом. В воздухе перед каждым пассажиром вспыхнуло полупрозрачное синее системное окно:\n\n[Основной сценарий № 1 активирован.]\n[Время до начала теста: 10 минут.]\n[Условие выживания: Докажите право на существование.]\n\nМое сердце пропустило удар. Я знал эти слова. Я читал их сотни раз. Мир, который существовал лишь в строках забытого веб-романа, стал реальностью...`,
        wordsCount: 2850,
        viewsCount: 4200,
        isFree: true,
      },
      {
        novelId: novel.id,
        volumeNumber: 1,
        chapterNumber: 2,
        title: "Глава 2: Правила игры",
        content: `В вагоне воцарилась гробовая тишина, которую через мгновение сменил нарастающий шквал паники.\n\n— Что это за шутки?! Кто вывел это на проектор?!\n— Выпустите нас отсюда!\n\nЛюди колотили кулаками по заблокированным дверям, пытаясь разбить пуленепробиваемые стекла. Но все было бесполезно. Прямо посреди вагона из сгустка черного дыма возникло маленькое парящее существо с белой шерсткой и маленькими рожками.\n\n[Доккэби появился в локации Сеул, станция Оксу.]\n\n— А-ха-ха! — раздался писклявый детский голос, разнесшийся прямо в сознании каждого. — Ну что за примитивные формы жизни! Вы думаете, это розыгрыш? Бесплатный период вашего жалкого мира подошел к концу!\n\nСущество взмахнуло крошечной лапкой, и таймер в окне системы начал обратный отсчет: 09:59... 09:58...\n\nЯ медленно поднялся со своего места, сжимая в руке телефон. В нем все еще хранился текстовый файл с полным описанием всех будущих катастроф, слабостей монстров и секретов созвездий.\n\n«Я единственный, кто знает, как выжить в этой бойне».`,
        wordsCount: 3100,
        viewsCount: 3800,
        isFree: true,
      },
      {
        novelId: novel.id,
        volumeNumber: 1,
        chapterNumber: 3,
        title: "Глава 3: Первый выбор",
        content: `Крики и плач заглушали гудение системного таймера. До окончания первого сценария оставалось всего три минуты.\n\n[Текущее условие: Убейте хотя бы одно живое существо.]\n\nМужчина крепкого телосложения в дорогом костюме схватил за воротник молодого парня. Паника превращала людей в зверей быстрее, чем любой вирус.\n\n— Стой! — крикнул я, привлекая к себе внимание всего вагона.\n\nЯ сделал шаг вперед. В углу сидела старушка с плетеной сеткой, полной речных кузнечиков и мелких насекомых, которых она везла для своих птиц.\n\n— «Живое существо»... — произнес я спокойно, глядя в системное окно. — Система никогда не требовала именно человеческой жизни.\n\nДоккэби замер в воздухе, его рот приоткрылся от изумления. Мои пальцы сомкнулись на сачке с кузнечиками...`,
        wordsCount: 2950,
        viewsCount: 3500,
        isFree: false,
        price: 5,
      },
    ];

    await db.insert(chapters).values(chaptersData);

    // Insert reviews
    await db.insert(reviews).values([
      {
        novelId: novel.id,
        userName: "DokjaFan",
        userAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Dokja",
        rating: 10,
        text: "Шедевр мировой новеллистики! Сюжет держит в напряжении с первой до последней страницы. Огромная благодарность переводчикам за качественную адаптацию!",
        likesCount: 142,
      },
      {
        novelId: novel.id,
        userName: "ShadowReader",
        userAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=Shadow",
        rating: 9,
        text: "Очень круто проработанные персонажи и логика мира. Читается на одном дыхании, советую всем любителям жанра!",
        likesCount: 88,
      },
    ]);
  }

  // Insert sample bookmarks
  if (insertedNovels.length >= 3) {
    await db.insert(bookmarks).values([
      {
        userId: "default_user",
        novelId: insertedNovels[0].id,
        status: "reading",
        lastReadChapter: 3,
      },
      {
        userId: "default_user",
        novelId: insertedNovels[1].id,
        status: "favorite",
        lastReadChapter: 1,
      },
      {
        userId: "default_user",
        novelId: insertedNovels[2].id,
        status: "planned",
        lastReadChapter: 1,
      },
    ]);
  }

  console.log("Database seeded successfully!");
}

/**
 * Fully original NovellRead-exclusive novels that are never paywalled.
 * Every title, synopsis, and chapter below is original writing created
 * specifically for this project (not a translation or excerpt of any
 * existing published work), so the whole catalog entry can be safely
 * marked `fullyFree: true` and every chapter is `isFree: true`.
 */
export async function seedFreeOriginalNovels() {
  const existingSlugs = await db
    .select({ slug: novels.slug })
    .from(novels);
  const knownSlugs = new Set(existingSlugs.map((n) => n.slug));

  interface FreeNovelChapter {
    volumeNumber: number;
    chapterNumber: number;
    title: string;
    content: string;
    wordsCount: number;
  }

  interface FreeNovelSeed {
    slug: string;
    title: string;
    englishTitle: string | null;
    originalTitle: string | null;
    description: string;
    coverUrl: string;
    bannerUrl: string;
    rating: number;
    ratingCount: number;
    viewsCount: number;
    bookmarksCount: number;
    country: string;
    type: string;
    status: string;
    translationStatus: string;
    ageRating: string;
    releaseYear: number;
    author: string;
    genres: string[];
    tags: string[];
    isRecommendation: boolean;
    chapters: FreeNovelChapter[];
  }

  const freeNovels: FreeNovelSeed[] = [
    {
      slug: "sword-of-a-thousand-fractures",
      title: "Меч Тысячи Изломов",
      englishTitle: null,
      originalTitle: null,
      description:
        "Ло Цзиньхэ был лучшим клинком секты Синего Обрыва, пока предательство учителя не оставило от его меча и его тела лишь осколки. Спустя семь лет отшельничества в Ущелье Сломанных Клинков он возвращается в мир боевых искусств не мастером одной школы, а хранителем тысячи изломанных стилей, каждый из которых хранит память погибшего воина. Эксклюзивная авторская история о цене силы, написанная специально для NovellRead — навсегда бесплатна для всех читателей.",
      coverUrl:
        "https://images.pexels.com/photos/12461376/pexels-photo-12461376.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/12461376/pexels-photo-12461376.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 9.1,
      ratingCount: 640,
      viewsCount: 21000,
      bookmarksCount: 1900,
      country: "Китай",
      type: "Веб-новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2024,
      author: "Тень Бамбука (NovellRead Originals)",
      genres: ["Уся", "Боевые искусства", "Приключения", "Драма"],
      tags: ["Культивация", "Месть", "Прокачка", "Умный ГГ"],
      isRecommendation: true,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Ущелье Сломанных Клинков",
          content:
            "Семь лет в ущелье не притупили боль — они лишь научили Ло Цзиньхэ носить её так же спокойно, как носят старый шрам.\n\nКаждое утро он поднимался до рассвета и спускался к ручью, где среди камней ржавели сотни обломков мечей — всё, что осталось от воинов, приходивших сюда умирать в одиночестве. Местные называли это место Ущельем Сломанных Клинков и обходили стороной, боясь духов.\n\nЛо Цзиньхэ не боялся духов. Он боялся забыть.\n\n— Учитель Сюань предал секту Синего Обрыва, — прошептал он в пустоту, повторяя эти слова, как молитву, которую нельзя прерывать. — Он предал меня. И он всё ещё жив.\n\nОн опустился на колени перед грудой обломков и коснулся ладонью самого большого осколка — некогда это был его собственный меч, «Утренний Иней», разрубленный одним ударом человека, которого он называл отцом по духу.\n\nОсколок вдруг дрогнул под пальцами, будто в ответ на прикосновение.\n\n«Ты наконец готов услышать нас?» — раздался беззвучный голос в его сознании, и тысяча других голосов зашептали следом.",
          wordsCount: 320,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Тысяча голосов в стали",
          content:
            "Голоса не были кошмаром — они были架 памятью. Каждый обломок в ущелье принадлежал воину, погибшему со своим стилем недосказанным, и все эти годы Ло Цзиньхэ невольно впитывал их последние вздохи, сам того не понимая.\n\n«Меня звали Дуань Хэ, — произнёс первый голос, принадлежавший ржавому клинку с узором ивовых листьев. — Я не успел закончить свою технику „Плач Ивы над Рекой“. Возьми её, раз уж мне больше некому передать».\n\nПеред глазами Ло Цзиньхэ развернулась смутная, будто сквозь толщу воды, картина: движения клинка, дыхание, ритм шагов. Тело откликнулось прежде разума — рука сама вычертила в воздухе плавную дугу.\n\n— Это... — выдохнул он, чувствуя, как что-то холодное и правильное укладывается в его мышцы.\n\nОн понял очень быстро: в этом ущелье не сотня забытых мечей. Здесь тысяча незаконченных судеб, и каждая готова была продолжиться в его руках — если он согласится стать их последним движением.\n\n— Хорошо, — сказал он вслух, поднимаясь. — Я стану клинком, который закончит то, что не успели вы все. А потом я найду Сюаня.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Возвращение без имени",
          content:
            "Городок у подножия гор не изменился за семь лет: та же покосившаяся вывеска чайного дома, тот же крикливый зазывала у ворот. Изменился только человек, вошедший в его ворота с обмотанным тряпками свёртком обломков за спиной.\n\n— Эй, путник, мечи в ремонт? — окликнул его кузнец, завидев характерную ношу.\n\n— Нет, — коротко ответил Ло Цзиньхэ. — Эти мечи чинят меня.\n\nОн прошёл мимо, ловя на себе безразличные взгляды: никто не узнавал в исхудавшем страннике с сединой на висках бывшую гордость секты Синего Обрыва. Это было даже к лучшему — тем неожиданнее окажется его первый удар.\n\nНа доске объявлений у постоялого двора красовалось свежее объявление, выведенное уверенной рукой: турнир боевых искусств в честь тридцатилетия главенства секты Синего Обрыва, судить который будет лично старейшина Сюань.\n\nЛо Цзиньхэ впервые за семь лет позволил себе улыбнуться — не радостно, а так, как улыбается клинок перед тем, как его извлекут из ножен.\n\n— Тридцать лет, значит, — тихо произнёс он. — Что ж, будет мне достойным местом для тысячи первого излома.",
          wordsCount: 300,
        },
      ],
    },
    {
      slug: "chronicles-of-the-empty-throne",
      title: "Хроники Пустого Трона",
      englishTitle: null,
      originalTitle: null,
      description:
        "Когда королевство Ардвен осталось без наследника, древний Трон Основателей сам выбрал себе носителя — простого архивариуса Кая Верна, никогда не державшего в руках ничего тяжелее пера. Вместе с короной он получает Систему Регента: интерфейс, который превращает управление государством в игру с реальными ставками, где каждое неверное решение стоит человеческих жизней. Полностью оригинальная история о цене власти, написанная эксклюзивно для NovellRead.",
      coverUrl:
        "https://images.pexels.com/photos/39238586/pexels-photo-39238586.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/39238586/pexels-photo-39238586.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 8.9,
      ratingCount: 410,
      viewsCount: 15400,
      bookmarksCount: 1320,
      country: "Запад",
      type: "Веб-новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "12+",
      releaseYear: 2025,
      author: "Артём Северин (NovellRead Originals)",
      genres: ["Фэнтези", "ЛитРПГ", "Приключения", "Драма"],
      tags: ["Система", "Прокачка", "Попаданец", "Дворянство"],
      isRecommendation: true,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Архивариус на пустом троне",
          content:
            "Кай Верн провёл в королевском архиве больше времени, чем во сне, но даже он не ожидал, что однажды его туда вызовет не заведующий, а сам Трон Основателей.\n\nЗал заседаний гудел от голосов вельмож, требовавших назначить нового регента после внезапной смерти короля. Никто не заметил, как massive каменный трон в центре зала едва слышно загудел — пока по нему не пробежали светящиеся линии рун, складывающиеся в имя.\n\n«КАЙ. ВЕРН.»\n\nВельможи замолчали разом. Кай, стоявший у дальней стены с ворохом свитков в руках, почувствовал, как холодеет затылок.\n\n— Это какая-то ошибка, — пробормотал он, но трон думал иначе. Невидимая сила потянула его вперёд, мимо ошеломлённых аристократов, прямо к каменному сиденью.\n\nВ момент, когда он коснулся подлокотника, перед глазами вспыхнуло полупрозрачное окно:\n\n[Система Регента активирована.]\n[Носитель: Кай Верн, ранг — Архивариус.]\n[Первое решение необходимо принять в течение 24 часов.]\n\n— Что ж, — выдохнул он, оглядывая разъярённые лица герцогов. — Кажется, у меня появилась новая должность.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Первое решение",
          content:
            "Система оказалась безжалостно честной: она не спрашивала, хочет ли Кай быть правителем, она просто показывала последствия.\n\n[Задача: Пограничная провинция Хальт требует помощи против набегов. Выберите ответ:]\n[А) Отправить армию (стоимость: 4000 золотых, риск открытого конфликта с соседним королевством)]\n[Б) Отправить дипломата (стоимость: 500 золотых, шанс успеха 40%)]\n[В) Игнорировать (провинция потеряна в течение месяца)]\n\nКай перечитал варианты трижды, чувствуя, как вес короны — в переносном смысле, физической короны на нём пока не было — давит сильнее любого фолианта, который он таскал в архиве.\n\n— Система, — тихо спросил он, — а можно четвёртый вариант, которого здесь нет?\n\n[Внимание: нестандартные решения доступны, но не гарантируют предсказуемый результат.]\n\nОн улыбнулся впервые за день. Именно этому его учили годы работы с архивами — искать между строк то, что не увидели составители документа.\n\n— Тогда запишем вариант Г, — сказал он. — Отправить не армию и не дипломата, а торговый караван с оружием в подарок местному ополчению. Пусть Хальт защитит себя сам — а мы просто дадим им повод быть благодарными лично мне, а не совету герцогов.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Совет несогласных",
          content:
            "Герцог Освальд Роэн ворвался в тронный зал прежде, чем стражники успели доложить о госте.\n\n— Архивариус на троне — это оскорбление рода Ардвен! — прогремел он, и его голос эхом разнёсся под сводами. — Совет герцогов не признает твоё регентство!\n\nКай не поднялся навстречу, лишь отложил перо, которым делал пометки в свитке распоряжений.\n\n— Совет герцогов, — спокойно ответил он, — признаёт то, что признаёт Трон Основателей. А трон, если вы заметили, выбрал не благороднейшего из вас, а того, кто читал все ваши прошения последние десять лет и помнит каждое невыполненное обещание.\n\nОсвальд побледнел.\n\n— Например, ваше обещание построить мост через реку Ирн для крестьян провинции Хальт, — продолжил Кай, разворачивая нужный свиток с полки за спиной, — данное четыре года назад и так и не исполненное.\n\n[Новая задача открыта: Заручиться поддержкой хотя бы одного герцога до заседания Совета.]\n[Награда за успех: +15 к Легитимности Трона.]\n\n— Так что, ваша светлость, — Кай слабо, но уверенно улыбнулся, — не хотите ли обсудить, как мы могли бы наконец построить этот мост вместе?",
          wordsCount: 300,
        },
      ],
    },
    {
      slug: "academy-of-iron-vows",
      title: "Академия Стальных Клятв",
      englishTitle: null,
      originalTitle: null,
      description:
        "Юная дочь обедневшего рода Ирэн Кассель поступает в Академию Стальных Клятв не ради магии, а ради клятвенного контракта, способного спасти её семью от долговой ямы. Но академия, где каждый студент связан магической присягой с домом-покровителем, оказывается полем битвы куда более опасным, чем любое сражение — битвы за то, чью клятву предадут первой. Полностью авторская история для NovellRead, доступная бесплатно от первой до последней главы.",
      coverUrl:
        "https://images.pexels.com/photos/8390336/pexels-photo-8390336.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/8390336/pexels-photo-8390336.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 9.0,
      ratingCount: 520,
      viewsCount: 18700,
      bookmarksCount: 1650,
      country: "Корея",
      type: "Новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "12+",
      releaseYear: 2024,
      author: "Ю Ханыль (NovellRead Originals)",
      genres: ["Фэнтези", "Драма", "Романтика", "Школа"],
      tags: ["Академия", "Дворянство", "Умный ГГ"],
      isRecommendation: false,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Контракт вместо стипендии",
          content:
            "Ирэн Кассель стояла перед воротами Академии Стальных Клятв с одним потрёпанным чемоданом и договором, который мог либо спасти её семью, либо разрушить окончательно.\n\n— Абитуриентка Кассель? — окликнул её распорядитель, сверяясь со списком. — Странно видеть здесь кого-то без магического дома-покровителя.\n\n— У меня будет покровитель, — ровным голосом ответила она. — Я подписала клятвенный контракт с домом Виндхарт вчера вечером.\n\nРаспорядитель поднял бровь, но промолчал — все знали, что дом Виндхарт не подписывает контракты с кем попало, тем более с провинциалками без единой капли благородной крови в родословной.\n\nВ актовом зале, где распределяли новобранцев по кураторам, взгляды всех присутствующих скрестились на невысокой девушке в поношенном форменном плаще. Особенно пристально наблюдал за ней высокий юноша с гербом Виндхартов на груди — тот самый наследник дома, чью подпись она получила накануне.\n\n— Значит, это ты, — тихо произнёс он, подходя ближе. — Та, кто заключила со мной контракт, даже не спросив моего разрешения.\n\n— Ваш дворецкий заверил меня, что документы в порядке, — невозмутимо ответила Ирэн. — Если у вас есть претензии, обсудим их после занятий. Сейчас, простите, я не хочу опоздать на распределение.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Клятва, которая слышит ложь",
          content:
            "Магия клятвенного контракта работала просто и жестоко: стоило одной из сторон солгать другой в вопросе, касающемся условий договора, — и печать на запястье вспыхивала болью.\n\nИрэн узнала это на собственном опыте уже на второй день, когда наследник Виндхартов, Даниэль, попытался убедить её расторгнуть контракт «по обоюдному согласию».\n\n— Обоюдному? — она вскинула бровь, чувствуя лёгкое покалывание в запястье — знак, что где-то в его словах пряталась недосказанность. — Вы ведь на самом деле хотите не расторгнуть его, а переписать в свою пользу. Печать не даст соврать.\n\nДаниэль поморщился, будто ему было физически неприятно, что его раскусили так быстро.\n\n— Хорошо, — признал он. — Мой отец узнал о контракте и был в ярости. Он считает, что я опозорил дом, связавшись с кем-то без родословной.\n\n— Тогда у нас с вами общая проблема, — спокойно сказала Ирэн. — Мне тоже несладко придётся, если контракт расторгнут: я потеряю единственный способ оплатить обучение и долг семьи. Так что предлагаю иное: докажем вашему отцу, что этот контракт — не позор, а лучшая сделка, которую он мог получить.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Испытание Первого Курса",
          content:
            "Ежегодное Испытание Первого Курса представляло собой турнир парных дуэлей между студентами, связанными клятвенными контрактами — единственный способ для новичков заявить о себе перед всей академией.\n\n— Мы не готовы, — прямо сказал Даниэль, разглядывая турнирную сетку. — Ты не изучала боевую магию, а я никогда не сражался в паре.\n\n— Тогда придётся победить не силой, — Ирэн разложила на столе схему турнирного поля, испещрённую пометками. — Я три года вела бухгалтерские книги нашего обедневшего поместья, Даниэль. Я умею находить слабое место там, где его никто не ищет.\n\nОна указала на имя их первого противника — Магнус Тор, известный своей грубой силой.\n\n— Его стиль боя завязан на количестве маны, а не на технике, — продолжила она. — Если мы вымотаем его до третьей минуты боя простыми уклонениями, дальше он начнёт совершать ошибки просто от усталости.\n\nДаниэль посмотрел на неё с новым, невольным уважением.\n\n— Ты действительно просчитала это, как бухгалтерский баланс.\n\n— Каждая победа — это ресурс, — Ирэн слабо улыбнулась. — А я, дом Виндхарт, всегда умела считать ресурсы лучше, чем кто-либо в этой академии.",
          wordsCount: 300,
        },
      ],
    },
    {
      slug: "ashes-of-the-second-dawn",
      title: "Пепел Второго Восхода",
      englishTitle: null,
      originalTitle: null,
      description:
        "После падения последнего города-купола бывший спасатель Марк Гордеев ведёт группу выживших через отравленные пеплом равнины в поисках легендарного Второго Восхода — укрытия, о существовании которого известно только по обрывкам старой радиопередачи. Мрачная авторская история о выживании, доверии и цене каждого решения в мире, где спасти всех невозможно. Полностью оригинальный проект NovellRead, бесплатный для всех читателей без исключения.",
      coverUrl:
        "https://images.pexels.com/photos/4874354/pexels-photo-4874354.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/4874354/pexels-photo-4874354.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 8.8,
      ratingCount: 380,
      viewsCount: 13200,
      bookmarksCount: 1100,
      country: "СНГ",
      type: "Авторский",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2025,
      author: "Виктор Морозов (NovellRead Originals)",
      genres: ["Постапокалипсис", "Драма", "Приключения"],
      tags: ["Выживание", "Антигерой", "Предательство"],
      isRecommendation: false,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Последний купол",
          content:
            "Купол над Северным сектором продержался дольше остальных — почти одиннадцать лет с момента Пепельного Заражения. Марк Гордеев помнил день, когда сектор пал, с той отчётливостью, с какой помнят собственную смерть.\n\n— Генератор не выдержит и часа, — прохрипел техник по рации, и в его голосе не было ни капли надежды. — Всем, кто может идти — уходите на восток, к старому вокзалу.\n\nМарк не был техником и не был солдатом. Он был спасателем, чья единственная работа последние годы заключалась в том, чтобы решать, кого можно спасти, а кого — уже нет.\n\nОн обвёл взглядом семерых человек, столпившихся у аварийного выхода: пожилую женщину с сорванным дыханием, парнишку лет четырнадцати, прижимающего к груди рюкзак с чем-то, гремящим как консервные банки, и ещё пятерых незнакомцев, чьи имена он не успел даже спросить.\n\n— Слушайте меня внимательно, — сказал он, стараясь, чтобы голос звучал твёрже, чем он себя чувствовал. — Я слышал старую радиопередачу три дня назад. Обрывок сигнала с позывным «Второй Восход». Координаты я не разобрал полностью, но направление — юго-восток, к Пепельным равнинам.\n\n— Это самоубийство, — процедил один из незнакомцев.\n\n— Оставаться здесь — самоубийство наверняка, — ответил Марк. — А там — просто вероятность. Я выбираю вероятность.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Цена одного решения",
          content:
            "К исходу вторых суток пути через пепельные равнины отряд Марка потерял первого человека — не от когтей мутантов, а от банальной нехватки чистой воды.\n\n— Мы могли бы дойти до старой водокачки за холмом, — тихо сказал парнишка с рюкзаком, которого звали Тимка. — Я видел её на карте моего деда.\n\n— Водокачка на территории Пепельных Псов, — отрезала пожилая женщина, представившаяся как тётя Клава. — Туда лучше не соваться.\n\nМарк присел на корточки рядом с телом умершего от обезвоживания незнакомца, чьё имя он так и не успел узнать, и почувствовал, как знакомая тяжесть возвращается в грудь.\n\n«Ты не мог спасти всех», — говорил ему когда-то наставник по спасательным операциям. Марк тогда не верил в эти слова. Теперь он повторял их себе как единственное оправдание для продолжения пути.\n\n— Идём к водокачке, — решил он наконец. — Рискованно, но у нас нет выбора: без воды до Второго Восхода не дойдёт никто.\n\nТётя Клава посмотрела на него долгим, оценивающим взглядом.\n\n— Ты принимаешь решения быстро для человека, который только что потерял члена группы.\n\n— Я принимаю решения быстро, — тихо ответил Марк, — потому что если я остановлюсь подумать дольше секунды, я усомнюсь во всём, что делаю.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Пепельные Псы",
          content:
            "Водокачка оказалась охраняемой — не механизмами, а людьми в самодельной броне из автомобильных покрышек, называвшими себя Пепельными Псами.\n\n— Территория занята, — вышел вперёд их предводитель, крупный мужчина с шрамом через всё лицо. — Плата за воду — снаряжение или работа. Выбирайте.\n\nМарк почувствовал, как за спиной напряглась вся группа. У них не было ничего лишнего для платы снаряжением — только то, что могло спасти их же жизни дальше в пути.\n\n— Какая работа? — спросил он, выигрывая время.\n\n— Нам нужен кто-то, кто проведёт разведку в старом метро, — предводитель кивнул в сторону тёмного провала неподалёку. — Там завёлся кто-то крупный, мешает нам добывать запчасти. Обычные разведчики не возвращаются.\n\nТимка дёрнул Марка за рукав.\n\n— Это ловушка, — прошептал он. — Они пошлют нас на смерть, а потом просто заберут наши вещи.\n\nМарк знал, что мальчик, скорее всего, прав. Но он также видел, как дрожат от жажды руки тёти Клавы, и понимал: без воды они не переживут даже следующую ночь.\n\n— Хорошо, — произнёс он вслух, встречая взгляд предводителя Псов. — Я пойду один. Но если я вернусь — вы дадите нам вдвое больше воды, чем договаривались, и мы уйдём отсюда без лишних вопросов.\n\nПредводитель усмехнулся, будто услышал именно то, что хотел.\n\n— Смелое условие для человека, идущего на верную смерть.\n\n— Я уже давно не боюсь смерти, — тихо ответил Марк. — Я боюсь только не довести этих людей до Второго Восхода.",
          wordsCount: 340,
        },
      ],
    },
    {
      slug: "the-shadow-between-pages",
      title: "Тень между Страницами",
      englishTitle: null,
      originalTitle: null,
      description:
        "В маленьком книжном магазине города Кицуноэ каждую полночь на определённой странице определённой книги появляется имя человека, которому суждено бесследно исчезнуть до рассвета. Юная работница архива Хана Мидзуки начинает собственное расследование, чтобы остановить цепочку исчезновений — и обнаруживает, что тень, скрывающаяся между страницами, знает её собственное имя лучше, чем она сама. Полностью авторская мистическая история для NovellRead, бесплатная от пролога до финала.",
      coverUrl:
        "https://images.pexels.com/photos/15385911/pexels-photo-15385911.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/15385911/pexels-photo-15385911.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 9.2,
      ratingCount: 470,
      viewsCount: 16800,
      bookmarksCount: 1480,
      country: "Япония",
      type: "Ранобэ",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2025,
      author: "Мидзуно Рэн (NovellRead Originals)",
      genres: ["Мистика", "Детектив", "Психология", "Сверхъестественное"],
      tags: ["Тайна", "Умный ГГ"],
      isRecommendation: true,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Книга, которая пишет имена",
          content:
            "Хана Мидзуки работала в архиве книжного магазина «Кицунэ-до» уже два года и ни разу не замечала ничего необычного — пока однажды в полночь не задержалась дольше обычного, разбирая коробки со старыми изданиями.\n\nНа полке в дальнем углу лежала книга без названия на обложке, покрытая тонким слоем пыли, будто её не касались годами. Хана могла бы поклясться, что раньше её здесь не было.\n\nЧасы на стене пробили полночь. В тот же момент страницы книги сами собой распахнулись, и на пожелтевшем листе бумаги проступили чернильные буквы, будто выведенные невидимой рукой:\n\n«Такэши Оно. Возраст 34 года. Улица Сакура, дом 7».\n\nХана замерла, чувствуя, как по спине пробегает холод. Она узнала это имя — Такэши Оно был постоянным покупателем, заходившим в магазин каждую среду за детективными романами.\n\nНа следующее утро радио сообщило: пропал без вести житель дома 7 по улице Сакура. Комната была заперта изнутри, вещи не тронуты, а сам человек будто растворился в воздухе.\n\nХана посмотрела на таинственную книгу, всё ещё лежащую на её столе.\n\n— Кто ты такая, — прошептала она, — и откуда ты знаешь то, чего не может знать никто?",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Второе имя",
          content:
            "Хана не спала три ночи подряд, наблюдая за таинственной книгой в надежде разгадать закономерность её появления. На четвёртую ночь книга снова раскрылась ровно в полночь.\n\n«Юкио Танака. Возраст 22 года. Кафе „Лунный свет“, угол улиц Хання и Обаке».\n\nНа этот раз Хана не собиралась просто наблюдать. Она схватила пальто и выбежала из магазина в ночную темноту, надеясь успеть предупредить незнакомого ей Юкио Танаку прежде, чем случится то же самое, что и с Такэши Оно.\n\nКафе «Лунный свет» оказалось закрыто, но сквозь витрину она разглядела силуэт молодого человека, убирающего со столов в одиночестве.\n\n— Простите! — Хана застучала в стеклянную дверь. — Пожалуйста, откройте! Ваша жизнь в опасности!\n\nЮкио удивлённо посмотрел на неё, но всё же отпер дверь.\n\n— Вы, наверное, обознались, — растерянно сказал он. — Я не знаю вас.\n\n— Возможно, — Хана перевела дыхание. — Но книга знает ваше имя, и это единственное, что имеет значение сегодня ночью. Пожалуйста, просто останьтесь здесь, при свете, до самого рассвета. Что бы ни случилось — не выходите на улицу и не открывайте дверь никому, кроме меня.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Тень, знающая её имя",
          content:
            "Юкио Танака пережил ту ночь — единственный, насколько было известно Хане, кому удалось избежать участи, предсказанной таинственной книгой. Но радость от маленькой победы длилась недолго.\n\nВернувшись в архив магазина под утро, измотанная бессонной ночью, Хана застала книгу открытой на новой странице. Она приблизилась, ожидая увидеть очередное незнакомое имя.\n\nВместо этого чернила выводили: «Хана Мидзуки. Возраст 24 года. Книжный магазин „Кицунэ-до“».\n\nОна отступила на шаг, чувствуя, как холодеют кончики пальцев.\n\n— Ты знаешь, что я пытаюсь тебя остановить, — прошептала она, обращаясь к книге так, будто та могла её услышать. — Именно поэтому ты выбрала меня следующей?\n\nСтраницы книги вздрогнули, и из них, будто из чернильного тумана, начала проступать полупрозрачная фигура — тень с чертами лица, до странности похожими на отражение самой Ханы в тёмном стекле витрины.\n\n«Ты не пытаешься меня остановить, Хана Мидзуки, — раздался голос, тихий, как шелест страниц. — Ты пытаешься вспомнить, кем была до того, как я забрала твоё первое имя пять лет назад».\n\nХана почувствовала, как земля уходит из-под ног — и поняла, что расследование, начатое три ночи назад, только что стало гораздо более личным, чем она могла себе представить.",
          wordsCount: 320,
        },
      ],
    },
    {
      slug: "wedding-under-the-dragons-curse",
      title: "Свадьба с Драконьим Проклятием",
      englishTitle: null,
      originalTitle: null,
      description:
        "Леди Айлин Морвейн узнаёт о собственной свадьбе с чужеземным принцем за три дня до церемонии — и ещё через час выясняет, что жених приходится наследником рода, на который семь поколений назад легло драконье проклятие: любой, кто искренне полюбит наследника Морвейн, погибает в день его коронации. Оригинальная романтическая фэнтези-история для NovellRead о выборе между чувством и судьбой, полностью бесплатная для всех читателей.",
      coverUrl:
        "https://images.pexels.com/photos/38277136/pexels-photo-38277136.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
      bannerUrl:
        "https://images.pexels.com/photos/38277136/pexels-photo-38277136.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1600",
      rating: 8.9,
      ratingCount: 350,
      viewsCount: 12600,
      bookmarksCount: 1240,
      country: "Запад",
      type: "Западная новелла",
      status: "Онгоинг",
      translationStatus: "Продолжается",
      ageRating: "16+",
      releaseYear: 2025,
      author: "Эвелина Марш (NovellRead Originals)",
      genres: ["Романтика", "Фэнтези", "Драма"],
      tags: ["Драконы", "Дворянство", "Предательство"],
      isRecommendation: false,
      chapters: [
        {
          volumeNumber: 1,
          chapterNumber: 1,
          title: "Глава 1. Свадьба через три дня",
          content:
            "Айлин Морвейн узнала о собственной помолвке из письма, которое отец оставил на её туалетном столике вместо личного разговора.\n\n«Дорогая дочь, — гласило письмо, — через три дня ты станешь женой принца Кэлана Дрейвенхарта. Этот союз спасёт наше герцогство от разорения. Прости меня за поспешность решения — обстоятельства не оставили выбора».\n\nОна перечитала строки трижды, прежде чем гнев сменился холодным расчётом. Дом Дрейвенхарт был известен всему королевству по одной причине — древнему проклятию, наложенному драконом семь поколений назад.\n\n— Служанка, — окликнула она девушку, наводившую порядок в комнате, — что говорят слухи о проклятии Дрейвенхартов?\n\nСлужанка побледнела.\n\n— Говорят, миледи, что всякий, кто искренне полюбит наследника этого рода, не переживёт день его коронации. Дракон забирает сердце любящего человека как плату за нарушенную клятву предка.\n\nАйлин невольно рассмеялась — резко, невесело.\n\n— Что ж, — произнесла она, отбрасывая письмо отца в сторону, — тогда мне повезло больше, чем большинству невест. Я не собираюсь любить своего мужа. Я собираюсь заключить с ним деловое соглашение — и остаться в живых после его коронации.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 2,
          title: "Глава 2. Принц с холодными глазами",
          content:
            "Кэлан Дрейвенхарт встретил свою невесту на ступенях родового замка с выражением лица человека, приговорённого к пожизненному одиночеству, а не к свадьбе.\n\n— Леди Морвейн, — произнёс он, склонив голову ровно настолько, насколько требовал этикет, ни граном больше. — Полагаю, вам уже известны условия нашего... союза.\n\n— Известны, ваше высочество, — Айлин ответила таким же ровным, лишённым эмоций тоном. — Насколько я понимаю, вы предпочли бы, чтобы я испытывала к вам чувства не сильнее вежливого равнодушия.\n\nВ его глазах, холодных, как горное озеро зимой, мелькнуло что-то похожее на удивление.\n\n— Большинство невест на вашем месте плакали бы или умоляли отца расторгнуть помолвку, — заметил он.\n\n— Большинство невест не читали хроник вашего рода настолько внимательно, как я, — Айлин слегка приподняла подбородок. — Я предлагаю вам сделку, принц Дрейвенхарт: мы оба сыграем свои роли безупречно перед двором, но ни один из нас не позволит себе того чувства, которое убивает. Вы получите жену, спасающую политическую репутацию вашего рода, а я — титул, спасающий герцогство моего отца. Никто не пострадает от драконьего проклятия, потому что для этого проклятия попросту не будет пищи.\n\nКэлан долго молчал, разглядывая её с прежней холодностью, но уже с иным, более внимательным интересом.\n\n— Это самое разумное предложение, которое мне делали за двадцать шесть лет жизни, леди Морвейн.",
          wordsCount: 300,
        },
        {
          volumeNumber: 1,
          chapterNumber: 3,
          title: "Глава 3. Трещина в холодном расчёте",
          content:
            "Соглашение работало безупречно ровно два месяца — до вечера, когда на замок Дрейвенхартов напали наёмники, подосланные завистливым кузеном Кэлана, желавшим престола себе.\n\nАйлин, разбуженная звоном стали за дверью, выбежала в коридор в одной ночной сорочке и застала Кэлана, отбивающегося от троих противников сразу, с раной на плече, уже пропитавшей рубашку кровью.\n\nНе раздумывая, она схватила со стены декоративный, но острый парадный меч и бросилась ему на помощь, хотя вся её боевая подготовка ограничивалась уроками фехтования для приличия.\n\n— Уходите, леди Морвейн! — крикнул Кэлан, отражая очередной удар. — Это не входит в условия нашей сделки!\n\n— Мёртвый муж тоже не входит в условия нашей сделки! — выкрикнула она в ответ, парируя выпад одного из наёмников чисто рефлекторно.\n\nКогда стража наконец подоспела и последний нападавший бежал, Кэлан опустился на одно колено от потери крови, и Айлин, забыв обо всех расчётах и холодных соглашениях, упала рядом с ним, зажимая рану дрожащими руками.\n\n— Ты испугалась за меня, — тихо произнёс он, глядя на неё снизу вверх со странным, незнакомым ей самой выражением на лице. — По-настоящему испугалась. Я это почувствовал.\n\nАйлин замерла, осознав вдруг с ледяным ужасом, что двухмесячный холодный расчёт дал первую трещину — а вместе с ней, возможно, пробудилось и древнее проклятие, которого они оба так старательно избегали.",
          wordsCount: 320,
        },
      ],
    },
  ];

  const toInsert = freeNovels.filter((novel) => !knownSlugs.has(novel.slug));

  if (toInsert.length === 0) {
    console.log("Free original novels already present, skipping.");
    return;
  }

  console.log(`Seeding ${toInsert.length} free original NovellRead novels...`);

  for (const novel of toInsert) {
    const inserted = await db
      .insert(novels)
      .values({
        slug: novel.slug,
        title: novel.title,
        englishTitle: novel.englishTitle,
        originalTitle: novel.originalTitle,
        description: novel.description,
        coverUrl: novel.coverUrl,
        bannerUrl: novel.bannerUrl,
        rating: novel.rating,
        ratingCount: novel.ratingCount,
        viewsCount: novel.viewsCount,
        bookmarksCount: novel.bookmarksCount,
        chaptersCount: novel.chapters.length,
        country: novel.country,
        type: novel.type,
        status: novel.status,
        translationStatus: novel.translationStatus,
        ageRating: novel.ageRating,
        releaseYear: novel.releaseYear,
        author: novel.author,
        translator: "NovellRead Originals",
        fandom: null,
        genres: novel.genres,
        tags: novel.tags,
        isFeatured: false,
        isRecommendation: novel.isRecommendation,
        fullyFree: true,
      })
      .returning();

    const novelRow = inserted[0];

    await db.insert(chapters).values(
      novel.chapters.map((chapter) => ({
        novelId: novelRow.id,
        volumeNumber: chapter.volumeNumber,
        chapterNumber: chapter.chapterNumber,
        title: chapter.title,
        content: chapter.content,
        wordsCount: chapter.wordsCount,
        viewsCount: Math.round(novel.viewsCount / novel.chapters.length),
        isFree: true,
        price: 0,
      }))
    );

    await db.insert(reviews).values([
      {
        novelId: novelRow.id,
        userName: "NovellRead_Reader",
        userAvatar: "https://api.dicebear.com/7.x/bottts/svg?seed=OriginalsFan",
        rating: 10,
        text: "Отличная эксклюзивная история, которую больше нигде не найти! Здорово, что она полностью бесплатна.",
        likesCount: 34,
      },
    ]);
  }

  console.log("Free original novels seeded successfully!");
}
