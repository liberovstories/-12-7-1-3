import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const novels = pgTable("novels", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  englishTitle: text("english_title"),
  originalTitle: text("original_title"),
  description: text("description").notNull(),
  coverUrl: text("cover_url").notNull(),
  bannerUrl: text("banner_url"),
  rating: real("rating").default(9.5).notNull(),
  ratingCount: integer("rating_count").default(120).notNull(),
  viewsCount: integer("views_count").default(45000).notNull(),
  bookmarksCount: integer("bookmarks_count").default(1800).notNull(),
  chaptersCount: integer("chapters_count").default(150).notNull(),
  country: text("country").notNull(), // Корея, Китай, Япония, СНГ, Запад
  type: text("type").notNull(), // Новелла, Ранобэ, Веб-новелла, Авторский, Фанфик
  status: text("status").notNull().default("Онгоинг"), // Онгоинг, Завершен, Заморожен
  translationStatus: text("translation_status").notNull().default("Продолжается"), // Продолжается, Завершен, Заброшен
  ageRating: text("age_rating").notNull().default("16+"), // 0+, 12+, 16+, 18+
  releaseYear: integer("release_year").notNull().default(2023),
  author: text("author").notNull().default("Неизвестен"),
  translator: text("translator").notNull().default("NovellRead Team"),
  fandom: text("fandom"), // e.g. "Гарри Поттер", "Наруто", "Marvel"
  genres: jsonb("genres").$type<string[]>().notNull().default([]),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  isFeatured: boolean("is_featured").default(false),
  isRecommendation: boolean("is_recommendation").default(false),
  fullyFree: boolean("fully_free").default(false).notNull(), // true when every chapter is free to read
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chapters = pgTable("chapters", {
  id: serial("id").primaryKey(),
  novelId: integer("novel_id")
    .notNull()
    .references(() => novels.id, { onDelete: "cascade" }),
  volumeNumber: integer("volume_number").default(1).notNull(),
  chapterNumber: real("chapter_number").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  wordsCount: integer("words_count").default(2500).notNull(),
  viewsCount: integer("views_count").default(120).notNull(),
  isFree: boolean("is_free").default(true).notNull(),
  price: integer("price").default(5).notNull(), // coin cost when isFree is false
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chapterComments = pgTable("chapter_comments", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id")
    .notNull()
    .references(() => chapters.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().default("default_user"),
  userName: text("user_name").notNull(),
  userAvatar: text("user_avatar").notNull(),
  text: text("text").notNull(),
  isSpoiler: boolean("is_spoiler").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chapterNotes = pgTable("chapter_notes", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id")
    .notNull()
    .references(() => chapters.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().default("default_user"),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chapterPurchases = pgTable(
  "chapter_purchases",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull().default("default_user"),
    chapterId: integer("chapter_id")
      .notNull()
      .references(() => chapters.id, { onDelete: "cascade" }),
    novelId: integer("novel_id")
      .notNull()
      .references(() => novels.id, { onDelete: "cascade" }),
    pricePaid: integer("price_paid").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    userChapterUnique: uniqueIndex("chapter_purchases_user_chapter_idx").on(
      table.userId,
      table.chapterId
    ),
  })
);

export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("default_user"),
  novelId: integer("novel_id")
    .notNull()
    .references(() => novels.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("reading"), // reading, planned, completed, favorite, dropped
  lastReadChapter: real("last_read_chapter").default(1),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  novelId: integer("novel_id")
    .notNull()
    .references(() => novels.id, { onDelete: "cascade" }),
  userName: text("user_name").notNull(),
  userAvatar: text("user_avatar").notNull(),
  rating: integer("rating").notNull().default(10),
  text: text("text").notNull(),
  likesCount: integer("likes_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const uploadedImages = pgTable("uploaded_images", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("default_user"),
  kind: text("kind").notNull(), // avatar | banner
  mimeType: text("mime_type").notNull(),
  data: text("data").notNull(), // base64-encoded image content
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const creatorRequests = pgTable("creator_requests", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("default_user"),
  kind: text("kind").notNull(), // translation | publication
  title: text("title").notNull(),
  sourceUrl: text("source_url"),
  language: text("language"),
  description: text("description").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique().default("default_user"),
  displayName: text("display_name").notNull().default("Dmitry"),
  username: text("username").notNull().default("dmitry575882"),
  bio: text("bio")
    .notNull()
    .default(
      "Люблю восточные новеллы, умных героев и истории о культивации. Перевожу главы и собираю лучшие произведения в личной библиотеке."
    ),
  avatarUrl: text("avatar_url")
    .notNull()
    .default("https://api.dicebear.com/7.x/bottts/svg?seed=Reader575882"),
  bannerUrl: text("banner_url"),
  email: text("email").notNull().default("reader@novellread.ru"),
  emailVerified: boolean("email_verified").notNull().default(false),
  themeMode: text("theme_mode").notNull().default("dark"),
  colorScheme: text("color_scheme").notNull().default("sakura"),
  contentType: text("content_type").notNull().default("all"),
  adultContent: text("adult_content").notNull().default("show"),
  notificationPreferences: jsonb("notification_preferences")
    .$type<Record<string, boolean>>()
    .notNull()
    .default({
      reading: true,
      planned: true,
      completed: false,
      paused: false,
      dropped: false,
      chaptersAvailable: true,
      likes: true,
      replies: true,
      browserPush: false,
      telegram: false,
    }),
  linkedAccounts: jsonb("linked_accounts")
    .$type<Record<string, boolean>>()
    .notNull()
    .default({ google: false, yandex: false, vk: true, telegram: false }),
  premium: boolean("premium").notNull().default(false),
  privateProfile: boolean("private_profile").notNull().default(false),
  balance: integer("balance").notNull().default(1240),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const novelsRelations = relations(novels, ({ many }) => ({
  chapters: many(chapters),
  bookmarks: many(bookmarks),
  reviews: many(reviews),
}));

export const chaptersRelations = relations(chapters, ({ one, many }) => ({
  novel: one(novels, {
    fields: [chapters.novelId],
    references: [novels.id],
  }),
  comments: many(chapterComments),
  purchases: many(chapterPurchases),
}));

export const chapterCommentsRelations = relations(
  chapterComments,
  ({ one }) => ({
    chapter: one(chapters, {
      fields: [chapterComments.chapterId],
      references: [chapters.id],
    }),
  })
);

export const chapterPurchasesRelations = relations(
  chapterPurchases,
  ({ one }) => ({
    chapter: one(chapters, {
      fields: [chapterPurchases.chapterId],
      references: [chapters.id],
    }),
    novel: one(novels, {
      fields: [chapterPurchases.novelId],
      references: [novels.id],
    }),
  })
);

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  novel: one(novels, {
    fields: [bookmarks.novelId],
    references: [novels.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  novel: one(novels, {
    fields: [reviews.novelId],
    references: [novels.id],
  }),
}));
