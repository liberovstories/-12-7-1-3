import { db } from "@/db";
import { userSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const DEFAULT_USER_ID = "default_user";

export const defaultNotificationPreferences: Record<string, boolean> = {
  reading: true,
  planned: true,
  completed: false,
  paused: false,
  dropped: false,
  chaptersAvailable: true,
  likes: true,
  replies: true,
  browserPush: false,
  telegram: false,
};

export const defaultLinkedAccounts: Record<string, boolean> = {
  google: false,
  yandex: false,
  vk: true,
  telegram: false,
};

export type UserSettingsRow = typeof userSettings.$inferSelect;

export async function getOrCreateUserSettings(
  userId = DEFAULT_USER_ID
): Promise<UserSettingsRow> {
  const existing = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  if (existing[0]) return existing[0];

  const created = await db
    .insert(userSettings)
    .values({
      userId,
      notificationPreferences: defaultNotificationPreferences,
      linkedAccounts: defaultLinkedAccounts,
    })
    .onConflictDoNothing({ target: userSettings.userId })
    .returning();

  if (created[0]) return created[0];

  const concurrent = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  if (!concurrent[0]) {
    throw new Error("Failed to initialize user settings");
  }

  return concurrent[0];
}
