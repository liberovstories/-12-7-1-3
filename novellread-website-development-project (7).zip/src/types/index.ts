export interface Novel {
  id: number;
  slug: string;
  title: string;
  englishTitle?: string | null;
  originalTitle?: string | null;
  description: string;
  coverUrl: string;
  bannerUrl?: string | null;
  rating: number;
  ratingCount: number;
  viewsCount: number;
  bookmarksCount: number;
  chaptersCount: number;
  country: string; // Корея, Китай, Япония, СНГ, Запад
  type: string; // Новелла, Ранобэ, Веб-новелла, Авторский, Фанфик
  status: string; // Онгоинг, Завершен, Заморожен
  translationStatus: string; // Продолжается, Завершен, Заброшен
  ageRating: string; // 0+, 12+, 16+, 18+
  releaseYear: number;
  author: string;
  translator: string;
  fandom?: string | null;
  genres: string[];
  tags: string[];
  isFeatured?: boolean | null;
  isRecommendation?: boolean | null;
  fullyFree?: boolean;
  createdAt?: string | Date;
  updatedAt?: string | Date;
}

export interface Chapter {
  id: number;
  novelId: number;
  volumeNumber: number;
  chapterNumber: number;
  title: string;
  content: string;
  wordsCount: number;
  viewsCount: number;
  isFree: boolean;
  price: number;
  createdAt?: string | Date;
}

export interface ChapterNote {
  id: number;
  chapterId: number;
  userId: string;
  text: string;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface ChapterComment {
  id: number;
  chapterId: number;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  isSpoiler: boolean;
  createdAt: string | Date;
}

export interface Review {
  id: number;
  novelId: number;
  userName: string;
  userAvatar: string;
  rating: number;
  text: string;
  likesCount: number;
  createdAt: string | Date;
}

export type BookmarkStatus =
  | "reading"
  | "planned"
  | "completed"
  | "dropped"
  | "paused"
  | "uninterested"
  | "favorite";

export interface Bookmark {
  id: number;
  userId: string;
  novelId: number;
  status: BookmarkStatus;
  lastReadChapter: number;
  updatedAt: string | Date;
  novel?: Novel;
}

export type SearchCategory =
  | "novels"
  | "teams"
  | "characters"
  | "creators"
  | "users";

export interface SearchDirectoryItem {
  id: string;
  category: Exclude<SearchCategory, "novels">;
  title: string;
  subtitle: string;
  image: string;
  href: string;
}

export interface SearchResponse {
  query: string;
  novels: Novel[];
  teams: SearchDirectoryItem[];
  characters: SearchDirectoryItem[];
  creators: SearchDirectoryItem[];
  users: SearchDirectoryItem[];
  popular: Novel[];
}

export interface CatalogFilters {
  search: string;
  type: string; // "all" or specific type
  country: string; // "all" or specific country
  genres: string[]; // selected genres
  excludeGenres?: string[];
  tags: string[]; // selected tags
  status: string; // "all", "Онгоинг", "Завершен", "Заморожен"
  translationStatus: string; // "all", "Продолжается", "Завершен", "Заброшен"
  ageRating: string; // "all", "0+", "12+", "16+", "18+"
  fullyFree: boolean; // when true, only show novels where every chapter is free
  chaptersRange: string; // "all", "lt50", "50-200", "200-500", "500-1000", "gt1000"
  releaseYear: string; // "all" or year
  minRating: string; // "all", "7", "8", "9", "9.5"
  sortBy: string; // "popularity", "rating", "newest", "updates", "chapters", "alphabet", "views"
}
