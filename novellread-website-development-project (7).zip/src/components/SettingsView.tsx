"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AtSign,
  Bell,
  BookOpen,
  Check,
  Crown,
  Eye,
  EyeOff,
  Filter,
  KeyRound,
  Laptop,
  LockKeyhole,
  Moon,
  Palette,
  Save,
  Send,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Sun,
  UserRound,
} from "lucide-react";
import { updateSiteTheme } from "@/components/ThemeProvider";
import { AvatarPickerModal } from "@/components/AvatarPickerModal";
import { BannerPickerModal } from "@/components/BannerPickerModal";
import { ToggleSwitch } from "@/components/ui/ToggleSwitch";

export type SettingsTab =
  | "profile"
  | "theme"
  | "content"
  | "notifications"
  | "subscription"
  | "security"
  | "privacy";

export interface SettingsData {
  id: number;
  userId: string;
  displayName: string;
  username: string;
  bio: string;
  avatarUrl: string;
  bannerUrl: string | null;
  email: string;
  emailVerified: boolean;
  themeMode: string;
  colorScheme: string;
  contentType: string;
  adultContent: string;
  notificationPreferences: Record<string, boolean>;
  linkedAccounts: Record<string, boolean>;
  premium: boolean;
  privateProfile: boolean;
  createdAt: Date | string;
  updatedAt: Date | string;
}

interface SettingsViewProps {
  initialSettings: SettingsData;
  initialTab: SettingsTab;
}

const navigation: Array<{
  id: SettingsTab;
  label: string;
  icon: typeof UserRound;
}> = [
  { id: "profile", label: "Профиль", icon: UserRound },
  { id: "theme", label: "Тема сайта", icon: Sparkles },
  { id: "content", label: "Фильтр контента", icon: Filter },
  { id: "notifications", label: "Уведомления", icon: Bell },
  { id: "subscription", label: "Подписка", icon: Crown },
  { id: "security", label: "Безопасность и данные", icon: ShieldCheck },
  { id: "privacy", label: "Конфиденциальность", icon: LockKeyhole },
];

const palettes = [
  {
    id: "honey",
    name: "Медовая (по умолчанию)",
    description: "Медовые и оранжевые акценты",
    background: "#22211e",
    panel: "#292825",
    accent: "#db9234",
  },
  {
    id: "book",
    name: "Книжная",
    description: "Кремовые тона старой книги и мягкой сепии",
    background: "#3a3639",
    panel: "#454044",
    accent: "#bd623e",
  },
  {
    id: "amoled",
    name: "AMOLED",
    description: "Чистый чёрный фон для OLED экранов",
    background: "#000000",
    panel: "#0b0b0d",
    accent: "#5d57e6",
  },
  {
    id: "slate",
    name: "Сланцевая",
    description: "Строгие серо-голубые тона в стиле tech",
    background: "#101721",
    panel: "#17212e",
    accent: "#718096",
  },
  {
    id: "lavender",
    name: "Лавандовая",
    description: "Мягкие фиолетовые тона для вечернего чтения",
    background: "#171020",
    panel: "#21172e",
    accent: "#7c3be2",
  },
  {
    id: "sakura",
    name: "Сакура",
    description: "Нежные розовые тона цветущей вишни",
    background: "#170d13",
    panel: "#25171f",
    accent: "#cf3e6b",
  },
  {
    id: "ocean",
    name: "Океаническая",
    description: "Прохладные морские тона для спокойного чтения",
    background: "#06151b",
    panel: "#0c222b",
    accent: "#1683a4",
  },
  {
    id: "sunset",
    name: "Закат",
    description: "Тёплые красно-оранжевые тона заката",
    background: "#1a100b",
    panel: "#291a12",
    accent: "#e64b08",
  },
  {
    id: "forest",
    name: "Лесная",
    description: "Натуральные зелёные тона для комфортного чтения",
    background: "#07160a",
    panel: "#102617",
    accent: "#43af51",
  },
];


function ChoiceButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-xl border px-4 py-2.5 text-xs font-bold transition-colors ${
        active
          ? "settings-accent-bg border-transparent shadow-lg"
          : "border-white/15 bg-transparent text-slate-200 hover:bg-white/5"
      }`}
    >
      {children}
    </button>
  );
}

function SettingRow({
  title,
  description,
  checked,
  onChange,
}: {
  title: string;
  description?: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-5 py-2">
      <div>
        <div className="text-xs font-bold text-slate-100">{title}</div>
        {description && (
          <div className="settings-muted mt-0.5 text-[10px] leading-4">
            {description}
          </div>
        )}
      </div>
      <ToggleSwitch checked={checked} onChange={onChange} label={title} />
    </div>
  );
}

export function SettingsView({
  initialSettings,
  initialTab,
}: SettingsViewProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<SettingsTab>(initialTab);
  const [settings, setSettings] = useState(initialSettings);
  const [savedMessage, setSavedMessage] = useState("");
  const [saving, setSaving] = useState(false);
  const [profileDraft, setProfileDraft] = useState({
    displayName: initialSettings.displayName,
    username: initialSettings.username,
    bio: initialSettings.bio,
    avatarUrl: initialSettings.avatarUrl,
    bannerUrl: initialSettings.bannerUrl,
  });
  const [isAvatarPickerOpen, setIsAvatarPickerOpen] = useState(false);
  const [isBannerPickerOpen, setIsBannerPickerOpen] = useState(false);
  const [editingEmail, setEditingEmail] = useState(false);
  const [emailDraft, setEmailDraft] = useState(initialSettings.email);
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordDraft, setPasswordDraft] = useState({
    current: "",
    next: "",
    repeat: "",
  });
  const [sessions, setSessions] = useState([
    {
      id: "desktop",
      name: "Opera на Windows",
      detail: "IP: 88.119.176.154 · Последняя активность: только что",
      current: true,
      icon: Laptop,
    },
    {
      id: "android",
      name: "Google Chrome на Android",
      detail: "IP: 81.30.112.81 · Последняя активность: 31.08.2026",
      current: false,
      icon: Smartphone,
    },
  ]);

  const showSaved = (message = "Настройки сохранены") => {
    setSavedMessage(message);
    window.setTimeout(() => setSavedMessage(""), 2600);
  };

  const savePatch = async (
    patch: Partial<SettingsData>,
    message = "Настройки сохранены"
  ) => {
    setSettings((current) => ({ ...current, ...patch }));
    setSaving(true);
    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      if (!response.ok) throw new Error("Failed to save settings");
      const data = await response.json();
      setSettings(data.settings);
      showSaved(message);
    } catch {
      setSettings(initialSettings);
      showSaved("Не удалось сохранить изменения");
    } finally {
      setSaving(false);
    }
  };

  const changeTab = (tab: SettingsTab) => {
    setActiveTab(tab);
    router.replace(`/settings?tab=${tab}`, { scroll: false });
  };

  const setNotification = (key: string, value: boolean) => {
    const notificationPreferences = {
      ...settings.notificationPreferences,
      [key]: value,
    };
    void savePatch({ notificationPreferences });
  };

  const setLinkedAccount = (key: string, value: boolean) => {
    const linkedAccounts = { ...settings.linkedAccounts, [key]: value };
    void savePatch(
      { linkedAccounts },
      value ? "Аккаунт привязан" : "Аккаунт отвязан"
    );
  };

  const activeTitle = useMemo(
    () => navigation.find((item) => item.id === activeTab)?.label ?? "Настройки",
    [activeTab]
  );

  const saveProfile = async (event: React.FormEvent) => {
    event.preventDefault();
    await savePatch(profileDraft, "Профиль обновлён");
    window.dispatchEvent(
      new CustomEvent("novellread-profile-change", {
        detail: {
          displayName: profileDraft.displayName,
          username: profileDraft.username,
          avatarUrl: profileDraft.avatarUrl,
        },
      })
    );
  };

  const applyAvatar = async (avatarUrl: string) => {
    setProfileDraft((current) => ({ ...current, avatarUrl }));
    await savePatch({ avatarUrl }, "Аватар обновлён");
    window.dispatchEvent(
      new CustomEvent("novellread-profile-change", {
        detail: {
          displayName: profileDraft.displayName,
          username: profileDraft.username,
          avatarUrl,
        },
      })
    );
  };

  const applyBanner = async (bannerUrl: string) => {
    setProfileDraft((current) => ({ ...current, bannerUrl }));
    await savePatch({ bannerUrl }, "Баннер профиля обновлён");
  };

  const removeBanner = async () => {
    setProfileDraft((current) => ({ ...current, bannerUrl: null }));
    await savePatch({ bannerUrl: null }, "Баннер профиля удалён");
  };

  const saveEmail = async () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailDraft)) {
      showSaved("Введите корректный Email");
      return;
    }
    await savePatch({ email: emailDraft, emailVerified: false }, "Email изменён");
    setEditingEmail(false);
  };

  const savePassword = () => {
    if (passwordDraft.next.length < 8) {
      showSaved("Новый пароль должен содержать минимум 8 символов");
      return;
    }
    if (passwordDraft.next !== passwordDraft.repeat) {
      showSaved("Новые пароли не совпадают");
      return;
    }
    setPasswordDraft({ current: "", next: "", repeat: "" });
    setChangingPassword(false);
    showSaved("Пароль успешно изменён");
  };

  const clearSearchHistory = () => {
    window.localStorage.removeItem("novellread-recent-searches");
    showSaved("История поиска очищена");
  };

  const clearReadingHistory = () => {
    window.localStorage.removeItem("novellread-reading-history");
    showSaved("История чтения очищена");
  };

  return (
    <div className="settings-shell mx-auto min-h-[calc(100vh-64px)] max-w-[930px] px-4 py-8 sm:px-6 lg:py-10">
      <div className="grid items-start gap-7 md:grid-cols-[205px_minmax(0,1fr)]">
        <aside className="md:sticky md:top-24">
          <div className="flex gap-1 overflow-x-auto pb-2 md:flex-col md:overflow-visible md:pb-0">
            {navigation.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => changeTab(item.id)}
                  className={`flex h-10 shrink-0 items-center gap-2.5 rounded-xl border px-3 text-left text-xs font-bold transition-colors md:w-full ${
                    active
                      ? "settings-accent-soft"
                      : "border-transparent text-slate-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </aside>

        <section className="min-w-0">
          {activeTab === "profile" && (
            <form onSubmit={saveProfile}>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Профиль
              </h1>
              <div className="settings-card rounded-2xl border p-5">
                <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={profileDraft.avatarUrl}
                    alt={profileDraft.displayName}
                    className="h-20 w-20 rounded-2xl border-2 object-cover"
                    style={{ borderColor: "var(--primary)" }}
                  />
                  <div>
                    <div className="text-sm font-bold text-slate-100">
                      Аватар профиля
                    </div>
                    <p className="settings-muted mt-1 text-[11px]">
                      Это изображение видно в профиле, комментариях и рецензиях.
                    </p>
                    <button
                      type="button"
                      onClick={() => setIsAvatarPickerOpen(true)}
                      className="settings-accent-soft mt-3 rounded-lg border px-3 py-2 text-xs font-bold"
                    >
                      Изменить аватар
                    </button>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="mb-2 text-sm font-bold text-slate-100">
                    Баннер профиля
                  </div>
                  <p className="settings-muted mb-3 text-[11px]">
                    Фон, который отображается позади аватара и описания на странице профиля.
                  </p>
                  <div
                    className="relative w-full overflow-hidden rounded-xl border border-white/10 bg-[#0b0e14]"
                    style={{ aspectRatio: 16 / 5 }}
                  >
                    {profileDraft.bannerUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={profileDraft.bannerUrl}
                        alt="Баннер профиля"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-[11px] font-semibold text-slate-500">
                        Баннер не выбран
                      </div>
                    )}
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsBannerPickerOpen(true)}
                      className="settings-accent-soft rounded-lg border px-3 py-2 text-xs font-bold"
                    >
                      Изменить баннер
                    </button>
                    {profileDraft.bannerUrl && (
                      <button
                        type="button"
                        onClick={() => void removeBanner()}
                        className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs font-bold text-red-400 hover:bg-red-500/20"
                      >
                        Удалить баннер
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-bold text-slate-200">
                      Отображаемое имя
                    </span>
                    <input
                      value={profileDraft.displayName}
                      onChange={(event) =>
                        setProfileDraft((current) => ({
                          ...current,
                          displayName: event.target.value,
                        }))
                      }
                      maxLength={40}
                      className="settings-panel h-10 w-full rounded-xl border px-3 text-xs text-slate-100 outline-none focus:border-[var(--primary)]"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-bold text-slate-200">
                      Имя пользователя
                    </span>
                    <div className="relative">
                      <AtSign className="settings-muted absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
                      <input
                        value={profileDraft.username}
                        onChange={(event) =>
                          setProfileDraft((current) => ({
                            ...current,
                            username: event.target.value,
                          }))
                        }
                        maxLength={32}
                        className="settings-panel h-10 w-full rounded-xl border pl-8 pr-3 text-xs text-slate-100 outline-none focus:border-[var(--primary)]"
                      />
                    </div>
                  </label>
                </div>

                <label className="mt-4 block">
                  <div className="mb-1.5 flex items-center justify-between gap-3">
                    <span className="text-xs font-bold text-slate-200">
                      Описание профиля
                    </span>
                    <span className="settings-muted text-[10px]">
                      {profileDraft.bio.length}/500
                    </span>
                  </div>
                  <textarea
                    value={profileDraft.bio}
                    onChange={(event) =>
                      setProfileDraft((current) => ({
                        ...current,
                        bio: event.target.value,
                      }))
                    }
                    maxLength={500}
                    rows={5}
                    placeholder="Расскажите другим читателям о себе..."
                    className="settings-panel w-full resize-none rounded-xl border p-3 text-xs leading-5 text-slate-100 outline-none placeholder:text-slate-500 focus:border-[var(--primary)]"
                  />
                  <span className="settings-muted mt-1 block text-[10px]">
                    Описание будет отображаться на вашей странице профиля.
                  </span>
                </label>

                <div className="mt-5 flex justify-end">
                  <button
                    type="submit"
                    disabled={saving}
                    className="settings-accent-bg flex h-10 items-center gap-2 rounded-xl px-5 text-xs font-extrabold shadow-lg disabled:opacity-60"
                  >
                    <Save className="h-4 w-4" />
                    {saving ? "Сохранение..." : "Сохранить профиль"}
                  </button>
                </div>
              </div>
            </form>
          )}

          {activeTab === "theme" && (
            <div>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Режим отображения
              </h1>
              <div className="mb-7 flex gap-2">
                <ChoiceButton
                  active={settings.themeMode === "dark"}
                  onClick={() => {
                    updateSiteTheme({
                      themeMode: "dark",
                      colorScheme: settings.colorScheme,
                    });
                    void savePatch({ themeMode: "dark" });
                  }}
                >
                  <span className="flex items-center gap-2">
                    <Moon className="h-4 w-4" /> Тёмная
                  </span>
                </ChoiceButton>
                <ChoiceButton
                  active={settings.themeMode === "light"}
                  onClick={() => {
                    updateSiteTheme({
                      themeMode: "light",
                      colorScheme: settings.colorScheme,
                    });
                    void savePatch({ themeMode: "light" });
                  }}
                >
                  <span className="flex items-center gap-2">
                    <Sun className="h-4 w-4" /> Светлая
                  </span>
                </ChoiceButton>
              </div>

              <h2 className="text-base font-extrabold text-slate-100">
                Цветовая схема
              </h2>
              <p className="settings-muted mb-3 mt-2 text-[11px]">
                Выберите цветовую палитру, которая будет использоваться для всего сайта
              </p>

              <div className="grid gap-3 sm:grid-cols-2">
                {palettes.map((palette) => {
                  const active = settings.colorScheme === palette.id;
                  return (
                    <button
                      key={palette.id}
                      type="button"
                      onClick={() => {
                        updateSiteTheme({
                          themeMode: settings.themeMode,
                          colorScheme: palette.id,
                        });
                        void savePatch({ colorScheme: palette.id });
                      }}
                      className={`relative h-[112px] overflow-hidden rounded-xl border p-3 text-left transition-all ${
                        active
                          ? "shadow-[0_0_0_1px_var(--primary),0_8px_24px_rgba(0,0,0,0.18)]"
                          : "hover:brightness-110"
                      }`}
                      style={{
                        backgroundColor: palette.background,
                        borderColor: active ? palette.accent : "rgba(255,255,255,.16)",
                      }}
                    >
                      <div className="mb-3 flex items-center gap-2">
                        <span
                          className="h-2.5 w-2.5 rounded-full"
                          style={{ backgroundColor: palette.accent }}
                        />
                        <span className="h-2 w-24 rounded-full bg-white/10" />
                      </div>
                      <div className="text-[11px] font-extrabold text-white">
                        {palette.name}
                      </div>
                      <div className="mt-0.5 text-[9px] text-white/55">
                        {palette.description}
                      </div>
                      <div className="mt-3 space-y-1">
                        <span className="block h-1.5 w-[92%] rounded-full bg-white/12" />
                        <span className="block h-1.5 w-[75%] rounded-full bg-white/10" />
                      </div>
                      <div className="absolute bottom-2.5 left-3 right-3 flex gap-2">
                        <span
                          className="h-5 flex-1 rounded-md border border-white/5"
                          style={{ backgroundColor: palette.panel }}
                        />
                        <span
                          className="h-5 w-11 rounded-md"
                          style={{ backgroundColor: palette.accent }}
                        />
                      </div>
                      {active && (
                        <span
                          className="absolute right-3 top-8 flex h-5 w-5 items-center justify-center rounded-full text-white"
                          style={{ backgroundColor: palette.accent }}
                        >
                          <Check className="h-3 w-3" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === "content" && (
            <div>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Фильтр контента
              </h1>
              <div className="mb-5">
                <div className="settings-muted mb-2 text-xs font-bold">
                  Тип контента
                </div>
                <div className="flex flex-wrap gap-2">
                  <ChoiceButton
                    active={settings.contentType === "all"}
                    onClick={() => void savePatch({ contentType: "all" })}
                  >
                    Новеллы и фанфики
                  </ChoiceButton>
                  <ChoiceButton
                    active={settings.contentType === "novels"}
                    onClick={() => void savePatch({ contentType: "novels" })}
                  >
                    Только новеллы
                  </ChoiceButton>
                  <ChoiceButton
                    active={settings.contentType === "fanfiction"}
                    onClick={() =>
                      void savePatch({ contentType: "fanfiction" })
                    }
                  >
                    Только фанфики
                  </ChoiceButton>
                </div>
              </div>

              <div>
                <div className="settings-muted mb-2 text-xs font-bold">
                  Контент 18+
                </div>
                <div className="flex flex-wrap gap-2">
                  <ChoiceButton
                    active={settings.adultContent === "show"}
                    onClick={() => void savePatch({ adultContent: "show" })}
                  >
                    Показывать
                  </ChoiceButton>
                  <ChoiceButton
                    active={settings.adultContent === "hide"}
                    onClick={() => void savePatch({ adultContent: "hide" })}
                  >
                    Скрывать
                  </ChoiceButton>
                  <ChoiceButton
                    active={settings.adultContent === "only"}
                    onClick={() => void savePatch({ adultContent: "only" })}
                  >
                    Только 18+
                  </ChoiceButton>
                </div>
              </div>
            </div>
          )}

          {activeTab === "notifications" && (
            <div>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Уведомления
              </h1>
              <div className="space-y-3">
                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-1 text-xs font-extrabold text-slate-100">
                    Новые главы
                  </h2>
                  {[
                    ["reading", "Читаю"],
                    ["planned", "В планах"],
                    ["completed", "Прочитано"],
                    ["paused", "Отложено"],
                    ["dropped", "Брошено"],
                  ].map(([key, label]) => (
                    <SettingRow
                      key={key}
                      title={label}
                      checked={Boolean(settings.notificationPreferences[key])}
                      onChange={(value) => setNotification(key, value)}
                    />
                  ))}
                  <div className="mt-1 border-t border-white/10 pt-1">
                    <SettingRow
                      title="Главы стали доступнее"
                      description="Когда главы из этих закладок становятся бесплатными или доступными по подписке"
                      checked={Boolean(
                        settings.notificationPreferences.chaptersAvailable
                      )}
                      onChange={(value) =>
                        setNotification("chaptersAvailable", value)
                      }
                    />
                  </div>
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-1 text-xs font-extrabold text-slate-100">
                    Социальное
                  </h2>
                  <SettingRow
                    title="Лайки"
                    checked={Boolean(settings.notificationPreferences.likes)}
                    onChange={(value) => setNotification("likes", value)}
                  />
                  <SettingRow
                    title="Ответы"
                    checked={Boolean(settings.notificationPreferences.replies)}
                    onChange={(value) => setNotification("replies", value)}
                  />
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-1 text-xs font-extrabold text-slate-100">
                    Каналы доставки
                  </h2>
                  <SettingRow
                    title="Push в браузере"
                    checked={Boolean(
                      settings.notificationPreferences.browserPush
                    )}
                    onChange={(value) => setNotification("browserPush", value)}
                  />
                  <div className="flex items-center justify-between gap-5 py-2">
                    <div>
                      <div className="text-xs font-bold text-slate-100">
                        Telegram
                      </div>
                      <div className="settings-muted mt-0.5 text-[10px]">
                        Привяжите Telegram для получения уведомлений
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        setLinkedAccount(
                          "telegram",
                          !settings.linkedAccounts.telegram
                        )
                      }
                      className="settings-accent-soft rounded-lg border px-3 py-2 text-[10px] font-bold"
                    >
                      {settings.linkedAccounts.telegram
                        ? "Отвязать"
                        : "Привязать"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "subscription" && (
            <div>
              <h1 className="text-lg font-extrabold text-slate-100">
                Подписка
              </h1>
              <p className="settings-muted mb-5 mt-1 text-[11px]">
                Управляйте премиум-доступом, статусом и автоматическими продлениями.
              </p>

              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 p-5 text-white shadow-xl">
                <div className="relative z-10 flex items-start justify-between gap-5">
                  <div>
                    <h2 className="flex items-center gap-2 text-lg font-black">
                      <Crown className="h-5 w-5 fill-white" /> Premium подписка
                    </h2>
                    <p className="mt-1 max-w-md text-[11px] font-semibold text-white/90">
                      Читайте больше и экономьте на покупках. Автопродление можно отменить в любой момент.
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <strong className="text-2xl font-black">99 ₽</strong>
                    <span className="text-xs"> /мес</span>
                    <span className="mt-1 block rounded-full bg-white/20 px-2 py-0.5 text-[9px] font-bold">
                      Популярный выбор
                    </span>
                  </div>
                </div>
                <div className="absolute -right-7 -top-12 h-40 w-40 rounded-full bg-white/10" />
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {[
                  [BookOpen, "Доступ к главам по подписке", "Читайте все платные главы кроме последних"],
                  [Sparkles, "Скидка 20% на покупки", "Экономьте на покупке глав и материалов"],
                  [EyeOff, "Отключение рекламы", "Читайте без отвлечений и перерывов"],
                  [Crown, "Эксклюзивный значок", "Выделяйтесь среди других читателей"],
                ].map(([Icon, title, description]) => {
                  const FeatureIcon = Icon as typeof BookOpen;
                  return (
                    <div
                      key={title as string}
                      className="settings-card flex items-start gap-3 rounded-xl border p-4"
                    >
                      <span className="settings-accent-soft flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border-0">
                        <FeatureIcon className="h-4 w-4" />
                      </span>
                      <div>
                        <div className="text-xs font-extrabold text-slate-100">
                          {title as string}
                        </div>
                        <div className="settings-muted mt-1 text-[10px] leading-4">
                          {description as string}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <p className="settings-muted mt-4 text-center text-[9px] leading-4">
                Нажимая кнопку оформления, вы подтверждаете согласие с условиями использования и правилами автоматического продления подписки.
              </p>
              <div className="mt-3 flex justify-center">
                <button
                  type="button"
                  onClick={() =>
                    void savePatch(
                      { premium: !settings.premium },
                      settings.premium
                        ? "Автопродление отключено"
                        : "Premium подписка оформлена"
                    )
                  }
                  className={`flex h-11 items-center gap-2 rounded-xl px-8 text-xs font-extrabold text-white shadow-xl ${
                    settings.premium
                      ? "bg-slate-700 hover:bg-slate-600"
                      : "bg-gradient-to-r from-amber-400 to-orange-500 hover:brightness-110"
                  }`}
                >
                  <Crown className="h-4 w-4" />
                  {settings.premium
                    ? "Отключить автопродление"
                    : "Оформить за 99 ₽"}
                </button>
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Безопасность и данные
              </h1>
              <div className="space-y-3">
                <div className="settings-card rounded-2xl border p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-xs font-extrabold text-slate-100">
                      Email
                    </div>
                    <button
                      type="button"
                      onClick={() => setEditingEmail(!editingEmail)}
                      className="rounded-lg bg-white/10 px-3 py-2 text-[10px] font-bold text-slate-200 hover:bg-white/15"
                    >
                      {editingEmail ? "Отмена" : "Изменить"}
                    </button>
                  </div>
                  {editingEmail ? (
                    <div className="mt-3 flex gap-2">
                      <input
                        value={emailDraft}
                        onChange={(event) => setEmailDraft(event.target.value)}
                        className="settings-panel h-9 flex-1 rounded-lg border px-3 text-xs text-slate-100 outline-none focus:border-[var(--primary)]"
                      />
                      <button
                        type="button"
                        onClick={saveEmail}
                        className="settings-accent-bg rounded-lg px-4 text-[10px] font-bold"
                      >
                        Сохранить
                      </button>
                    </div>
                  ) : (
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-xs font-bold text-slate-200">
                      <span>{settings.email}</span>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[9px] ${
                          settings.emailVerified
                            ? "bg-emerald-500/15 text-emerald-400"
                            : "bg-amber-500/15 text-amber-400"
                        }`}
                      >
                        {settings.emailVerified
                          ? "Подтверждён"
                          : "Не подтверждён"}
                      </span>
                    </div>
                  )}
                  {!settings.emailVerified && !editingEmail && (
                    <button
                      type="button"
                      onClick={() =>
                        void savePatch(
                          { emailVerified: true },
                          "Email подтверждён"
                        )
                      }
                      className="settings-accent-soft mt-3 flex items-center gap-2 rounded-lg border px-3 py-2 text-[10px] font-bold"
                    >
                      <Send className="h-3.5 w-3.5" />
                      Отправить письмо подтверждения
                    </button>
                  )}
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-xs font-extrabold text-slate-100">
                      Пароль
                    </div>
                    <button
                      type="button"
                      onClick={() => setChangingPassword(!changingPassword)}
                      className="rounded-lg bg-white/10 px-3 py-2 text-[10px] font-bold text-slate-200 hover:bg-white/15"
                    >
                      {changingPassword ? "Отмена" : "Изменить"}
                    </button>
                  </div>
                  {changingPassword && (
                    <div className="mt-3 grid gap-2 sm:grid-cols-3">
                      {[
                        ["current", "Текущий пароль"],
                        ["next", "Новый пароль"],
                        ["repeat", "Повторите пароль"],
                      ].map(([key, label]) => (
                        <input
                          key={key}
                          type="password"
                          value={passwordDraft[key as keyof typeof passwordDraft]}
                          onChange={(event) =>
                            setPasswordDraft((current) => ({
                              ...current,
                              [key]: event.target.value,
                            }))
                          }
                          placeholder={label}
                          className="settings-panel h-9 rounded-lg border px-3 text-[11px] text-slate-100 outline-none focus:border-[var(--primary)]"
                        />
                      ))}
                      <button
                        type="button"
                        onClick={savePassword}
                        className="settings-accent-bg h-9 rounded-lg px-4 text-[10px] font-bold sm:col-start-3"
                      >
                        Сохранить пароль
                      </button>
                    </div>
                  )}
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-3 text-xs font-extrabold text-slate-100">
                    Привязанные аккаунты
                  </h2>
                  <div className="space-y-2">
                    {[
                      ["google", "Google", "G", "text-blue-400"],
                      ["yandex", "Яндекс", "Я", "text-red-400"],
                      ["vk", "ВКонтакте", "VK", "text-blue-400"],
                      ["telegram", "Telegram", "TG", "text-cyan-400"],
                    ].map(([key, label, mark, color]) => {
                      const linked = Boolean(settings.linkedAccounts[key]);
                      return (
                        <div
                          key={key}
                          className="flex items-center justify-between rounded-xl bg-white/10 px-3 py-2"
                        >
                          <div className="flex items-center gap-3">
                            <span
                              className={`flex h-6 w-6 items-center justify-center rounded-full bg-white text-[9px] font-black ${color}`}
                            >
                              {mark}
                            </span>
                            <span className="text-xs font-bold text-slate-100">
                              {label}
                            </span>
                            {linked && (
                              <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] font-bold text-emerald-400">
                                Привязан
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => setLinkedAccount(key, !linked)}
                            className={`rounded-lg px-3 py-2 text-[9px] font-bold ${
                              linked
                                ? "bg-red-500/15 text-red-400"
                                : "settings-accent-soft border"
                            }`}
                          >
                            {linked ? "Отвязать" : "Привязать"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-3 text-xs font-extrabold text-slate-100">
                    Активные сессии/устройства
                  </h2>
                  <div className="space-y-2">
                    {sessions.map((session) => {
                      const Icon = session.icon;
                      return (
                        <div
                          key={session.id}
                          className="flex items-center justify-between gap-3 rounded-xl bg-white/10 px-3 py-2.5"
                        >
                          <div className="flex min-w-0 items-center gap-3">
                            <Icon className="h-4 w-4 shrink-0 text-slate-400" />
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-100">
                                {session.name}
                                {session.current && (
                                  <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] text-emerald-400">
                                    Это устройство
                                  </span>
                                )}
                              </div>
                              <div className="settings-muted mt-0.5 truncate text-[9px]">
                                {session.detail}
                              </div>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setSessions((current) =>
                                current.filter((item) => item.id !== session.id)
                              );
                              showSaved(
                                session.current
                                  ? "Выход с устройства выполнен"
                                  : "Сессия завершена"
                              );
                            }}
                            className="shrink-0 rounded-lg bg-red-500/15 px-3 py-2 text-[9px] font-bold text-red-400"
                          >
                            {session.current ? "Выйти" : "Завершить"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  {sessions.length > 0 && (
                    <div className="mt-3 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          setSessions([]);
                          showSaved("Все сессии завершены");
                        }}
                        className="rounded-lg bg-red-500/15 px-3 py-2 text-[9px] font-bold text-red-400"
                      >
                        Завершить все сессии
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "privacy" && (
            <div>
              <h1 className="mb-5 text-lg font-extrabold text-slate-100">
                Конфиденциальность и история
              </h1>
              <div className="space-y-3">
                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-2 text-xs font-extrabold text-slate-100">
                    Настройки приватности
                  </h2>
                  <SettingRow
                    title="Приватный профиль"
                    description="Разделы закладок и комментариев видны только вам"
                    checked={settings.privateProfile}
                    onChange={(privateProfile) =>
                      void savePatch({ privateProfile })
                    }
                  />
                </div>

                <div className="settings-card rounded-2xl border p-4">
                  <h2 className="mb-2 text-xs font-extrabold text-slate-100">
                    Очистка истории
                  </h2>
                  <div className="flex items-center justify-between gap-4 py-2">
                    <div>
                      <div className="text-xs font-bold text-slate-100">
                        История чтения
                      </div>
                      <div className="settings-muted mt-0.5 text-[10px]">
                        Удалить весь прогресс чтения глав
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={clearReadingHistory}
                      className="rounded-lg bg-red-500/15 px-3 py-2 text-[10px] font-bold text-red-400 hover:bg-red-500/25"
                    >
                      Очистить
                    </button>
                  </div>
                  <div className="flex items-center justify-between gap-4 py-2">
                    <div>
                      <div className="text-xs font-bold text-slate-100">
                        История поиска
                      </div>
                      <div className="settings-muted mt-0.5 text-[10px]">
                        Удалить все сохранённые поисковые запросы
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={clearSearchHistory}
                      className="rounded-lg bg-red-500/15 px-3 py-2 text-[10px] font-bold text-red-400 hover:bg-red-500/25"
                    >
                      Очистить
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </div>

      {savedMessage && (
        <div className="fixed bottom-5 left-1/2 z-[100] flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/10 bg-[#17181b] px-4 py-2.5 text-xs font-bold text-white shadow-2xl">
          <Check className="settings-accent h-4 w-4" />
          {savedMessage}
        </div>
      )}

      {isAvatarPickerOpen && (
        <AvatarPickerModal
          currentAvatar={profileDraft.avatarUrl}
          onClose={() => setIsAvatarPickerOpen(false)}
          onSelect={(avatarUrl) => {
            void applyAvatar(avatarUrl);
          }}
        />
      )}

      {isBannerPickerOpen && (
        <BannerPickerModal
          currentBanner={profileDraft.bannerUrl}
          onClose={() => setIsBannerPickerOpen(false)}
          onSelect={(bannerUrl) => {
            void applyBanner(bannerUrl);
          }}
          onRemove={() => {
            void removeBanner();
          }}
        />
      )}
    </div>
  );
}
