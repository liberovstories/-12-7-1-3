import Link from "next/link";
import { Compass, ArrowRight } from "lucide-react";
import { collectionsData } from "@/data/collections";

export function CollectionsSection() {
  const preview = collectionsData.slice(0, 6);

  return (
    <section id="collections" className="my-12">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2.5">
          <div className="accent-soft flex h-8 w-8 items-center justify-center rounded-lg border">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-body-theme text-xl sm:text-2xl font-bold tracking-tight">
              Тематические подборки
            </h3>
            <p className="text-muted-theme text-xs">
              Коллекции новелл, отобранные редакцией и читателями
            </p>
          </div>
        </div>

        <Link
          href="/collections"
          className="accent-text text-xs font-semibold flex items-center gap-1 transition-colors hover:opacity-80"
        >
          <span>Все подборки</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Grid of collections with NovelGo overlapping covers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {preview.map((col) => (
          <Link
            key={col.id}
            href={`/catalog?tags=${encodeURIComponent(col.filterTag)}`}
            className="surface-card surface-card-hover group relative rounded-2xl border p-4 sm:p-5 transition-all duration-300 shadow-lg hover:border-[var(--primary)]/40 flex flex-col justify-between"
          >
            {/* Top Row: Title & Badge */}
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <span className="accent-text text-[10px] font-bold tracking-wider uppercase mb-1 inline-block">
                  Подборка
                </span>
                <h4 className="text-body-theme text-base font-bold transition-colors group-hover:text-[var(--primary)]">
                  {col.title}
                </h4>
                <p className="text-muted-theme text-xs mt-1 line-clamp-1">
                  {col.subtitle}
                </p>
              </div>

              <span className="text-muted-theme text-xs font-semibold bg-[var(--surface-hover)] border border-theme px-2.5 py-1 rounded-full whitespace-nowrap">
                {col.count} тайтлов
              </span>
            </div>

            {/* Bottom Row: 3 Overlapping Covers Preview (NovelGo signature) */}
            <div className="relative h-28 flex items-center pt-2">
              <div className="relative w-full flex items-center">
                {/* 1st Cover */}
                <div className="relative z-10 w-20 h-28 rounded-lg overflow-hidden shadow-lg border border-theme group-hover:-translate-x-1 transition-transform">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={col.covers[0]}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* 2nd Cover (stacked) */}
                <div className="relative z-20 -ml-8 w-20 h-28 rounded-lg overflow-hidden shadow-xl border border-theme group-hover:scale-105 group-hover:-translate-y-1 transition-all">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={col.covers[1]}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* 3rd Cover (stacked) */}
                <div className="relative z-30 -ml-8 w-20 h-28 rounded-lg overflow-hidden shadow-2xl border border-theme group-hover:translate-x-1 transition-transform">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={col.covers[2]}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Arrow hint */}
                <div className="accent-text ml-auto text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                  <span>Смотреть</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
