import Link from "next/link";
import { Sparkles, ArrowRight } from "lucide-react";
import { fandomsData } from "@/data/fandoms";

export function FandomsSection() {
  const preview = fandomsData.slice(0, 8);

  return (
    <section id="fandoms" className="my-12">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2.5">
          <div className="accent-soft flex h-8 w-8 items-center justify-center rounded-lg border">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-body-theme text-xl sm:text-2xl font-bold tracking-tight">
              Популярные фандомы
            </h3>
            <p className="text-muted-theme text-xs">
              Произведения по любимым вселенным и мирам
            </p>
          </div>
        </div>

        <Link
          href="/fandoms"
          className="accent-text text-xs font-semibold flex items-center gap-1 transition-colors hover:opacity-80"
        >
          <span>Все фандомы</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-3 sm:gap-4">
        {preview.map((fandom) => (
          <Link
            key={fandom.id}
            href={`/catalog?fandom=${encodeURIComponent(fandom.name)}`}
            className="surface-card group relative overflow-hidden rounded-2xl border p-3 sm:p-4 transition-all duration-300 shadow-md hover:border-[var(--primary)]/40 flex items-center gap-3"
          >
            {/* Background Gradient */}
            <div
              className={`absolute inset-0 bg-gradient-to-r ${fandom.accent} opacity-30 group-hover:opacity-60 transition-opacity`}
            />

            {/* Fandom Avatar */}
            <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden flex-shrink-0 border border-theme group-hover:scale-105 transition-transform">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={fandom.image}
                alt={fandom.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Fandom Info */}
            <div className="relative z-10 flex-1 min-w-0">
              <h4 className="text-body-theme text-xs sm:text-sm font-bold truncate transition-colors group-hover:text-[var(--primary)]">
                {fandom.name}
              </h4>
              <span className="accent-soft inline-block text-[10px] sm:text-xs font-semibold border px-2 py-0.5 rounded-full mt-1">
                {fandom.count} глав
              </span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
