"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Sparkles,
  Trophy,
  Flame,
  ArrowRight,
  Globe,
  Compass,
} from "lucide-react";
import { Novel } from "@/types";
import { NovelCard } from "./NovelCard";
import { FeaturedCarousel } from "./FeaturedCarousel";
import { CollectionsSection } from "./CollectionsSection";
import { FandomsSection } from "./FandomsSection";
import { PopularUpdatesSection } from "./PopularUpdatesSection";

interface HomeViewProps {
  novels: Novel[];
}

export function HomeView({ novels }: HomeViewProps) {
  const [selectedCountry, setSelectedCountry] = useState<string>("Все");

  // Featured novels for hero banner
  const featuredNovels = novels.filter((n) => n.isFeatured || n.rating >= 9.5).slice(0, 5);

  // Recommendations section (NovelGo style)
  const recommendations = novels.filter((n) => n.isRecommendation).slice(0, 8);

  // Top Ranked novels (#1, #2, #3, ...)
  const topRanked = [...novels].sort((a, b) => b.rating - a.rating).slice(0, 6);

  // Filtered by country for Country Tabs
  const countryFiltered =
    selectedCountry === "Все"
      ? novels.slice(0, 8)
      : novels.filter((n) => n.country === selectedCountry).slice(0, 8);

  const countries = ["Все", "Корея", "Китай", "Япония", "СНГ", "Запад"];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
      {/* 1. Hero Spotlight Carousel (NovelGo signature) */}
      <FeaturedCarousel novels={featuredNovels} />

      {/* 2. Рекомендации (Recommendations) - NovelGo Style */}
      <section className="my-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Рекомендации
              </h3>
              <p className="text-xs text-slate-400">
                Тайтлы с высоким рейтингом и захватывающим сюжетом
              </p>
            </div>
          </div>

          <Link
            href="/catalog?recommendation=true"
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
          >
            <span>Смотреть все</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* NovelGo Cards Grid with Mouse Hover Description */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4 sm:gap-5">
          {recommendations.map((novel) => (
            <NovelCard key={novel.id} novel={novel} />
          ))}
        </div>
      </section>

      {/* 3. Лучшие новеллы (Top Ranked) */}
      <section className="my-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Лучшие новеллы
              </h3>
              <p className="text-xs text-slate-400">
                Абсолютный топ читательского рейтинга
              </p>
            </div>
          </div>

          <Link
            href="/top"
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
          >
            <span>Полный топ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3.5 sm:gap-4">
          {topRanked.map((novel, index) => (
            <NovelCard
              key={novel.id}
              novel={novel}
              showRank={true}
              rank={index + 1}
            />
          ))}
        </div>
      </section>

      {/* 4. Популярные обновления (Popular Updates - NovelGo style) */}
      <PopularUpdatesSection novels={novels} />

      {/* 5. Топ по странам (Interactive Country Tabs) */}
      <section className="my-12">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Топ по происхождению
              </h3>
              <p className="text-xs text-slate-400">
                Новеллы Кореи, Китая, Японии и русскоязычных авторов
              </p>
            </div>
          </div>

          {/* Country Tabs */}
          <div className="surface-card flex items-center gap-1.5 rounded-xl border p-1 overflow-x-auto">
            {countries.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCountry(c)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                  selectedCountry === c
                    ? "accent-bg shadow-md"
                    : "text-muted-theme hover:text-body-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                {c === "Все" ? "Все страны" : c}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4 sm:gap-5">
          {countryFiltered.map((novel) => (
            <NovelCard key={novel.id} novel={novel} />
          ))}
        </div>
      </section>

      {/* 6. Тематические подборки (NovelGo Thematic Collections) */}
      <CollectionsSection />

      {/* 7. Популярные фандомы (NovelGo Popular Fandoms) */}
      <FandomsSection />
    </div>
  );
}
