"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  BookOpen,
  Check,
  ChevronDown,
  MoreHorizontal,
  Pencil,
  Plus,
  Star,
  Trash2,
  X,
} from "lucide-react";
import type {
  Bookmark as BookmarkType,
  BookmarkStatus,
  Novel,
} from "@/types";

interface BookmarksViewProps {
  initialBookmarks: (BookmarkType & { novel: Novel })[];
}

type BookmarkFilter = "all" | BookmarkStatus;
type SortMode = "chapter-updates" | "added" | "title" | "rating" | "progress";

const categories: Array<{ id: BookmarkFilter; label: string }> = [
  { id: "all", label: "Все" },
  { id: "reading", label: "Читаю" },
  { id: "planned", label: "Буду читать" },
  { id: "completed", label: "Прочитано" },
  { id: "dropped", label: "Брошено" },
  { id: "paused", label: "Отложено" },
  { id: "uninterested", label: "Не интересно" },
  { id: "favorite", label: "Любимое" },
];

export function BookmarksView({ initialBookmarks }: BookmarksViewProps) {
  const [bookmarks, setBookmarks] = useState(initialBookmarks);
  const [activeTab, setActiveTab] = useState<BookmarkFilter>("reading");
  const [sortMode, setSortMode] = useState<SortMode>("chapter-updates");
  const [editMode, setEditMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [actionsOpen, setActionsOpen] = useState(false);
  const [moveMenuOpen, setMoveMenuOpen] = useState(false);

  const countByStatus = (status: BookmarkFilter) =>
    status === "all"
      ? bookmarks.length
      : bookmarks.filter((bookmark) => bookmark.status === status).length;

  const visibleBookmarks = useMemo(() => {
    const filtered =
      activeTab === "all"
        ? [...bookmarks]
        : bookmarks.filter((bookmark) => bookmark.status === activeTab);

    return filtered.sort((a, b) => {
      switch (sortMode) {
        case "title":
          return a.novel.title.localeCompare(b.novel.title, "ru");
        case "rating":
          return b.novel.rating - a.novel.rating;
        case "progress":
          return (b.lastReadChapter ?? 0) - (a.lastReadChapter ?? 0);
        case "added":
          return (
            new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
          );
        case "chapter-updates":
        default:
          return (
            new Date(b.novel.updatedAt ?? b.updatedAt).getTime() -
            new Date(a.novel.updatedAt ?? a.updatedAt).getTime()
          );
      }
    });
  }, [activeTab, bookmarks, sortMode]);

  const updateStatus = async (novelId: number, status: BookmarkStatus) => {
    const response = await fetch("/api/bookmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ novelId, status }),
    });
    if (!response.ok) return;
    setBookmarks((current) =>
      current.map((bookmark) =>
        bookmark.novelId === novelId ? { ...bookmark, status } : bookmark
      )
    );
  };

  const removeBookmarks = async (ids: number[]) => {
    await Promise.all(
      bookmarks
        .filter((bookmark) => ids.includes(bookmark.id))
        .map((bookmark) =>
          fetch("/api/bookmarks", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              novelId: bookmark.novelId,
              status: "remove",
            }),
          })
        )
    );
    setBookmarks((current) =>
      current.filter((bookmark) => !ids.includes(bookmark.id))
    );
    setSelectedIds(new Set());
  };

  const moveSelected = async (status: BookmarkStatus) => {
    const selected = bookmarks.filter((bookmark) =>
      selectedIds.has(bookmark.id)
    );
    await Promise.all(
      selected.map((bookmark) =>
        fetch("/api/bookmarks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ novelId: bookmark.novelId, status }),
        })
      )
    );
    setBookmarks((current) =>
      current.map((bookmark) =>
        selectedIds.has(bookmark.id) ? { ...bookmark, status } : bookmark
      )
    );
    setSelectedIds(new Set());
    setMoveMenuOpen(false);
    setActionsOpen(false);
  };

  const toggleSelected = (id: number) => {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleEditMode = () => {
    setEditMode((value) => !value);
    setSelectedIds(new Set());
    setActionsOpen(false);
    setMoveMenuOpen(false);
  };

  const selectAllVisible = () => {
    if (
      visibleBookmarks.length > 0 &&
      visibleBookmarks.every((bookmark) => selectedIds.has(bookmark.id))
    ) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(visibleBookmarks.map((bookmark) => bookmark.id)));
    }
  };

  return (
    <div className="mx-auto min-h-[calc(100vh-64px)] max-w-[1120px] px-4 pb-24 pt-7 sm:px-6 lg:px-8">
      <div className="relative flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="relative mb-6 inline-block">
            <h1 className="text-body-theme text-[21px] font-extrabold leading-tight">
              Закладки
            </h1>
            <span className="absolute -bottom-3 left-0 h-[5px] w-[100px] -rotate-2 rounded-full bg-[var(--primary)]" />
          </div>

          <div className="flex max-w-full items-center gap-1 overflow-x-auto rounded-[22px] bg-[var(--surface-hover)] p-1">
            {categories.map((category) => {
              const count = countByStatus(category.id);
              const active = activeTab === category.id;
              return (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(category.id);
                    setSelectedIds(new Set());
                  }}
                  className={`flex h-[34px] shrink-0 items-center gap-1.5 rounded-[18px] px-3 text-[11px] font-extrabold transition-colors ${
                    active
                      ? "accent-bg shadow-[0_4px_12px_rgba(var(--primary-rgb),0.28)]"
                      : "text-body-theme hover:bg-[var(--surface-active)]"
                  }`}
                >
                  <span>{category.label}</span>
                  {category.id !== "all" && (
                    <span className={active ? "text-white" : "text-muted-theme"}>
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex shrink-0 flex-col items-end gap-4 sm:pt-0">
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setActionsOpen(!actionsOpen);
                setMoveMenuOpen(false);
              }}
              className="text-body-theme h-8 rounded-[16px] bg-[var(--surface-hover)] px-3.5 text-[11px] font-extrabold transition-colors hover:bg-[var(--surface-active)]"
            >
              Действия
            </button>

            {actionsOpen && (
              <div className="surface-card absolute right-0 top-10 z-30 w-52 rounded-2xl border p-2 shadow-2xl">
                <button
                  type="button"
                  onClick={() => {
                    setEditMode(true);
                    setActionsOpen(false);
                  }}
                  className="text-body-theme w-full rounded-xl px-3 py-2 text-left text-xs font-semibold hover:bg-[var(--surface-hover)]"
                >
                  Выбрать новеллы
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditMode(true);
                    selectAllVisible();
                    setActionsOpen(false);
                  }}
                  disabled={visibleBookmarks.length === 0}
                  className="text-body-theme w-full rounded-xl px-3 py-2 text-left text-xs font-semibold hover:bg-[var(--surface-hover)] disabled:opacity-40"
                >
                  Выбрать все в разделе
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab("all");
                    setActionsOpen(false);
                  }}
                  className="text-body-theme w-full rounded-xl px-3 py-2 text-left text-xs font-semibold hover:bg-[var(--surface-hover)]"
                >
                  Показать все закладки
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/catalog"
              title="Добавить новеллу"
              className="text-body-theme flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface-hover)] transition-colors hover:bg-[var(--surface-active)]"
            >
              <Plus className="h-4 w-4" strokeWidth={2} />
            </Link>
            <button
              type="button"
              onClick={toggleEditMode}
              title={editMode ? "Закончить редактирование" : "Редактировать"}
              className={`flex h-9 w-9 items-center justify-center rounded-full transition-colors ${
                editMode
                  ? "accent-bg"
                  : "text-body-theme bg-[var(--surface-hover)] hover:bg-[var(--surface-active)]"
              }`}
            >
              {editMode ? (
                <X className="h-4 w-4" />
              ) : (
                <Pencil className="h-3.5 w-3.5" />
              )}
            </button>
          </div>

          <div className="relative">
            <select
              value={sortMode}
              onChange={(event) => setSortMode(event.target.value as SortMode)}
              className="border-theme text-body-theme h-9 appearance-none rounded-[18px] border bg-[var(--surface-hover)] pl-4 pr-9 text-[11px] font-extrabold outline-none transition-colors focus:border-[var(--primary)]"
            >
              <option value="chapter-updates">По дате обновлений глав</option>
              <option value="added">По дате добавления</option>
              <option value="title">По названию</option>
              <option value="rating">По рейтингу</option>
              <option value="progress">По прогрессу чтения</option>
            </select>
            <ChevronDown className="text-body-theme pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
          </div>
        </div>
      </div>

      {editMode && visibleBookmarks.length > 0 && (
        <div className="surface-card sticky top-20 z-20 mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-3 shadow-2xl backdrop-blur-xl">
          <button
            type="button"
            onClick={selectAllVisible}
            className="text-body-theme flex items-center gap-2 text-xs font-bold"
          >
            <span
              className={`flex h-5 w-5 items-center justify-center rounded-md border ${
                visibleBookmarks.every((bookmark) =>
                  selectedIds.has(bookmark.id)
                )
                  ? "border-[var(--primary)] bg-[var(--primary)] text-white"
                  : "border-[var(--border)]"
              }`}
            >
              {visibleBookmarks.every((bookmark) =>
                selectedIds.has(bookmark.id)
              ) && <Check className="h-3.5 w-3.5" />}
            </span>
            Выбрать все
          </button>

          <div className="flex items-center gap-2">
            <span className="text-muted-theme text-[11px] font-semibold">
              Выбрано: {selectedIds.size}
            </span>
            <div className="relative">
              <button
                type="button"
                disabled={selectedIds.size === 0}
                onClick={() => setMoveMenuOpen(!moveMenuOpen)}
                className="text-body-theme h-8 rounded-[16px] bg-[var(--surface-active)] px-3 text-[11px] font-bold hover:brightness-110 disabled:opacity-40"
              >
                Переместить
              </button>
              {moveMenuOpen && (
                <div className="surface-card absolute right-0 top-10 z-30 w-44 rounded-2xl border p-2 shadow-2xl">
                  {categories.slice(1).map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() =>
                        moveSelected(category.id as BookmarkStatus)
                      }
                      className="text-body-theme w-full rounded-xl px-3 py-2 text-left text-xs font-semibold hover:bg-[var(--surface-hover)]"
                    >
                      {category.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <button
              type="button"
              disabled={selectedIds.size === 0}
              onClick={() => removeBookmarks(Array.from(selectedIds))}
              className="flex h-8 items-center gap-1.5 rounded-[16px] bg-red-500/15 px-3 text-[11px] font-bold text-red-400 hover:bg-red-500/25 disabled:opacity-40"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Удалить
            </button>
          </div>
        </div>
      )}

      {visibleBookmarks.length === 0 ? (
        <div className="flex min-h-[510px] flex-col items-center justify-center pb-20 text-center">
          <div className="text-muted-theme relative mb-4 h-10 w-10">
            <span className="absolute left-1 top-1 h-7 w-6 -rotate-12 rounded-[9px] border-[3px] border-current" />
            <span className="absolute bottom-1 right-1 h-7 w-6 rotate-12 rounded-[9px] border-[3px] border-current" />
          </div>
          <p className="text-body-theme text-[14px] font-medium">Пусто</p>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {visibleBookmarks.map((bookmark) => {
            const selected = selectedIds.has(bookmark.id);
            const progress = Math.min(
              100,
              Math.max(
                0,
                ((bookmark.lastReadChapter || 0) /
                  Math.max(1, bookmark.novel.chaptersCount)) *
                  100
              )
            );

            return (
              <article
                key={bookmark.id}
                onClick={() => editMode && toggleSelected(bookmark.id)}
                className={`group surface-card relative flex min-w-0 gap-3 rounded-[20px] border p-3 transition-colors ${
                  selected
                    ? "border-[var(--primary)]"
                    : "hover:border-[var(--primary)]/40"
                } ${editMode ? "cursor-pointer" : ""}`}
              >
                {editMode && (
                  <span
                    className={`absolute left-2 top-2 z-10 flex h-6 w-6 items-center justify-center rounded-full border shadow-lg ${
                      selected
                        ? "border-[var(--primary)] bg-[var(--primary)] text-white"
                        : "border-[var(--border)] bg-[var(--surface-hover)] text-transparent"
                    }`}
                  >
                    <Check className="h-4 w-4" />
                  </span>
                )}

                <Link
                  href={`/novel/${bookmark.novel.slug}`}
                  onClick={(event) => editMode && event.preventDefault()}
                  className="h-[126px] w-[84px] shrink-0 overflow-hidden rounded-[13px] bg-[var(--surface-hover)]"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={bookmark.novel.coverUrl}
                    alt={bookmark.novel.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </Link>

                <div className="flex min-w-0 flex-1 flex-col justify-between py-0.5">
                  <div>
                    <div className="mb-1 flex items-center justify-between gap-2">
                      <span className="text-muted-theme truncate text-[10px] font-semibold">
                        {bookmark.novel.type} • {bookmark.novel.country}
                      </span>
                      <span className="text-body-theme flex items-center gap-1 text-[11px] font-bold">
                        <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                        {bookmark.novel.rating.toFixed(1)}
                      </span>
                    </div>
                    <Link
                      href={`/novel/${bookmark.novel.slug}`}
                      onClick={(event) => editMode && event.preventDefault()}
                      className="text-body-theme line-clamp-2 text-[14px] font-extrabold leading-[18px] transition-colors group-hover:text-[var(--primary)]"
                    >
                      {bookmark.novel.title}
                    </Link>
                  </div>

                  <div>
                    <div className="text-muted-theme mb-1.5 flex items-center justify-between text-[10px] font-semibold">
                      <span>Глава {bookmark.lastReadChapter || 1}</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <div className="mb-2.5 h-1 overflow-hidden rounded-full bg-[var(--surface-active)]">
                      <div
                        className="h-full rounded-full bg-[var(--primary)]"
                        style={{ width: `${progress}%` }}
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <Link
                        href={`/novel/${bookmark.novel.slug}/chapter/${
                          bookmark.lastReadChapter || 1
                        }`}
                        onClick={(event) => editMode && event.preventDefault()}
                        className="accent-bg flex h-8 flex-1 items-center justify-center gap-1.5 rounded-[16px] px-3 text-[11px] font-extrabold transition-colors hover:brightness-110"
                      >
                        <BookOpen className="h-3.5 w-3.5" />
                        Читать
                      </Link>

                      {!editMode && (
                        <div className="group/menu relative">
                          <button
                            type="button"
                            className="text-body-theme flex h-8 w-8 items-center justify-center rounded-full bg-[var(--surface-hover)] hover:bg-[var(--surface-active)]"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </button>
                          <div className="surface-card invisible absolute bottom-9 right-0 z-20 w-44 translate-y-1 rounded-2xl border p-2 opacity-0 shadow-2xl transition-all group-hover/menu:visible group-hover/menu:translate-y-0 group-hover/menu:opacity-100">
                            <select
                              value={bookmark.status}
                              onChange={(event) =>
                                updateStatus(
                                  bookmark.novelId,
                                  event.target.value as BookmarkStatus
                                )
                              }
                              className="border-theme text-body-theme mb-1 w-full rounded-xl border bg-[var(--surface-hover)] px-2 py-2 text-[11px] font-semibold outline-none"
                            >
                              {categories.slice(1).map((category) => (
                                <option key={category.id} value={category.id}>
                                  {category.label}
                                </option>
                              ))}
                            </select>
                            <button
                              type="button"
                              onClick={() => removeBookmarks([bookmark.id])}
                              className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-[11px] font-semibold text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                              Удалить
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
