"use client";

import { useEffect } from "react";

export const THEME_EVENT = "novellread-theme-change";

export interface ThemeSelection {
  themeMode: string;
  colorScheme: string;
}

function applyThemeToDocument(selection: ThemeSelection) {
  const root = document.documentElement;
  root.dataset.themeMode = selection.themeMode;
  root.dataset.colorScheme = selection.colorScheme;
  root.classList.toggle("dark", selection.themeMode === "dark");
  root.style.colorScheme = selection.themeMode === "light" ? "light" : "dark";
}

export function updateSiteTheme(selection: ThemeSelection) {
  applyThemeToDocument(selection);
  window.localStorage.setItem(
    "novellread-theme",
    JSON.stringify(selection)
  );
  window.dispatchEvent(
    new CustomEvent<ThemeSelection>(THEME_EVENT, { detail: selection })
  );
}

const READER_OVERRIDE_VARS = [
  "--background",
  "--surface",
  "--surface-hover",
  "--surface-active",
  "--border",
  "--border-light",
  "--primary",
  "--primary-hover",
  "--primary-rgb",
  "--text-primary",
  "--text-secondary",
  "--text-muted",
] as const;

export interface ReaderThemeVarsInput {
  background: string;
  surface: string;
  surfaceHover: string;
  surfaceActive: string;
  border: string;
  borderLight: string;
  primary: string;
  primaryHover: string;
  primaryRgb: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
}

/**
 * Reading pages need to recolor the *entire* page (including the shared
 * Header/Footer) while a reader theme like OLED is active, not just the
 * article text. Since every themed component already reads CSS custom
 * properties (--background, --surface, --primary, ...), the simplest way to
 * theme the whole page consistently is to override those same properties
 * with an inline style on <html>, which always wins over the attribute-based
 * color-scheme rules. Flipping `data-theme-mode` alongside it also makes the
 * legacy `html[data-theme-mode="light"] .text-white {...}` helper rules used
 * by older components resolve correctly for the reader's chosen theme.
 */
export function applyReaderThemeOverride(
  vars: ReaderThemeVarsInput,
  mode: "dark" | "light"
) {
  const root = document.documentElement;
  root.dataset.readerOverride = "true";
  root.dataset.themeMode = mode;
  root.classList.toggle("dark", mode === "dark");
  root.style.colorScheme = mode === "light" ? "light" : "dark";
  root.style.setProperty("--background", vars.background);
  root.style.setProperty("--surface", vars.surface);
  root.style.setProperty("--surface-hover", vars.surfaceHover);
  root.style.setProperty("--surface-active", vars.surfaceActive);
  root.style.setProperty("--border", vars.border);
  root.style.setProperty("--border-light", vars.borderLight);
  root.style.setProperty("--primary", vars.primary);
  root.style.setProperty("--primary-hover", vars.primaryHover);
  root.style.setProperty("--primary-rgb", vars.primaryRgb);
  root.style.setProperty("--text-primary", vars.textPrimary);
  root.style.setProperty("--text-secondary", vars.textSecondary);
  root.style.setProperty("--text-muted", vars.textMuted);
}

/** Restores whatever site theme (mode + color scheme) was active before the
 * reader override was applied, clearing every inline variable so the
 * class-driven site palette takes over again. */
export function clearReaderThemeOverride(
  originalMode: string,
  originalScheme: string
) {
  const root = document.documentElement;
  delete root.dataset.readerOverride;
  for (const cssVar of READER_OVERRIDE_VARS) {
    root.style.removeProperty(cssVar);
  }
  root.dataset.themeMode = originalMode;
  root.dataset.colorScheme = originalScheme;
  root.classList.toggle("dark", originalMode === "dark");
  root.style.colorScheme = originalMode === "light" ? "light" : "dark";
}

export function ThemeProvider({
  initialMode,
  initialScheme,
}: {
  initialMode: string;
  initialScheme: string;
}) {
  useEffect(() => {
    let selection: ThemeSelection = {
      themeMode: initialMode,
      colorScheme: initialScheme,
    };

    const stored = window.localStorage.getItem("novellread-theme");
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as Partial<ThemeSelection>;
        if (parsed.themeMode && parsed.colorScheme) {
          selection = {
            themeMode: parsed.themeMode,
            colorScheme: parsed.colorScheme,
          };
        }
      } catch {
        window.localStorage.removeItem("novellread-theme");
      }
    }

    applyThemeToDocument(selection);

    const handleThemeChange = (event: Event) => {
      const customEvent = event as CustomEvent<ThemeSelection>;
      applyThemeToDocument(customEvent.detail);
    };

    window.addEventListener(THEME_EVENT, handleThemeChange);
    return () => window.removeEventListener(THEME_EVENT, handleThemeChange);
  }, [initialMode, initialScheme]);

  return null;
}
