"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, Sparkles } from "lucide-react";
import { fandomsData } from "@/data/fandoms";

export function FandomsView() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("ru-RU");
    if (!normalized) return fandomsData;
    return fandomsData.filter((fandom) =>
      fandom.name.toLocaleLowerCase("ru-RU").includes(normalized)
    );
  }, [query]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-5 flex items-center gap-2.5">
        <div className="accent-soft flex h-9 w-9 items-center justify-center rounded-xl border">
          <Sparkles className="h-4.5 w-4.5" />
        </div>
        <div>
          <h1 className="text-body-theme text-2xl font-extrabold tracking-tight">
            Фандомы
          </h1>
          <p className="text-muted-theme text-xs">
            Фанфики и произведения по любимым вселенным и мирам
          </p>
        </div>
      </div>

      <div className="relative mb-3 max-w-md">
        <Search className="text-muted-theme pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Поиск фандома..."
          className="border-theme text-body-theme h-11 w-full rounded-full border bg-[var(--surface)] pl-10 pr-4 text-sm outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
        />
      </div>

      <p className="text-muted-theme mb-6 text-xs">{filtered.length} фандомов</p>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {filtered.map((fandom) => (
          <Link
            key={fandom.id}
            href={`/catalog?fandom=${encodeURIComponent(fandom.name)}`}
            className="group flex flex-col items-center"
          >
            <div className="relative h-28 w-28 overflow-hidden rounded-2xl border border-theme shadow-lg transition-transform group-hover:scale-105 sm:h-32 sm:w-32">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={fandom.image}
                alt={fandom.name}
                className="h-full w-full object-cover"
              />
              <div
                className={`absolute inset-0 bg-gradient-to-t ${fandom.accent} opacity-40`}
              />
            </div>
            <h3 className="text-body-theme mt-3 text-center text-sm font-bold transition-colors group-hover:text-[var(--primary)]">
              {fandom.name}
            </h3>
            <span className="accent-soft mt-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold">
              {fandom.count} глав
            </span>
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="surface-card mt-6 rounded-2xl border p-10 text-center">
          <p className="text-body-theme text-sm font-bold">Ничего не найдено</p>
          <p className="text-muted-theme mt-1 text-xs">
            Попробуйте изменить запрос поиска
          </p>
        </div>
      )}
    </div>
  );
}
