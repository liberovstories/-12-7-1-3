"use client";

import { useState } from "react";
import { CatalogFilters } from "@/types";
import {
  RotateCcw,
  Search,
  SlidersHorizontal,
  Check,
  ChevronDown,
  BookMarked,
  Tags,
  Hash,
  Activity,
  ListFilter,
} from "lucide-react";

interface FilterSidebarProps {
  filters: CatalogFilters;
  onChange: (newFilters: CatalogFilters) => void;
  onReset: () => void;
  isMobileModal?: boolean;
  onCloseMobile?: () => void;
}

const ALL_TYPES = [
  { id: "all", label: "Все типы" },
  { id: "Новелла", label: "Новелла (Корея)" },
  { id: "Веб-новелла", label: "Веб-новелла (Китай)" },
  { id: "Ранобэ", label: "Ранобэ (Япония)" },
  { id: "Авторский", label: "Авторская новелла (СНГ)" },
  { id: "Западная новелла", label: "Западная новелла" },
  { id: "Фанфик", label: "Фанфик" },
];

const ALL_GENRES = [
  "Боевик",
  "Боевые искусства",
  "Гарем",
  "Детектив",
  "Драма",
  "Игра",
  "Исекай",
  "Исторический",
  "Комедия",
  "Киберпанк",
  "ЛитРПГ",
  "Меха",
  "Мистика",
  "Научная фантастика",
  "Повседневность",
  "Постапокалипсис",
  "Приключения",
  "Психология",
  "Романтика",
  "Сверхъестественное",
  "Спорт",
  "Сёнэн",
  "Сэйнэн",
  "Сянься",
  "Триллер",
  "Ужасы",
  "Уся",
  "Фэнтези",
  "Хоррор",
  "Школа",
  "Этти",
  "Юмор",
];

const ALL_TAGS = [
  "Система",
  "Перерождение",
  "Реинкарнация",
  "Культивация",
  "Магия",
  "Непобедимый ГГ",
  "Антигерой",
  "Владыка подземелий",
  "Игровой элемент",
  "Попаданец",
  "Умный ГГ",
  "Демоны",
  "Драконы",
  "Боги",
  "Гильдии",
  "Война кланов",
  "Предательство",
  "Месть",
  "Крафтинг",
  "Прокачка",
  "Дворянство",
  "Академия",
  "Бессмертие",
];

const STATUS_OPTIONS = [
  { id: "all", label: "Любой статус" },
  { id: "Онгоинг", label: "Онгоинг (выходит)" },
  { id: "Завершен", label: "Завершен" },
  { id: "Заморожен", label: "Заморожен" },
];

const TRANSLATION_OPTIONS = [
  { id: "all", label: "Любой статус" },
  { id: "Продолжается", label: "Продолжается" },
  { id: "Завершен", label: "Завершен" },
  { id: "Заброшен", label: "Заброшен" },
];

const AGE_OPTIONS = [
  { id: "all", label: "Все рейтинги" },
  { id: "0+", label: "0+ (Для всех)" },
  { id: "12+", label: "12+" },
  { id: "16+", label: "16+" },
  { id: "18+", label: "18+" },
];

const CHAPTERS_OPTIONS = [
  { id: "all", label: "Любое количество" },
  { id: "lt50", label: "Меньше 50" },
  { id: "50-200", label: "50 – 200 глав" },
  { id: "200-500", label: "200 – 500 глав" },
  { id: "500-1000", label: "500 – 1 000 глав" },
  { id: "gt1000", label: "Более 1 000 глав" },
];

const YEAR_OPTIONS = [
  { id: "all", label: "Все годы" },
  { id: "2026", label: "2026" },
  { id: "2025", label: "2025" },
  { id: "2024", label: "2024" },
  { id: "2023", label: "2023" },
  { id: "2022", label: "2022" },
  { id: "2021", label: "2021" },
  { id: "old", label: "До 2020 года" },
];

const RATING_OPTIONS = [
  { id: "all", label: "Любая оценка" },
  { id: "9.5", label: "★ 9.5 и выше" },
  { id: "9", label: "★ 9.0 и выше" },
  { id: "8", label: "★ 8.0 и выше" },
  { id: "7", label: "★ 7.0 и выше" },
];

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: Array<{ id: string; label: string }>;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="text-muted-theme mb-1 block text-[11px] font-semibold">
        {label}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="border-theme text-body-theme h-9 w-full appearance-none rounded-lg border bg-[var(--surface-hover)] px-2.5 pr-8 text-xs outline-none transition-colors focus:border-[var(--primary)]"
        >
          {options.map((opt) => (
            <option key={opt.id} value={opt.id}>
              {opt.label}
            </option>
          ))}
        </select>
        <ChevronDown className="text-muted-theme pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
      </div>
    </div>
  );
}

function FilterSection({
  icon,
  title,
  badge,
  isOpen,
  onToggle,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  badge?: number;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="surface-card border-theme overflow-hidden rounded-2xl border">
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between px-4 py-3.5 transition-colors hover:bg-[var(--surface-hover)]"
      >
        <div className="flex items-center gap-2.5">
          <span className="accent-soft flex h-7 w-7 items-center justify-center rounded-lg border">
            {icon}
          </span>
          <span className="text-body-theme text-xs font-extrabold uppercase tracking-wide">
            {title}
          </span>
          {!!badge && (
            <span className="accent-bg rounded-full px-1.5 py-0.5 text-[10px] font-bold leading-none">
              {badge}
            </span>
          )}
        </div>
        <ChevronDown
          className={`text-muted-theme h-4 w-4 shrink-0 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {isOpen && (
        <div className="border-theme space-y-3 border-t px-4 py-3.5">
          {children}
        </div>
      )}
    </div>
  );
}

export function CatalogFilterSidebar({
  filters,
  onChange,
  onReset,
  isMobileModal = false,
  onCloseMobile,
}: FilterSidebarProps) {
  const [genreSearch, setGenreSearch] = useState("");
  const [tagSearch, setTagSearch] = useState("");
  const [openSections, setOpenSections] = useState({
    types: true,
    genres: true,
    tags: false,
    status: false,
    extra: false,
  });

  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleGenre = (genre: string) => {
    const current = [...filters.genres];
    const index = current.indexOf(genre);
    if (index >= 0) {
      current.splice(index, 1);
    } else {
      current.push(genre);
    }
    onChange({ ...filters, genres: current });
  };

  const toggleTag = (tag: string) => {
    const current = [...filters.tags];
    const index = current.indexOf(tag);
    if (index >= 0) {
      current.splice(index, 1);
    } else {
      current.push(tag);
    }
    onChange({ ...filters, tags: current });
  };

  const filteredGenres = ALL_GENRES.filter((g) =>
    g.toLowerCase().includes(genreSearch.toLowerCase().trim())
  );

  const filteredTags = ALL_TAGS.filter((t) =>
    t.toLowerCase().includes(tagSearch.toLowerCase().trim())
  );

  const hasExtraCriteria =
    filters.chaptersRange !== "all" ||
    filters.ageRating !== "all" ||
    filters.releaseYear !== "all" ||
    filters.minRating !== "all";

  const hasStatusCriteria =
    filters.status !== "all" || filters.translationStatus !== "all";

  return (
    <aside className="w-full space-y-3 text-left">
      {/* Top Header */}
      <div className="surface-card border-theme flex items-center justify-between rounded-2xl border px-4 py-3.5">
        <div className="flex items-center gap-2.5">
          <span className="accent-soft flex h-8 w-8 items-center justify-center rounded-xl border">
            <SlidersHorizontal className="h-4 w-4" />
          </span>
          <div>
            <h3 className="text-body-theme text-sm font-extrabold leading-tight">
              Фильтры
            </h3>
            <p className="text-muted-theme text-[10px]">ReManga-style</p>
          </div>
        </div>

        <button
          onClick={onReset}
          className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-semibold text-rose-400 transition-colors hover:bg-rose-500/10"
          title="Сбросить все фильтры"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Сбросить</span>
        </button>
      </div>

      {/* 1. ТИПЫ (Types) */}
      <FilterSection
        icon={<BookMarked className="h-3.5 w-3.5" />}
        title="Тип произведения"
        isOpen={openSections.types}
        onToggle={() => toggleSection("types")}
      >
        <div className="space-y-1">
          {ALL_TYPES.map((t) => (
            <label
              key={t.id}
              className={`flex cursor-pointer items-center justify-between rounded-lg px-2.5 py-2 text-xs transition-colors ${
                filters.type === t.id
                  ? "accent-soft border font-semibold"
                  : "text-body-theme hover:bg-[var(--surface-hover)]"
              }`}
            >
              <span>{t.label}</span>
              <input
                type="radio"
                name="type"
                checked={filters.type === t.id}
                onChange={() => onChange({ ...filters, type: t.id })}
                className="hidden"
              />
              {filters.type === t.id && <Check className="h-3.5 w-3.5" />}
            </label>
          ))}
        </div>
      </FilterSection>

      {/* 2. ЖАНРЫ (Genres with Search) */}
      <FilterSection
        icon={<Tags className="h-3.5 w-3.5" />}
        title="Жанры"
        badge={filters.genres.length}
        isOpen={openSections.genres}
        onToggle={() => toggleSection("genres")}
      >
        <div className="relative">
          <input
            type="text"
            value={genreSearch}
            onChange={(e) => setGenreSearch(e.target.value)}
            placeholder="Поиск по жанрам..."
            className="border-theme text-body-theme h-9 w-full rounded-lg border bg-[var(--surface-hover)] pl-8 pr-2 text-xs outline-none transition-colors placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
          />
          <Search className="text-muted-theme pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
        </div>

        <div className="max-h-52 space-y-1 overflow-y-auto pr-1">
          {filteredGenres.length === 0 ? (
            <p className="text-muted-theme py-2 text-center text-[11px]">
              Ничего не найдено
            </p>
          ) : (
            filteredGenres.map((genre) => {
              const isSelected = filters.genres.includes(genre);
              return (
                <button
                  key={genre}
                  type="button"
                  onClick={() => toggleGenre(genre)}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-xs transition-colors ${
                    isSelected
                      ? "accent-soft border font-semibold"
                      : "text-body-theme hover:bg-[var(--surface-hover)]"
                  }`}
                >
                  <span>{genre}</span>
                  {isSelected && <Check className="h-3.5 w-3.5" />}
                </button>
              );
            })
          )}
        </div>
      </FilterSection>

      {/* 3. КАТЕГОРИИ / ТЕГИ (Categories & Tags) */}
      <FilterSection
        icon={<Hash className="h-3.5 w-3.5" />}
        title="Категории / Теги"
        badge={filters.tags.length}
        isOpen={openSections.tags}
        onToggle={() => toggleSection("tags")}
      >
        <div className="relative">
          <input
            type="text"
            value={tagSearch}
            onChange={(e) => setTagSearch(e.target.value)}
            placeholder="Поиск по тегам..."
            className="border-theme text-body-theme h-9 w-full rounded-lg border bg-[var(--surface-hover)] pl-8 pr-2 text-xs outline-none transition-colors placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
          />
          <Search className="text-muted-theme pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
        </div>

        <div className="flex max-h-44 flex-wrap gap-1.5 overflow-y-auto pr-1">
          {filteredTags.length === 0 ? (
            <p className="text-muted-theme w-full py-2 text-center text-[11px]">
              Ничего не найдено
            </p>
          ) : (
            filteredTags.map((tag) => {
              const isSelected = filters.tags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    isSelected
                      ? "border-cyan-500/50 bg-cyan-500/15 text-cyan-400"
                      : "border-theme text-muted-theme hover:bg-[var(--surface-hover)] hover:text-body-theme"
                  }`}
                >
                  {tag}
                </button>
              );
            })
          )}
        </div>
      </FilterSection>

      {/* 4. СТАТУС ТАЙТЛА & ПЕРЕВОДА */}
      <FilterSection
        icon={<Activity className="h-3.5 w-3.5" />}
        title="Статус произведения"
        badge={hasStatusCriteria ? 1 : 0}
        isOpen={openSections.status}
        onToggle={() => toggleSection("status")}
      >
        <SelectField
          label="Статус оригинала"
          value={filters.status}
          options={STATUS_OPTIONS}
          onChange={(value) => onChange({ ...filters, status: value })}
        />
        <SelectField
          label="Статус перевода"
          value={filters.translationStatus}
          options={TRANSLATION_OPTIONS}
          onChange={(value) =>
            onChange({ ...filters, translationStatus: value })
          }
        />
      </FilterSection>

      {/* 5. ДОПОЛНИТЕЛЬНО: ГЛАВЫ, ГОД, РЕЙТИНГ, ВОЗРАСТ */}
      <FilterSection
        icon={<ListFilter className="h-3.5 w-3.5" />}
        title="Критерии поиска"
        badge={hasExtraCriteria ? 1 : 0}
        isOpen={openSections.extra}
        onToggle={() => toggleSection("extra")}
      >
        <SelectField
          label="Количество глав"
          value={filters.chaptersRange}
          options={CHAPTERS_OPTIONS}
          onChange={(value) => onChange({ ...filters, chaptersRange: value })}
        />
        <SelectField
          label="Возрастной рейтинг"
          value={filters.ageRating}
          options={AGE_OPTIONS}
          onChange={(value) => onChange({ ...filters, ageRating: value })}
        />
        <SelectField
          label="Год релиза"
          value={filters.releaseYear}
          options={YEAR_OPTIONS}
          onChange={(value) => onChange({ ...filters, releaseYear: value })}
        />
        <SelectField
          label="Минимальная оценка"
          value={filters.minRating}
          options={RATING_OPTIONS}
          onChange={(value) => onChange({ ...filters, minRating: value })}
        />
      </FilterSection>

      {/* Mobile Drawer Close Button */}
      {isMobileModal && onCloseMobile && (
        <button
          onClick={onCloseMobile}
          className="accent-bg w-full rounded-xl py-2.5 text-xs font-extrabold shadow-lg"
        >
          Применить фильтры
        </button>
      )}
    </aside>
  );
}
