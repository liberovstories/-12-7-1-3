"use client";

/**
 * Site-wide toggle switch used anywhere a boolean setting needs a pill-style
 * on/off control (Settings → Notifications, Reader settings, etc).
 *
 * The previous per-page implementations positioned the white thumb with
 * `absolute` + `translate-x-*`, which is fragile: any mismatch between the
 * track width, thumb size, and translate distance makes the thumb drift
 * outside the track (the bug the user reported — the circle rendering
 * disconnected from the pill). This version instead lays the thumb out with
 * flexbox and `justify-start`/`justify-end`, so the thumb can never escape
 * the track regardless of size tweaks, matching the reference design where
 * the colored pill always fully contains the white circle.
 */
export function ToggleSwitch({
  checked,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`flex h-6 w-11 shrink-0 items-center rounded-full p-[3px] transition-colors duration-200 ${
        checked ? "accent-bg" : "bg-[var(--surface-active)]"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
    >
      <span
        className={`h-[18px] w-[18px] rounded-full bg-white shadow-[0_1px_3px_rgba(0,0,0,0.35)] transition-transform duration-200 ${
          checked ? "translate-x-[20px]" : "translate-x-0"
        }`}
      />
    </button>
  );
}
