"use client";

import { useState, useEffect, useRef, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  LayoutGrid,
  List as ListIcon,
  Search,
  SlidersHorizontal,
  X,
  Star,
  BookOpen,
  Bookmark,
  Layers,
} from "lucide-react";
import { Novel, CatalogFilters } from "@/types";
import { NovelCard } from "./NovelCard";
import { CatalogFilterSidebar } from "./CatalogFilterSidebar";
import Link from "next/link";

interface CatalogViewProps {
  initialNovels: Novel[];
}

const DEFAULT_FILTERS: CatalogFilters = {
  search: "",
  type: "all",
  country: "all",
  genres: [],
  tags: [],
  status: "all",
  translationStatus: "all",
  ageRating: "all",
  fullyFree: false,
  chaptersRange: "all",
  releaseYear: "all",
  minRating: "all",
  sortBy: "popularity",
};

export function CatalogView({ initialNovels }: CatalogViewProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  // Initialize filters from URL params if present
  const [filters, setFilters] = useState<CatalogFilters>(() => {
    return {
      search: searchParams.get("search") || "",
      type: searchParams.get("type") || "all",
      country: searchParams.get("country") || "all",
      genres: searchParams.get("genres")
        ? searchParams.get("genres")!.split(",")
        : [],
      tags: searchParams.get("tags") ? searchParams.get("tags")!.split(",") : [],
      status: searchParams.get("status") || "all",
      translationStatus: searchParams.get("translationStatus") || "all",
      ageRating: searchParams.get("ageRating") || "all",
      fullyFree: searchParams.get("fullyFree") === "true",
      chaptersRange: searchParams.get("chaptersRange") || "all",
      releaseYear: searchParams.get("releaseYear") || "all",
      minRating: searchParams.get("minRating") || "all",
      sortBy: searchParams.get("sortBy") || "popularity",
    };
  });

  const [novels, setNovels] = useState<Novel[]>(initialNovels);
  const [loading, setLoading] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);
  const [, startTransition] = useTransition();
  const lastQueryKeyRef = useRef<string | null>(null);

  // Fetch filtered novels. A ref-based guard skips redundant requests for an
  // identical query string, and an AbortController prevents an older, slower
  // response from overwriting newer results — both of which previously
  // caused the grid to appear to "reshuffle" the same novels unexpectedly.
  useEffect(() => {
    const params = new URLSearchParams();
    if (filters.search) params.set("search", filters.search);
    if (filters.type !== "all") params.set("type", filters.type);
    if (filters.country !== "all") params.set("country", filters.country);
    if (filters.genres.length > 0) params.set("genres", filters.genres.join(","));
    if (filters.tags.length > 0) params.set("tags", filters.tags.join(","));
    if (filters.status !== "all") params.set("status", filters.status);
    if (filters.translationStatus !== "all")
      params.set("translationStatus", filters.translationStatus);
    if (filters.ageRating !== "all") params.set("ageRating", filters.ageRating);
    if (filters.fullyFree) params.set("fullyFree", "true");
    if (filters.chaptersRange !== "all")
      params.set("chaptersRange", filters.chaptersRange);
    if (filters.releaseYear !== "all")
      params.set("releaseYear", filters.releaseYear);
    if (filters.minRating !== "all") params.set("minRating", filters.minRating);
    if (filters.sortBy !== "popularity") params.set("sortBy", filters.sortBy);

    const queryKey = params.toString();
    if (lastQueryKeyRef.current === queryKey) {
      return;
    }
    lastQueryKeyRef.current = queryKey;

    const controller = new AbortController();
    setLoading(true);
    fetch(`/api/novels?${queryKey}`, { signal: controller.signal })
      .then((res) => res.json())
      .then((data) => {
        if (data.items) {
          setNovels(data.items);
        }
      })
      .catch((err) => {
        if ((err as Error).name !== "AbortError") {
          console.error("Filter fetch failed", err);
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    // Sync URL without hard page reload
    startTransition(() => {
      router.replace(`/catalog?${queryKey}`, { scroll: false });
    });

    return () => controller.abort();
  }, [filters, router]);

  const handleResetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  const removeGenre = (genre: string) => {
    setFilters((prev) => ({
      ...prev,
      genres: prev.genres.filter((g) => g !== genre),
    }));
  };

  const removeTag = (tag: string) => {
    setFilters((prev) => ({
      ...prev,
      tags: prev.tags.filter((t) => t !== tag),
    }));
  };

  // Quick Chips (as on ReManga)
  const quickChips = [
    { label: "Все", active: filters.type === "all" && filters.country === "all", onClick: () => setFilters({ ...filters, type: "all", country: "all" }) },
    { label: "Корея", active: filters.country === "Корея", onClick: () => setFilters({ ...filters, country: filters.country === "Корея" ? "all" : "Корея" }) },
    { label: "Китай", active: filters.country === "Китай", onClick: () => setFilters({ ...filters, country: filters.country === "Китай" ? "all" : "Китай" }) },
    { label: "Япония", active: filters.country === "Япония", onClick: () => setFilters({ ...filters, country: filters.country === "Япония" ? "all" : "Япония" }) },
    { label: "СНГ", active: filters.country === "СНГ", onClick: () => setFilters({ ...filters, country: filters.country === "СНГ" ? "all" : "СНГ" }) },
    { label: "Новелла", active: filters.type === "Новелла", onClick: () => setFilters({ ...filters, type: filters.type === "Новелла" ? "all" : "Новелла" }) },
    { label: "Ранобэ", active: filters.type === "Ранобэ", onClick: () => setFilters({ ...filters, type: filters.type === "Ранобэ" ? "all" : "Ранобэ" }) },
    { label: "Завершенные", active: filters.status === "Завершен", onClick: () => setFilters({ ...filters, status: filters.status === "Завершен" ? "all" : "Завершен" }) },
    { label: "18+", active: filters.ageRating === "18+", onClick: () => setFilters({ ...filters, ageRating: filters.ageRating === "18+" ? "all" : "18+" }) },
    { label: "Бесплатно", active: filters.fullyFree, onClick: () => setFilters({ ...filters, fullyFree: !filters.fullyFree }) },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Catalog Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Каталог новелл
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Тысячи восточных новелл, ранобэ и авторских книг с удобной фильтрацией ReManga
          </p>
        </div>

        {/* Mobile Filters Toggle Button */}
        <button
          onClick={() => setIsMobileFiltersOpen(true)}
          className="lg:hidden flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-xl text-sm font-bold"
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>Фильтры ReManga</span>
          {(filters.genres.length > 0 ||
            filters.tags.length > 0 ||
            filters.type !== "all" ||
            filters.country !== "all") && (
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
          )}
        </button>
      </div>

      {/* Quick Chips Bar (ReManga style) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4 scrollbar-none">
        {quickChips.map((chip) => (
          <button
            key={chip.label}
            onClick={chip.onClick}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              chip.active
                ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/20"
                : "bg-[#131722] text-slate-300 hover:text-white hover:bg-[#1a2030] border border-white/5"
            }`}
          >
            {chip.label}
          </button>
        ))}
      </div>

      {/* Control Bar: Search input, Sort dropdown, View switch */}
      <div className="bg-[#131722] border border-white/5 rounded-2xl p-3 sm:p-4 mb-6 flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search inside catalog */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            placeholder="Поиск по названию или автору..."
            className="w-full bg-[#0b0e14] border border-white/10 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          {filters.search && (
            <button
              onClick={() => setFilters({ ...filters, search: "" })}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Right side: Sorting & View toggles */}
        <div className="flex items-center justify-between w-full md:w-auto gap-3">
          {/* Sort Select */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 hidden sm:inline">Сортировка:</span>
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
              className="bg-[#0b0e14] border border-white/10 rounded-xl px-3 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              <option value="popularity">По популярности</option>
              <option value="rating">По рейтингу</option>
              <option value="newest">По новизне (году)</option>
              <option value="chapters">По количеству глав</option>
              <option value="views">По просмотрам</option>
              <option value="alphabet">По алфавиту (А-Я)</option>
            </select>
          </div>

          {/* Grid / List Switcher */}
          <div className="flex items-center bg-[#0b0e14] border border-white/10 rounded-xl p-1">
            <button
              onClick={() => setViewMode("grid")}
              title="Сетка"
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === "grid"
                  ? "bg-emerald-500 text-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              title="Список"
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === "list"
                  ? "bg-emerald-500 text-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <ListIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Active Filter Pills (ReManga style) */}
      {(filters.genres.length > 0 ||
        filters.tags.length > 0 ||
        filters.type !== "all" ||
        filters.country !== "all" ||
        filters.status !== "all" ||
        filters.minRating !== "all" ||
        filters.fullyFree ||
        filters.releaseYear !== "all") && (
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <span className="text-xs text-slate-400">Активные фильтры:</span>

          {filters.fullyFree && (
            <span className="inline-flex items-center gap-1 text-xs font-medium bg-emerald-500 text-black px-2.5 py-1 rounded-full">
              Полностью бесплатно
              <button
                onClick={() => setFilters({ ...filters, fullyFree: false })}
                className="hover:opacity-70"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.type !== "all" && (
            <span className="inline-flex items-center gap-1 text-xs font-medium bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-full">
              Тип: {filters.type}
              <button
                onClick={() => setFilters({ ...filters, type: "all" })}
                className="hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.country !== "all" && (
            <span className="inline-flex items-center gap-1 text-xs font-medium bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2.5 py-1 rounded-full">
              Страна: {filters.country}
              <button
                onClick={() => setFilters({ ...filters, country: "all" })}
                className="hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.status !== "all" && (
            <span className="inline-flex items-center gap-1 text-xs font-medium bg-purple-500/20 text-purple-400 border border-purple-500/30 px-2.5 py-1 rounded-full">
              Статус: {filters.status}
              <button
                onClick={() => setFilters({ ...filters, status: "all" })}
                className="hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.minRating !== "all" && (
            <span className="inline-flex items-center gap-1 text-xs font-medium bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full">
              Оценка ≥ {filters.minRating}
              <button
                onClick={() => setFilters({ ...filters, minRating: "all" })}
                className="hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.genres.map((g) => (
            <span
              key={g}
              className="inline-flex items-center gap-1 text-xs font-medium bg-white/10 text-slate-200 border border-white/10 px-2.5 py-1 rounded-full"
            >
              {g}
              <button onClick={() => removeGenre(g)} className="hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}

          {filters.tags.map((t) => (
            <span
              key={t}
              className="inline-flex items-center gap-1 text-xs font-medium bg-cyan-950/70 text-cyan-300 border border-cyan-700/40 px-2.5 py-1 rounded-full"
            >
              #{t}
              <button onClick={() => removeTag(t)} className="hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}

          <button
            onClick={handleResetFilters}
            className="text-xs font-medium text-rose-400 hover:text-rose-300 underline ml-1"
          >
            Сбросить все
          </button>
        </div>
      )}

      {/* Main Catalog Content: Sidebar + Cards Grid/List */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Desktop Sidebar (1/4 column) */}
        <div className="hidden lg:block lg:col-span-1 sticky top-20">
          <CatalogFilterSidebar
            filters={filters}
            onChange={setFilters}
            onReset={handleResetFilters}
          />
        </div>

        {/* Novels Results Grid/List (3/4 column) */}
        <div className="lg:col-span-3">
          {/* Results Counter */}
          <div className="flex items-center justify-between text-xs text-slate-400 mb-4 px-1">
            <span>
              Найдено: <strong className="text-white">{novels.length}</strong>{" "}
              {novels.length === 1
                ? "новелла"
                : novels.length < 5
                ? "новеллы"
                : "новелл"}
            </span>
            {loading && (
              <span className="text-emerald-400 flex items-center gap-1">
                Обновление...
              </span>
            )}
          </div>

          {/* Cards Display */}
          {novels.length === 0 ? (
            <div className="bg-[#131722] border border-white/5 rounded-2xl p-12 text-center my-4">
              <Layers className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">
                По выбранным критериям ничего не найдено
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
                Попробуйте ослабить фильтры, выбрать другой тип или сбросить критерии поиска
              </p>
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-black text-xs font-bold rounded-xl transition-colors"
              >
                Сбросить фильтры
              </button>
            </div>
          ) : viewMode === "grid" ? (
            /* Grid View: NovelGo Cards with Mouse Hover Excerpt */
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-5">
              {novels.map((novel) => (
                <NovelCard key={novel.id} novel={novel} />
              ))}
            </div>
          ) : (
            /* List View: ReManga detailed row layout */
            <div className="space-y-3">
              {novels.map((novel) => (
                <div
                  key={novel.id}
                  className="group bg-[#131722] hover:bg-[#181e30] border border-white/5 hover:border-emerald-500/40 rounded-xl p-3 sm:p-4 transition-all duration-200 flex gap-4"
                >
                  {/* Cover */}
                  <Link
                    href={`/novel/${novel.slug}`}
                    className="relative w-20 sm:w-24 aspect-[2/3] flex-shrink-0 rounded-lg overflow-hidden border border-white/10"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={novel.coverUrl}
                      alt={novel.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute top-1 left-1 bg-black/80 px-1.5 py-0.2 rounded text-[10px] font-bold text-amber-400 flex items-center gap-0.5">
                      <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                      {novel.rating.toFixed(1)}
                    </div>
                  </Link>

                  {/* Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[11px] font-semibold text-emerald-400">
                          {novel.type} • {novel.country}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/5 text-slate-300">
                          {novel.ageRating}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400">
                          {novel.status}
                        </span>
                      </div>

                      <Link
                        href={`/novel/${novel.slug}`}
                        className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors block line-clamp-1"
                      >
                        {novel.title}
                      </Link>
                      {novel.englishTitle && (
                        <p className="text-xs text-slate-400 truncate">
                          {novel.englishTitle}
                        </p>
                      )}

                      {/* Excerpt */}
                      <p className="text-xs text-slate-300 line-clamp-2 mt-1.5">
                        {novel.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-white/5 mt-2 text-xs text-slate-400">
                      <div className="flex items-center gap-3">
                        <span>{novel.chaptersCount} глав</span>
                        <span>{novel.releaseYear} г.</span>
                        <span className="hidden sm:inline">
                          Перевод: {novel.translator}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Link
                          href={`/novel/${novel.slug}`}
                          className="px-3 py-1 bg-emerald-500 hover:bg-emerald-600 text-black font-bold text-xs rounded-lg flex items-center gap-1"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>Читать</span>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Filters Modal Drawer */}
      {isMobileFiltersOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-lg max-h-[85vh] overflow-y-auto bg-[#131722] border border-white/10 rounded-t-2xl sm:rounded-2xl p-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <span className="text-sm font-bold text-white">
                Фильтры ReManga
              </span>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <CatalogFilterSidebar
              filters={filters}
              onChange={setFilters}
              onReset={handleResetFilters}
              isMobileModal={true}
              onCloseMobile={() => setIsMobileFiltersOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
