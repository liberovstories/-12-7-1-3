"use client";

import { useCallback, useRef, useState } from "react";
import Cropper from "react-easy-crop";
import type { Area } from "react-easy-crop";
import { Check, Image as ImageIcon, Upload, X } from "lucide-react";

export const PRESET_AVATARS = [
  "/images/avatars/preset-1.jpg",
  "/images/avatars/preset-2.jpg",
  "/images/avatars/preset-3.jpg",
  "/images/avatars/preset-4.jpg",
  "/images/avatars/preset-5.jpg",
  "/images/avatars/preset-6.jpg",
];

interface AvatarPickerModalProps {
  currentAvatar: string;
  onClose: () => void;
  onSelect: (avatarUrl: string) => void;
}

function loadImageElement(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new window.Image();
    image.addEventListener("load", () => resolve(image));
    image.addEventListener("error", (event) => reject(event));
    image.crossOrigin = "anonymous";
    image.src = url;
  });
}

async function cropImageToSquare(
  imageSrc: string,
  area: Area
): Promise<string> {
  const image = await loadImageElement(imageSrc);
  const canvas = document.createElement("canvas");
  const outputSize = 512;
  canvas.width = outputSize;
  canvas.height = outputSize;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is not supported in this browser");

  ctx.drawImage(
    image,
    area.x,
    area.y,
    area.width,
    area.height,
    0,
    0,
    outputSize,
    outputSize
  );

  return canvas.toDataURL("image/jpeg", 0.92);
}

export function AvatarPickerModal({
  currentAvatar,
  onClose,
  onSelect,
}: AvatarPickerModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<Area | null>(
    null
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Пожалуйста, выберите файл изображения");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError("Файл слишком большой (максимум 8 МБ)");
      return;
    }

    setError("");
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result as string);
      setCrop({ x: 0, y: 0 });
      setZoom(1);
      setCroppedAreaPixels(null);
    };
    reader.readAsDataURL(file);
  };

  const onCropComplete = useCallback((_area: Area, pixels: Area) => {
    setCroppedAreaPixels(pixels);
  }, []);

  const confirmCrop = async () => {
    if (!uploadedImage || !croppedAreaPixels) return;
    setSaving(true);
    setError("");
    try {
      const dataUrl = await cropImageToSquare(uploadedImage, croppedAreaPixels);
      const response = await fetch("/api/uploads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dataUrl, type: "avatar" }),
      });
      const data = await response.json();
      if (!response.ok || !data.url) {
        throw new Error(data.error || "Не удалось сохранить изображение");
      }
      onSelect(data.url);
      onClose();
    } catch {
      setError("Не удалось обработать изображение");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[130] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !uploadedImage) {
          onClose();
        }
      }}
    >
      <div className="settings-card w-full max-w-lg rounded-2xl border p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-slate-100">
            {uploadedImage ? "Выберите область аватара" : "Выберите аватар"}
          </h2>
          <button
            type="button"
            onClick={() => {
              if (uploadedImage) {
                setUploadedImage(null);
                setError("");
              } else {
                onClose();
              }
            }}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {uploadedImage ? (
          <div>
            <div className="relative h-72 w-full overflow-hidden rounded-xl bg-black">
              <Cropper
                image={uploadedImage}
                crop={crop}
                zoom={zoom}
                aspect={1}
                cropShape="rect"
                showGrid
                onCropChange={setCrop}
                onZoomChange={setZoom}
                onCropComplete={onCropComplete}
              />
            </div>

            <div className="mt-4 flex items-center gap-3">
              <span className="settings-muted text-[11px] font-bold">
                Масштаб
              </span>
              <input
                type="range"
                min={1}
                max={3}
                step={0.01}
                value={zoom}
                onChange={(event) => setZoom(Number(event.target.value))}
                className="flex-1 accent-[var(--primary)]"
              />
            </div>

            {error && (
              <p className="mt-3 rounded-lg bg-red-500/10 p-2 text-[11px] font-semibold text-red-400">
                {error}
              </p>
            )}

            <div className="mt-4 flex items-center gap-3">
              <button
                type="button"
                onClick={() => setUploadedImage(null)}
                className="h-10 flex-1 rounded-xl border border-white/10 text-xs font-bold text-slate-300 hover:bg-white/5"
              >
                Назад
              </button>
              <button
                type="button"
                onClick={confirmCrop}
                disabled={saving || !croppedAreaPixels}
                className="settings-accent-bg flex h-10 flex-1 items-center justify-center gap-2 rounded-xl text-xs font-extrabold shadow-lg disabled:opacity-60"
              >
                <Check className="h-4 w-4" />
                {saving ? "Сохранение..." : "Сохранить"}
              </button>
            </div>
          </div>
        ) : (
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="settings-accent-soft flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-3 text-xs font-extrabold"
            >
              <Upload className="h-4 w-4" />
              Загрузить свою фотографию
            </button>

            {error && (
              <p className="mt-3 rounded-lg bg-red-500/10 p-2 text-[11px] font-semibold text-red-400">
                {error}
              </p>
            )}

            <div className="mt-5">
              <div className="settings-muted mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
                <ImageIcon className="h-3.5 w-3.5" />
                Готовые аватары
              </div>
              <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-6">
                {PRESET_AVATARS.map((preset) => {
                  const active = currentAvatar === preset;
                  return (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        onSelect(preset);
                        onClose();
                      }}
                      className={`relative aspect-square overflow-hidden rounded-xl border-2 transition-all ${
                        active
                          ? "border-[var(--primary)]"
                          : "border-transparent hover:border-white/20"
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={preset}
                        alt="Готовый аватар"
                        className="h-full w-full object-cover"
                      />
                      {active && (
                        <span className="absolute inset-0 flex items-center justify-center bg-black/30">
                          <Check className="h-5 w-5 text-white" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
