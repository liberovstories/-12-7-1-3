"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  Link as LinkIcon,
  PenLine,
  Send,
} from "lucide-react";

export function CreatorRequestView({
  kind,
}: {
  kind: "translation" | "publication";
}) {
  const isTranslation = kind === "translation";
  const [form, setForm] = useState({
    title: "",
    sourceUrl: "",
    language: isTranslation ? "Китайский" : "Русский",
    description: "",
  });
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSending(true);
    setError("");
    try {
      const response = await fetch("/api/creator-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, kind }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось отправить заявку");
      setSubmitted(true);
    } catch (requestError) {
      setError((requestError as Error).message);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="mx-auto min-h-[calc(100vh-64px)] max-w-3xl px-4 py-10 sm:px-6">
      <Link
        href="/"
        className="settings-muted mb-5 inline-flex items-center gap-2 text-xs font-bold hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" /> На главную
      </Link>

      {submitted ? (
        <div className="settings-card rounded-3xl border p-10 text-center shadow-2xl">
          <CheckCircle2 className="settings-accent mx-auto h-14 w-14" />
          <h1 className="mt-4 text-2xl font-black text-slate-100">
            Заявка отправлена
          </h1>
          <p className="settings-muted mx-auto mt-2 max-w-md text-sm leading-6">
            Редакция NovellRead рассмотрит её и отправит уведомление после принятия решения.
          </p>
          <Link
            href="/profile"
            className="settings-accent-bg mt-6 inline-flex h-10 items-center rounded-xl px-5 text-xs font-extrabold"
          >
            Вернуться в профиль
          </Link>
        </div>
      ) : (
        <form
          onSubmit={submit}
          className="settings-card rounded-3xl border p-6 shadow-2xl sm:p-8"
        >
          <div className="mb-7 flex items-start gap-4">
            <span className="settings-accent-soft flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border">
              {isTranslation ? (
                <Send className="h-5 w-5" />
              ) : (
                <PenLine className="h-5 w-5" />
              )}
            </span>
            <div>
              <h1 className="text-2xl font-black text-slate-100">
                {isTranslation
                  ? "Предложить перевод"
                  : "Начать публиковать"}
              </h1>
              <p className="settings-muted mt-1 text-xs leading-5">
                {isTranslation
                  ? "Предложите произведение, перевод которого вы хотите увидеть на NovellRead."
                  : "Отправьте заявку на публикацию авторского произведения или собственного перевода."}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-slate-200">
                {isTranslation
                  ? "Название произведения"
                  : "Название публикации"}
              </span>
              <div className="relative">
                <BookOpen className="settings-muted absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" />
                <input
                  required
                  minLength={2}
                  maxLength={160}
                  value={form.title}
                  onChange={(event) =>
                    setForm((current) => ({
                      ...current,
                      title: event.target.value,
                    }))
                  }
                  placeholder="Введите название"
                  className="settings-panel h-11 w-full rounded-xl border pl-10 pr-3 text-sm text-slate-100 outline-none placeholder:text-slate-500 focus:border-[var(--primary)]"
                />
              </div>
            </label>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1.5 block text-xs font-bold text-slate-200">
                  Ссылка на оригинал
                </span>
                <div className="relative">
                  <LinkIcon className="settings-muted absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" />
                  <input
                    type="url"
                    value={form.sourceUrl}
                    onChange={(event) =>
                      setForm((current) => ({
                        ...current,
                        sourceUrl: event.target.value,
                      }))
                    }
                    placeholder="https://..."
                    className="settings-panel h-11 w-full rounded-xl border pl-10 pr-3 text-sm text-slate-100 outline-none placeholder:text-slate-500 focus:border-[var(--primary)]"
                  />
                </div>
              </label>

              <label className="block">
                <span className="mb-1.5 block text-xs font-bold text-slate-200">
                  {isTranslation ? "Язык оригинала" : "Язык публикации"}
                </span>
                <select
                  value={form.language}
                  onChange={(event) =>
                    setForm((current) => ({
                      ...current,
                      language: event.target.value,
                    }))
                  }
                  className="settings-panel h-11 w-full rounded-xl border px-3 text-sm text-slate-100 outline-none focus:border-[var(--primary)]"
                >
                  {[
                    "Русский",
                    "Китайский",
                    "Корейский",
                    "Японский",
                    "Английский",
                    "Другой",
                  ].map((language) => (
                    <option key={language}>{language}</option>
                  ))}
                </select>
              </label>
            </div>

            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-slate-200">
                {isTranslation ? "Почему стоит перевести" : "О произведении"}
              </span>
              <textarea
                required
                minLength={10}
                maxLength={2000}
                rows={7}
                value={form.description}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    description: event.target.value,
                  }))
                }
                placeholder={
                  isTranslation
                    ? "Расскажите, чем интересно это произведение..."
                    : "Опишите произведение и ваш план публикации..."
                }
                className="settings-panel w-full resize-none rounded-xl border p-3 text-sm leading-6 text-slate-100 outline-none placeholder:text-slate-500 focus:border-[var(--primary)]"
              />
            </label>
          </div>

          {error && (
            <p className="mt-4 rounded-xl bg-red-500/10 p-3 text-xs font-semibold text-red-400">
              {error}
            </p>
          )}

          <div className="mt-6 flex justify-end">
            <button
              type="submit"
              disabled={sending}
              className="settings-accent-bg flex h-11 items-center gap-2 rounded-xl px-6 text-xs font-extrabold shadow-lg disabled:opacity-60"
            >
              <Send className="h-4 w-4" />
              {sending ? "Отправка..." : "Отправить заявку"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
