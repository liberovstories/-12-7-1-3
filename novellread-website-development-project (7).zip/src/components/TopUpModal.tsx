"use client";

import { useState } from "react";
import { Check, Coins, X } from "lucide-react";

interface CoinPackage {
  id: string;
  coins: number;
  bonus: number;
  priceRub: number;
  hit?: boolean;
}

const packages: CoinPackage[] = [
  { id: "p100", coins: 100, bonus: 0, priceRub: 100 },
  { id: "p220", coins: 220, bonus: 21, priceRub: 199 },
  { id: "p390", coins: 390, bonus: 41, priceRub: 349, hit: true },
  { id: "p560", coins: 560, bonus: 61, priceRub: 499 },
  { id: "p1150", coins: 1150, bonus: 151, priceRub: 999 },
  { id: "p2500", coins: 2500, bonus: 501, priceRub: 1999 },
];

export const BALANCE_EVENT = "novellread-balance-change";

interface TopUpModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: (balance: number) => void;
}

export function TopUpModal({ open, onClose, onSuccess }: TopUpModalProps) {
  const [selected, setSelected] = useState<string>("p390");
  const [customAmount, setCustomAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (!open) return null;

  const isCustom = selected === "custom";
  const activePackage = packages.find((item) => item.id === selected);
  const customValue = Math.max(0, Math.round(Number(customAmount) || 0));
  const credited = isCustom ? customValue : activePackage?.coins ?? 0;
  const priceRub = isCustom ? customValue : activePackage?.priceRub ?? 0;
  const canPay = isCustom ? customValue >= 20 : Boolean(activePackage);

  const submit = async () => {
    if (!canPay) {
      setError("Минимальная сумма пополнения — 20 ₽");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/wallet/topup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          isCustom
            ? { customAmountRub: customValue }
            : { packageId: selected }
        ),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Не удалось выполнить оплату");
      }
      window.dispatchEvent(
        new CustomEvent(BALANCE_EVENT, {
          detail: { balance: data.settings.balance },
        })
      );
      onSuccess?.(data.settings.balance);
      onClose();
    } catch (requestError) {
      setError((requestError as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[130] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="settings-card w-full max-w-md rounded-2xl border p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-slate-100">
            Пополнение баланса
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-2">
          {packages.map((pack) => {
            const active = selected === pack.id;
            return (
              <button
                key={pack.id}
                type="button"
                onClick={() => setSelected(pack.id)}
                className={`flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-left transition-colors ${
                  active
                    ? "settings-accent-soft"
                    : "border-white/10 hover:bg-white/5"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                      active
                        ? "border-[var(--primary)] bg-[var(--primary)] text-white"
                        : "border-white/25"
                    }`}
                  >
                    {active && <Check className="h-3 w-3" />}
                  </span>
                  <div>
                    <div className="flex items-center gap-2 text-xs font-extrabold text-slate-100">
                      <span>{pack.coins} монет</span>
                      {pack.hit && (
                        <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-bold text-amber-400">
                          ХИТ
                        </span>
                      )}
                    </div>
                    {pack.bonus > 0 && (
                      <div className="settings-muted mt-0.5 text-[10px]">
                        включая +{pack.bonus} бонусных
                      </div>
                    )}
                  </div>
                </div>
                <span className="text-xs font-extrabold text-slate-100">
                  {pack.priceRub} ₽
                </span>
              </button>
            );
          })}

          <div
            className={`flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-left transition-colors ${
              isCustom
                ? "settings-accent-soft"
                : "border-white/10 hover:bg-white/5"
            }`}
          >
            <button
              type="button"
              onClick={() => setSelected("custom")}
              className="flex flex-1 items-center gap-3 text-left"
            >
              <span
                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                  isCustom
                    ? "border-[var(--primary)] bg-[var(--primary)] text-white"
                    : "border-white/25"
                }`}
              >
                {isCustom && <Check className="h-3 w-3" />}
              </span>
              <span className="text-xs font-extrabold text-slate-100">
                Своя сумма{" "}
                <span className="settings-muted font-medium">от 20 ₽</span>
              </span>
            </button>
            <input
              type="number"
              min={20}
              value={customAmount}
              onFocus={() => setSelected("custom")}
              onChange={(event) => {
                setSelected("custom");
                setCustomAmount(event.target.value);
              }}
              placeholder="0"
              className="settings-panel h-8 w-20 rounded-lg border px-2 text-right text-xs text-slate-100 outline-none focus:border-[var(--primary)]"
            />
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-xs">
          <span className="settings-muted font-semibold">К зачислению</span>
          <span className="flex items-center gap-1.5 font-extrabold text-slate-100">
            <Coins className="h-4 w-4 text-amber-400" />
            {credited} монет
          </span>
        </div>

        {error && (
          <p className="mt-3 rounded-lg bg-red-500/10 p-2 text-[11px] font-semibold text-red-400">
            {error}
          </p>
        )}

        <div className="mt-4 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="h-10 flex-1 rounded-xl border border-white/10 text-xs font-bold text-slate-300 hover:bg-white/5"
          >
            Отмена
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={loading || !canPay}
            className="settings-accent-bg h-10 flex-1 rounded-xl text-xs font-extrabold shadow-lg disabled:opacity-60"
          >
            {loading ? "Оплата..." : `Оплатить ${priceRub} ₽`}
          </button>
        </div>
      </div>
    </div>
  );
}
