import Link from "next/link";
import { BookOpen, ShieldAlert, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-white/5 bg-[#0e111a] text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand info */}
          <div className="md:col-span-1 space-y-3">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-black font-black text-sm">
                NR
              </div>
              <span className="font-extrabold text-lg tracking-tight text-white">
                Novell<span className="text-emerald-400">Read</span>
              </span>
            </Link>

            <p className="text-xs text-slate-400 leading-relaxed">
              Современная платформа для чтения переводов азиатских веб-новелл, ранобэ и фанфиков на русском языке. Удобная читалка, ежедневные обновления и большой каталог.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <span className="text-[11px] font-bold text-amber-400 bg-amber-950/40 border border-amber-800/40 px-2 py-0.5 rounded">
                18+ Возрастное ограничение
              </span>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Разделы сайта
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/catalog" className="hover:text-emerald-400 transition-colors">
                  Каталог новелл (ReManga)
                </Link>
              </li>
              <li>
                <Link href="/top" className="hover:text-emerald-400 transition-colors">
                  Топ произведений
                </Link>
              </li>
              <li>
                <Link href="/collections" className="hover:text-emerald-400 transition-colors">
                  Тематические подборки
                </Link>
              </li>
              <li>
                <Link href="/fandoms" className="hover:text-emerald-400 transition-colors">
                  Популярные фандомы
                </Link>
              </li>
              <li>
                <Link href="/bookmarks" className="hover:text-emerald-400 transition-colors">
                  Мои закладки и история
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Категории
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/catalog?country=Корея" className="hover:text-emerald-400 transition-colors">
                  Корейские новеллы
                </Link>
              </li>
              <li>
                <Link href="/catalog?country=Китай" className="hover:text-emerald-400 transition-colors">
                  Китайские веб-новеллы (Сянься)
                </Link>
              </li>
              <li>
                <Link href="/catalog?country=Япония" className="hover:text-emerald-400 transition-colors">
                  Японские ранобэ
                </Link>
              </li>
              <li>
                <Link href="/catalog?country=СНГ" className="hover:text-emerald-400 transition-colors">
                  Русскоязычные авторы
                </Link>
              </li>
              <li>
                <Link href="/catalog?type=Фанфик" className="hover:text-emerald-400 transition-colors">
                  Фанфики по вселенным
                </Link>
              </li>
            </ul>
          </div>

          {/* Information & Legal */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Информация
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <span className="hover:text-emerald-400 cursor-pointer transition-colors">
                  О проекте NovellRead
                </span>
              </li>
              <li>
                <span className="hover:text-emerald-400 cursor-pointer transition-colors">
                  Пользовательское соглашение
                </span>
              </li>
              <li>
                <span className="hover:text-emerald-400 cursor-pointer transition-colors flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  Правообладателям (DMCA)
                </span>
              </li>
              <li>
                <span className="hover:text-emerald-400 cursor-pointer transition-colors">
                  Командам переводчиков (Rulate API)
                </span>
              </li>
            </ul>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-400 font-medium">Сервер онлайн • 2026</span>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 NovellRead. Все права на произведения принадлежат их авторам и переводчикам.</p>
          <p className="flex items-center gap-1">
            Сделано с <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> для истинных ценителей новелл
          </p>
        </div>
      </div>
    </footer>
  );
}
