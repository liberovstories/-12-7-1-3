"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, Compass, Search } from "lucide-react";
import { collectionsData } from "@/data/collections";

export function CollectionsView() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("ru-RU");
    if (!normalized) return collectionsData;
    return collectionsData.filter((collection) =>
      collection.title.toLocaleLowerCase("ru-RU").includes(normalized)
    );
  }, [query]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-5 flex items-center gap-2.5">
        <div className="accent-soft flex h-9 w-9 items-center justify-center rounded-xl border">
          <Compass className="h-4.5 w-4.5" />
        </div>
        <div>
          <h1 className="text-body-theme text-2xl font-extrabold tracking-tight">
            Тематические подборки
          </h1>
          <p className="text-muted-theme text-xs">
            Коллекции новелл, отобранные редакцией и читателями NovellRead
          </p>
        </div>
      </div>

      <div className="relative mb-3 max-w-md">
        <Search className="text-muted-theme pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Поиск подборки..."
          className="border-theme text-body-theme h-11 w-full rounded-full border bg-[var(--surface)] pl-10 pr-4 text-sm outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
        />
      </div>

      <p className="text-muted-theme mb-6 text-xs">
        {filtered.length} тематических подборок
      </p>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {filtered.map((collection) => (
          <Link
            key={collection.id}
            href={`/catalog?tags=${encodeURIComponent(collection.filterTag)}`}
            className="group flex flex-col"
          >
            <div className="relative flex h-36 items-center justify-center sm:h-40">
              <div className="relative z-10 h-32 w-24 -rotate-6 overflow-hidden rounded-xl border border-theme shadow-lg transition-transform group-hover:-translate-x-1 group-hover:-rotate-3 sm:h-36 sm:w-28">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={collection.covers[0]}
                  alt=""
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="relative z-20 -ml-8 h-32 w-24 rotate-6 overflow-hidden rounded-xl border border-theme shadow-xl transition-transform group-hover:translate-x-1 group-hover:rotate-3 sm:h-36 sm:w-28">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={collection.covers[1]}
                  alt=""
                  className="h-full w-full object-cover"
                />
              </div>
            </div>

            <h3 className="text-body-theme mt-3 text-center text-sm font-bold leading-tight transition-colors group-hover:text-[var(--primary)]">
              {collection.title}
            </h3>
            <p className="text-muted-theme mt-1 flex items-center justify-center gap-1 text-center text-[11px]">
              {collection.count} тайтлов
            </p>
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="surface-card mt-6 rounded-2xl border p-10 text-center">
          <p className="text-body-theme text-sm font-bold">Ничего не найдено</p>
          <p className="text-muted-theme mt-1 text-xs">
            Попробуйте изменить запрос поиска
          </p>
        </div>
      )}
    </div>
  );
}
