"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Star,
  BookOpen,
  Bookmark,
  Share2,
  Calendar,
  Layers,
  Eye,
  User,
  Check,
  Languages,
  MessageSquare,
  ThumbsUp,
  Search,
} from "lucide-react";
import { Novel, Chapter, Review } from "@/types";

interface NovelDetailsViewProps {
  novel: Novel;
  chapters: Chapter[];
  reviews: Review[];
  initialBookmarkStatus?: string | null;
  initialLastReadChapter?: number;
}

export function NovelDetailsView({
  novel,
  chapters,
  reviews: initialReviews,
  initialBookmarkStatus,
  initialLastReadChapter = 1,
}: NovelDetailsViewProps) {
  const [activeTab, setActiveTab] = useState<"about" | "chapters" | "reviews">("about");
  const [bookmarkStatus, setBookmarkStatus] = useState<string | null>(
    initialBookmarkStatus || null
  );
  const [isBookmarkSaving, setIsBookmarkSaving] = useState(false);
  const [chapterSearch, setChapterSearch] = useState("");
  const [reviews, setReviews] = useState<Review[]>(initialReviews);

  // Review form state
  const [newReviewText, setNewReviewText] = useState("");
  const [newReviewRating, setNewReviewRating] = useState(10);
  const [reviewerName, setReviewerName] = useState("");
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  const handleBookmarkChange = async (status: string) => {
    setIsBookmarkSaving(true);
    try {
      await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          novelId: novel.id,
          status,
          lastReadChapter: initialLastReadChapter,
        }),
      });
      setBookmarkStatus(status === "remove" ? null : status);
    } catch (e) {
      console.error("Failed to update bookmark", e);
    } finally {
      setIsBookmarkSaving(false);
    }
  };

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim()) return;

    setIsSubmittingReview(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          novelId: novel.id,
          userName: reviewerName.trim() || "Читатель NovellRead",
          rating: newReviewRating,
          text: newReviewText.trim(),
        }),
      });
      const data = await res.json();
      if (data.review) {
        setReviews([data.review, ...reviews]);
        setNewReviewText("");
        setReviewSuccess(true);
        setTimeout(() => setReviewSuccess(false), 4000);
      }
    } catch (err) {
      console.error("Review submission failed", err);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const filteredChapters = chapters.filter((c) =>
    c.title.toLowerCase().includes(chapterSearch.toLowerCase().trim())
  );

  const bookmarkLabels: Record<string, string> = {
    reading: "Читаю",
    planned: "Буду читать",
    completed: "Прочитано",
    dropped: "Брошено",
    paused: "Отложено",
    uninterested: "Не интересно",
    favorite: "Любимое",
  };

  return (
    <div className="min-h-screen">
      {/* Ambient Banner Backdrop — a strongly blurred, full-bleed version of
          the cover art fills the top of the page (ReManga-style), fading
          smoothly into the site background behind the floating title card. */}
      <div className="relative w-full h-[420px] sm:h-[560px] overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={novel.bannerUrl || novel.coverUrl}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full scale-125 object-cover object-center opacity-60 blur-3xl saturate-125"
        />
        <div className="absolute inset-0 bg-black/25" />
        <div className="absolute inset-0 banner-fade-y" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-64 sm:-mt-[26rem] relative z-10 pb-16">
        {/* Main Header Card */}
        <div className="flex flex-col md:flex-row gap-6 sm:gap-8 bg-[#131722]/90 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl">
          {/* Cover and Actions */}
          <div className="w-full sm:w-64 flex-shrink-0 flex flex-col items-center">
            <div className="relative aspect-[2/3] w-48 sm:w-full rounded-2xl overflow-hidden shadow-2xl border-2 border-white/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={novel.coverUrl}
                alt={novel.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2.5 left-2.5 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-bold text-amber-400 flex items-center gap-1 border border-white/10">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{novel.rating.toFixed(1)}</span>
              </div>
              <div className="absolute top-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2 py-1 rounded-lg text-xs font-semibold text-slate-200 border border-white/10">
                {novel.ageRating}
              </div>
            </div>

            {/* Bookmark Status Dropdown */}
            <div className="w-full mt-4">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1 text-center">
                Статус в закладках
              </label>
              <div className="relative">
                <select
                  value={bookmarkStatus || "none"}
                  disabled={isBookmarkSaving}
                  onChange={(e) =>
                    handleBookmarkChange(
                      e.target.value === "none" ? "remove" : e.target.value
                    )
                  }
                  className="w-full bg-[#0b0e14] border border-white/10 text-xs font-bold rounded-xl px-3 py-2.5 text-center text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
                >
                  <option value="none">Добавить в закладки</option>
                  <option value="reading">В закладках: Читаю</option>
                  <option value="planned">В закладках: Буду читать</option>
                  <option value="completed">В закладках: Прочитано</option>
                  <option value="dropped">В закладках: Брошено</option>
                  <option value="paused">В закладках: Отложено</option>
                  <option value="uninterested">В закладках: Не интересно</option>
                  <option value="favorite">В закладках: Любимое</option>
                </select>
              </div>
              {bookmarkStatus && (
                <p className="text-[11px] text-emerald-400 text-center mt-1 flex items-center justify-center gap-1 font-semibold">
                  <Check className="w-3 h-3" /> В категории «
                  {bookmarkLabels[bookmarkStatus]}»
                </p>
              )}
            </div>
          </div>

          {/* Details & Info */}
          <div className="flex-1 flex flex-col justify-between">
            <div className="space-y-3">
              {/* Type, Country & Status Badges */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  {novel.type} • {novel.country}
                </span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-white/10 text-slate-300">
                  {novel.status}
                </span>
                <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-cyan-950/60 text-cyan-400 border border-cyan-800/40">
                  Перевод: {novel.translationStatus}
                </span>
              </div>

              {/* Title & Alternate Names */}
              <div>
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
                  {novel.title}
                </h1>
                {novel.englishTitle && (
                  <p className="text-sm font-medium text-slate-400 mt-1">
                    {novel.englishTitle}
                  </p>
                )}
                {novel.originalTitle && (
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Оригинал: {novel.originalTitle}
                  </p>
                )}
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 border-y border-white/5 my-2">
                <div>
                  <span className="text-[11px] text-slate-400 block">Оценка:</span>
                  <div className="flex items-center gap-1 text-sm font-bold text-amber-400 mt-0.5">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>{novel.rating.toFixed(1)}</span>
                    <span className="text-xs text-slate-500 font-normal">
                      ({novel.ratingCount.toLocaleString()})
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block">Глав:</span>
                  <div className="flex items-center gap-1 text-sm font-bold text-white mt-0.5">
                    <Layers className="w-4 h-4 text-emerald-400" />
                    <span>{novel.chaptersCount}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block">Просмотров:</span>
                  <div className="flex items-center gap-1 text-sm font-bold text-white mt-0.5">
                    <Eye className="w-4 h-4 text-cyan-400" />
                    <span>{novel.viewsCount.toLocaleString()}</span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block">В закладках:</span>
                  <div className="flex items-center gap-1 text-sm font-bold text-white mt-0.5">
                    <Bookmark className="w-4 h-4 text-rose-400" />
                    <span>{novel.bookmarksCount.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Metadata rows */}
              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-28">Автор:</span>
                  <span className="font-semibold text-white">{novel.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-28">Переводчики:</span>
                  <span className="font-semibold text-emerald-400 flex items-center gap-1">
                    <Languages className="w-3.5 h-3.5" />
                    {novel.translator}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-28">Год выпуска:</span>
                  <span>{novel.releaseYear}</span>
                </div>
                {novel.fandom && (
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 w-28">Фандом:</span>
                    <span className="text-purple-400 font-semibold">
                      {novel.fandom}
                    </span>
                  </div>
                )}
              </div>

              {/* Genres Pills */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {novel.genres.map((genre) => (
                  <Link
                    key={genre}
                    href={`/catalog?genres=${encodeURIComponent(genre)}`}
                    className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-200 border border-white/5 transition-colors"
                  >
                    {genre}
                  </Link>
                ))}
              </div>
            </div>

            {/* Read Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-6 border-t border-white/5">
              {chapters.length > 0 ? (
                <Link
                  href={`/novel/${novel.slug}/chapter/${chapters[0].chapterNumber}`}
                  className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-extrabold text-sm rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-transform active:scale-95"
                >
                  <BookOpen className="w-4 h-4 text-black" />
                  <span>Читать с 1 главы</span>
                </Link>
              ) : (
                <button
                  disabled
                  className="px-6 py-3 bg-slate-700 text-slate-400 font-semibold text-sm rounded-xl cursor-not-allowed"
                >
                  Глав пока нет
                </button>
              )}

              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  alert("Ссылка скопирована в буфер обмена!");
                }}
                className="p-3 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl border border-white/5 transition-colors"
                title="Поделиться ссылкой"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-white/10 mt-8 mb-6">
          <button
            onClick={() => setActiveTab("about")}
            className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 ${
              activeTab === "about"
                ? "border-emerald-400 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            О произведении
          </button>
          <button
            onClick={() => setActiveTab("chapters")}
            className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === "chapters"
                ? "border-emerald-400 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            <span>Оглавление</span>
            <span className="text-xs bg-white/10 px-2 py-0.2 rounded-full">
              {chapters.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab("reviews")}
            className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === "reviews"
                ? "border-emerald-400 text-emerald-400"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            <span>Рецензии</span>
            <span className="text-xs bg-white/10 px-2 py-0.2 rounded-full">
              {reviews.length}
            </span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === "about" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Description */}
              <div className="bg-[#131722] border border-white/5 rounded-2xl p-6">
                <h3 className="text-base font-bold text-white mb-3">Описание</h3>
                <div className="text-sm text-slate-300 leading-relaxed space-y-3 whitespace-pre-line font-normal">
                  {novel.description}
                </div>
              </div>

              {/* Tags Section */}
              {novel.tags && novel.tags.length > 0 && (
                <div className="bg-[#131722] border border-white/5 rounded-2xl p-6">
                  <h3 className="text-base font-bold text-white mb-3">
                    Теги произведения
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {novel.tags.map((tag) => (
                      <Link
                        key={tag}
                        href={`/catalog?tags=${encodeURIComponent(tag)}`}
                        className="text-xs font-medium px-3 py-1.5 rounded-lg bg-[#0b0e14] text-cyan-400 border border-cyan-800/40 hover:bg-cyan-950/40 transition-colors"
                      >
                        #{tag}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right sidebar: Translator & Novel Info */}
            <div className="space-y-6">
              <div className="bg-[#131722] border border-white/5 rounded-2xl p-5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Команда перевода (Rulate)
                </h4>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                    TL
                  </div>
                  <div>
                    <h5 className="text-sm font-bold text-white">
                      {novel.translator}
                    </h5>
                    <p className="text-xs text-slate-400">
                      Верифицированная команда
                    </p>
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-white/5 text-xs text-slate-400">
                  <p>Качество перевода: <strong className="text-emerald-400">9.9/10</strong></p>
                  <p className="mt-1">Частота выхода: <strong className="text-white">1 глава в день</strong></p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Chapters List Tab */}
        {activeTab === "chapters" && (
          <div className="bg-[#131722] border border-white/5 rounded-2xl p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <h3 className="text-base font-bold text-white">Список глав</h3>
              <div className="relative w-64">
                <input
                  type="text"
                  value={chapterSearch}
                  onChange={(e) => setChapterSearch(e.target.value)}
                  placeholder="Поиск по главам..."
                  className="w-full bg-[#0b0e14] border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="divide-y divide-white/5">
              {filteredChapters.map((chapter) => (
                <Link
                  key={chapter.id}
                  href={`/novel/${novel.slug}/chapter/${chapter.chapterNumber}`}
                  className="group flex items-center justify-between py-3.5 px-3 hover:bg-white/5 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 text-xs font-mono font-bold text-slate-500 group-hover:text-emerald-400">
                      #{chapter.chapterNumber}
                    </span>
                    <span className="text-sm font-semibold text-slate-200 group-hover:text-emerald-400 transition-colors">
                      {chapter.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    {chapter.isFree ? (
                      <span className="text-emerald-400/90 bg-emerald-950/60 px-2 py-0.5 rounded text-[11px]">
                        Бесплатно
                      </span>
                    ) : (
                      <span className="text-amber-400/90 bg-amber-950/40 px-2 py-0.5 rounded text-[11px] font-semibold">
                        {chapter.price} монет
                      </span>
                    )}
                    <span className="hidden sm:inline">
                      {chapter.wordsCount} слов
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Reviews Tab */}
        {activeTab === "reviews" && (
          <div className="space-y-6">
            {/* Add Review Form */}
            <form
              onSubmit={handleAddReview}
              className="bg-[#131722] border border-white/5 rounded-2xl p-5 sm:p-6"
            >
              <h3 className="text-base font-bold text-white mb-2">
                Написать рецензию
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Поделитесь впечатлениями о произведении с другими читателями
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">
                    Ваше имя или ник:
                  </label>
                  <input
                    type="text"
                    value={reviewerName}
                    onChange={(e) => setReviewerName(e.target.value)}
                    placeholder="Например, Читатель #575882"
                    className="w-full bg-[#0b0e14] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">
                    Ваша оценка: <strong className="text-amber-400">{newReviewRating} / 10</strong>
                  </label>
                  <div className="flex items-center gap-1 pt-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReviewRating(star)}
                        className={`p-1 rounded ${
                          star <= newReviewRating
                            ? "text-amber-400"
                            : "text-slate-600 hover:text-slate-400"
                        }`}
                      >
                        <Star className="w-4 h-4 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mb-3">
                <textarea
                  rows={3}
                  value={newReviewText}
                  onChange={(e) => setNewReviewText(e.target.value)}
                  placeholder="Опишите ваши мысли о сюжете, персонажах и переводе..."
                  className="w-full bg-[#0b0e14] border border-white/10 rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-between">
                {reviewSuccess ? (
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Рецензия опубликована!
                  </span>
                ) : (
                  <span />
                )}

                <button
                  type="submit"
                  disabled={isSubmittingReview || !newReviewText.trim()}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-black font-extrabold text-xs rounded-xl shadow-lg transition-colors"
                >
                  {isSubmittingReview ? "Отправка..." : "Опубликовать рецензию"}
                </button>
              </div>
            </form>

            {/* Reviews List */}
            <div className="space-y-4">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-[#131722] border border-white/5 rounded-2xl p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={rev.userAvatar}
                        alt=""
                        className="w-8 h-8 rounded-full bg-slate-800"
                      />
                      <div>
                        <span className="text-xs font-bold text-white">
                          {rev.userName}
                        </span>
                        <div className="flex items-center gap-1 text-[11px] text-amber-400">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{rev.rating}/10</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal whitespace-pre-line">
                    {rev.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
