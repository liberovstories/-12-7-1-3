"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  BookOpen,
  Compass,
  RefreshCcw,
  Send,
  Sparkles,
  Star,
  X,
} from "lucide-react";
import type { Novel } from "@/types";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  novels?: Novel[];
  time: number;
}

interface AiAssistantModalProps {
  open: boolean;
  onClose: () => void;
  /** Optional proactive opener text used when the modal is triggered from
   * the header's idle tooltip instead of a manual click, so the very first
   * thing the reader sees already feels like Nova reaching out to them. */
  openingLine?: string | null;
}

const SUGGESTION_SETS: string[][] = [
  [
    "Посоветуй фэнтези с системой",
    "Хочу что-то про культивацию",
    "Есть корейские новеллы?",
    "Топ новелл по рейтингу",
  ],
  [
    "Удиви меня чем-нибудь",
    "Хочу грустную драму",
    "Что-то короткое на вечер",
    "Малоизвестные новеллы",
  ],
  [
    "Как купить платную главу?",
    "Как работают закладки?",
    "Где настроить тему сайта?",
    "Хочу что-то про попаданцев",
  ],
];

const IDLE_NUDGES = [
  "Всё ещё думаете, что почитать? Могу предложить что-нибудь на основе того, что мы уже обсуждали 🙂",
  "Кстати, если хотите — я могу показать подборку самых высокооценённых новелл прямо сейчас.",
  "Не теряюсь без дела: если нужна ещё одна подборка или ответ на вопрос про сайт — просто напишите.",
];

const IDLE_TIMEOUT_MS = 45000;
const MAX_IDLE_NUDGES = 2;
const HISTORY_LIMIT = 8;

function createId() {
  return Math.random().toString(36).slice(2);
}

function formatTime(timestamp: number) {
  return new Date(timestamp).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AiAssistantModal({
  open,
  onClose,
  openingLine,
}: AiAssistantModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [suggestionSetIndex, setSuggestionSetIndex] = useState(0);
  const [idleNudgeCount, setIdleNudgeCount] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const idleTimerRef = useRef<number | null>(null);
  const shownNovelSlugsRef = useRef<Set<string>>(new Set());
  const hasInitializedRef = useRef(false);
  const wasOpenRef = useRef(false);

  const clearIdleTimer = useCallback(() => {
    if (idleTimerRef.current) {
      window.clearTimeout(idleTimerRef.current);
      idleTimerRef.current = null;
    }
  }, []);

  const scheduleIdleNudge = useCallback(() => {
    clearIdleTimer();
    idleTimerRef.current = window.setTimeout(() => {
      setIdleNudgeCount((count) => {
        if (count >= MAX_IDLE_NUDGES) return count;
        setMessages((prev) => [
          ...prev,
          {
            id: createId(),
            role: "assistant",
            text: IDLE_NUDGES[count % IDLE_NUDGES.length],
            time: Date.now(),
          },
        ]);
        return count + 1;
      });
    }, IDLE_TIMEOUT_MS);
  }, [clearIdleTimer]);

  // The very first time the modal opens, seed it with a greeting (using the
  // proactive `openingLine` if one was provided by the header's idle
  // nudge). On every later re-open, if a fresh `openingLine` is provided
  // (e.g. the reader clicked a new proactive nudge), append it as a new
  // message instead of resetting the whole conversation.
  useEffect(() => {
    const justOpened = open && !wasOpenRef.current;
    if (justOpened) {
      if (!hasInitializedRef.current) {
        hasInitializedRef.current = true;
        setMessages([
          {
            id: "welcome",
            role: "assistant",
            text:
              openingLine ??
              "Привет! Я Нова — книжный ИИ-помощник NovellRead 📚 Спросите меня о жанре, стране или настроении, и я подберу новеллы из каталога. Также отвечу на любые вопросы о том, как устроен сайт.",
            time: Date.now(),
          },
        ]);
      } else if (openingLine) {
        setMessages((prev) => [
          ...prev,
          {
            id: createId(),
            role: "assistant",
            text: openingLine,
            time: Date.now(),
          },
        ]);
      }
    }
    wasOpenRef.current = open;
  }, [open, openingLine]);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    scheduleIdleNudge();
    return () => {
      document.body.style.overflow = previousOverflow;
      clearIdleTimer();
    };
  }, [open, scheduleIdleNudge, clearIdleTimer]);

  useEffect(() => {
    window.localStorage.setItem(
      "novellread-ai-last-interaction",
      String(Date.now())
    );
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages, isSending]);

  const sendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isSending) return;

    clearIdleTimer();
    setIdleNudgeCount(0);
    window.localStorage.setItem(
      "novellread-ai-last-interaction",
      String(Date.now())
    );

    const userMessage: ChatMessage = {
      id: createId(),
      role: "user",
      text: trimmed,
      time: Date.now(),
    };
    const historyForRequest = [...messages, userMessage]
      .slice(-HISTORY_LIMIT)
      .map((m) => ({ role: m.role, text: m.text }));

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsSending(true);

    try {
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: historyForRequest,
          excludeSlugs: Array.from(shownNovelSlugsRef.current),
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Ошибка ассистента");

      const recommended: Novel[] = data.novels ?? [];
      recommended.forEach((novel) => shownNovelSlugsRef.current.add(novel.slug));

      setMessages((prev) => [
        ...prev,
        {
          id: createId(),
          role: "assistant",
          text: data.reply,
          novels: recommended,
          time: Date.now(),
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: createId(),
          role: "assistant",
          text: "Не удалось получить ответ. Попробуйте ещё раз чуть позже.",
          time: Date.now(),
        },
      ]);
    } finally {
      setIsSending(false);
      scheduleIdleNudge();
    }
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    void sendMessage(input);
  };

  const shuffleSuggestions = () => {
    setSuggestionSetIndex((prev) => (prev + 1) % SUGGESTION_SETS.length);
  };

  if (!open) return null;

  const suggestions = SUGGESTION_SETS[suggestionSetIndex];

  return (
    <div
      className="fixed inset-0 z-[120] flex items-end justify-center bg-black/65 backdrop-blur-sm sm:items-center"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="surface-card border-theme relative flex h-[88vh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl border shadow-2xl sm:h-[660px] sm:rounded-3xl">
        {/* Header */}
        <div className="border-theme relative flex items-center justify-between gap-3 overflow-hidden border-b bg-gradient-to-r from-[var(--surface)] via-[var(--surface-hover)] to-[var(--surface)] px-4 py-3.5">
          <div
            className="pointer-events-none absolute inset-0 opacity-40"
            style={{
              background:
                "radial-gradient(circle at 15% 20%, rgba(var(--primary-rgb), 0.25), transparent 55%)",
            }}
          />
          <div className="relative flex items-center gap-3">
            <div className="assistant-avatar-ring h-11 w-11 shrink-0 rounded-full">
              <div className="h-full w-full overflow-hidden rounded-full border-2 border-[var(--surface)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/assistant/ai-girl-avatar.png"
                  alt="ИИ-помощник"
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
            <div>
              <h2 className="text-body-theme flex items-center gap-1.5 text-sm font-extrabold">
                Нова
                <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              </h2>
              <p className="text-muted-theme flex items-center gap-1.5 text-[11px]">
                <span className="assistant-ping-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
                ИИ-помощник по книгам NovellRead
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-muted-theme relative rounded-lg p-1.5 hover:bg-[var(--surface-active)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Messages */}
        <div
          ref={scrollRef}
          className="assistant-scrollbar flex-1 space-y-4 overflow-y-auto p-4"
        >
          {messages.map((message) => (
            <div
              key={message.id}
              className={`assistant-msg-in flex items-end gap-2 ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {message.role === "assistant" && (
                <div className="h-6 w-6 shrink-0 overflow-hidden rounded-full border border-[var(--border-light)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/images/assistant/ai-girl-avatar.png"
                    alt=""
                    className="h-full w-full object-cover"
                  />
                </div>
              )}

              <div
                className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-sm ${
                  message.role === "user"
                    ? "accent-bg rounded-br-md"
                    : "border-theme text-body-theme rounded-bl-md border bg-[var(--surface-hover)]"
                }`}
              >
                <p className="whitespace-pre-wrap">{message.text}</p>

                {message.novels && message.novels.length > 0 && (
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    {message.novels.map((novel) => (
                      <Link
                        key={novel.id}
                        href={`/novel/${novel.slug}`}
                        onClick={onClose}
                        className="surface-card border-theme group flex items-center gap-2 rounded-xl border p-1.5 transition-colors hover:border-[var(--primary)]/50"
                      >
                        <div className="h-12 w-9 shrink-0 overflow-hidden rounded-lg">
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={novel.coverUrl}
                            alt={novel.title}
                            className="h-full w-full object-cover transition-transform group-hover:scale-105"
                          />
                        </div>
                        <div className="min-w-0">
                          <div className="text-body-theme line-clamp-2 text-[10px] font-bold leading-tight">
                            {novel.title}
                          </div>
                          <div className="mt-0.5 flex items-center gap-0.5 text-[9px] font-semibold text-amber-400">
                            <Star className="h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                            {novel.rating.toFixed(1)}
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                <span
                  className={`mt-1.5 block text-right text-[9px] font-medium ${
                    message.role === "user" ? "text-black/50" : "text-muted-theme"
                  }`}
                >
                  {formatTime(message.time)}
                </span>
              </div>
            </div>
          ))}

          {isSending && (
            <div className="assistant-msg-in flex items-end justify-start gap-2">
              <div className="h-6 w-6 shrink-0 overflow-hidden rounded-full border border-[var(--border-light)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/assistant/ai-girl-avatar.png"
                  alt=""
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="border-theme flex items-center gap-1.5 rounded-2xl rounded-bl-md border bg-[var(--surface-hover)] px-3.5 py-2.5">
                <span className="assistant-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--primary)]" />
                <span className="assistant-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--primary)] [animation-delay:0.15s]" />
                <span className="assistant-typing-dot h-1.5 w-1.5 rounded-full bg-[var(--primary)] [animation-delay:0.3s]" />
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        <div className="border-theme border-t px-3 py-2.5">
          <div className="mb-1.5 flex items-center justify-between px-1">
            <span className="text-muted-theme flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
              <Compass className="h-3 w-3" />
              Быстрые идеи
            </span>
            <button
              type="button"
              onClick={shuffleSuggestions}
              title="Другие варианты"
              className="text-muted-theme flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold transition-colors hover:bg-[var(--surface-hover)] hover:text-body-theme"
            >
              <RefreshCcw className="h-3 w-3" />
              Ещё
            </button>
          </div>
          <div className="no-scrollbar-x flex gap-1.5 overflow-x-auto px-1 pb-0.5">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => void sendMessage(suggestion)}
                className="border-theme text-body-theme shrink-0 whitespace-nowrap rounded-full border bg-[var(--surface-hover)] px-3 py-1.5 text-[11px] font-semibold transition-colors hover:bg-[var(--surface-active)]"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <form
          onSubmit={handleSubmit}
          className="border-theme flex items-center gap-2 border-t p-3"
        >
          <div className="border-theme relative flex-1 rounded-xl border bg-[var(--surface-hover)] transition-colors focus-within:border-[var(--primary)]">
            <BookOpen className="text-muted-theme pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2" />
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Спросите про книги или сайт..."
              maxLength={500}
              className="text-body-theme h-11 w-full rounded-xl bg-transparent pl-8 pr-3 text-xs outline-none placeholder:text-[var(--text-muted)]"
            />
          </div>
          <button
            type="submit"
            disabled={isSending || !input.trim()}
            className="accent-bg flex h-11 w-11 shrink-0 items-center justify-center rounded-xl shadow-md transition-opacity disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
