"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  Bell,
  BellRing,
  Check,
  Heart,
  MessageCircle,
  Settings,
} from "lucide-react";

interface NotificationItem {
  id: string;
  category: "chapters" | "social" | "important";
  icon: React.ReactNode;
  title: string;
  description: string;
  time: string;
  read: boolean;
}

const SAMPLE_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "n1",
    category: "chapters",
    icon: <BellRing className="h-3.5 w-3.5 text-emerald-400" />,
    title: "Вышла новая глава: «Точка зрения Всеведущего читателя»",
    description: "Глава 552 уже доступна для чтения!",
    time: "15 минут назад",
    read: false,
  },
  {
    id: "n2",
    category: "social",
    icon: <Heart className="h-3.5 w-3.5 text-rose-400" />,
    title: "Вашей рецензии поставили лайк",
    description: "Читателям понравился ваш отзыв на «Поднятие уровня в одиночку»",
    time: "2 часа назад",
    read: false,
  },
  {
    id: "n3",
    category: "social",
    icon: <MessageCircle className="h-3.5 w-3.5 text-cyan-400" />,
    title: "Новый ответ на ваш комментарий",
    description: "Читатель ответил в обсуждении главы 12",
    time: "Вчера",
    read: true,
  },
  {
    id: "n4",
    category: "important",
    icon: <Bell className="h-3.5 w-3.5 text-amber-400" />,
    title: "Новый переводчик вступил в команду!",
    description: "Скорость выхода глав увеличена.",
    time: "Вчера",
    read: true,
  },
];

const CATEGORY_TABS: Array<{ id: NotificationItem["category"]; label: string }> = [
  { id: "chapters", label: "Главы" },
  { id: "social", label: "Социальное" },
  { id: "important", label: "Важное" },
];

interface NotificationsPanelProps {
  onClose: () => void;
}

export function NotificationsPanel({ onClose }: NotificationsPanelProps) {
  const [notifications, setNotifications] = useState(SAMPLE_NOTIFICATIONS);
  const [activeCategory, setActiveCategory] =
    useState<NotificationItem["category"]>("chapters");
  const [statusFilter, setStatusFilter] = useState<"new" | "read">("new");

  const filtered = useMemo(() => {
    return notifications.filter(
      (item) =>
        item.category === activeCategory &&
        (statusFilter === "new" ? !item.read : item.read)
    );
  }, [notifications, activeCategory, statusFilter]);

  const unreadCountByCategory = (category: NotificationItem["category"]) =>
    notifications.filter((item) => item.category === category && !item.read)
      .length;

  const totalUnread = notifications.filter((item) => !item.read).length;

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((item) => ({ ...item, read: true })));
    setStatusFilter("read");
  };

  return (
    <div className="surface-card border-theme absolute right-0 z-50 mt-2 w-[min(400px,calc(100vw-24px))] overflow-hidden rounded-2xl border shadow-2xl">
      {/* Header: icon + title on the left, tabs + status pills sharing one row */}
      <div className="border-theme flex flex-wrap items-center justify-between gap-y-2 border-b px-4 py-3">
        <div className="flex items-center gap-2">
          <Bell className="accent-text h-4 w-4" />
          <span className="text-body-theme text-sm font-extrabold">
            Уведомления
          </span>
          {totalUnread > 0 && (
            <span className="accent-bg flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[9px] font-bold leading-none">
              {totalUnread}
            </span>
          )}
        </div>

        {/* Status filter pills */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setStatusFilter("new")}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold transition-colors ${
              statusFilter === "new"
                ? "accent-bg shadow-sm"
                : "text-muted-theme hover:bg-[var(--surface-hover)]"
            }`}
          >
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                statusFilter === "new" ? "bg-white" : "bg-[var(--primary)]"
              }`}
            />
            Новые
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter("read")}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold transition-colors ${
              statusFilter === "read"
                ? "surface-card border text-body-theme shadow-sm"
                : "text-muted-theme hover:bg-[var(--surface-hover)]"
            }`}
          >
            <Check className="h-3 w-3" />
            Прочитанные
          </button>
        </div>
      </div>

      {/* Category Tabs (pill group, matches the reference layout) */}
      <div className="border-theme flex items-center gap-1 border-b bg-[var(--surface-hover)]/40 px-3 py-2">
        {CATEGORY_TABS.map((tab) => {
          const count = unreadCountByCategory(tab.id);
          const active = activeCategory === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveCategory(tab.id)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition-colors ${
                active
                  ? "accent-soft border"
                  : "text-muted-theme hover:bg-[var(--surface-hover)] hover:text-body-theme"
              }`}
            >
              {tab.label}
              {count > 0 && (
                <span
                  className={`flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[9px] font-bold leading-none ${
                    active
                      ? "bg-[var(--primary)] text-white"
                      : "bg-[var(--surface-active)] text-body-theme"
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Notifications list / empty state */}
      <div className="max-h-80 min-h-[180px] overflow-y-auto px-3 py-3">
        {filtered.length === 0 ? (
          <div className="flex h-44 flex-col items-center justify-center text-center">
            <span className="border-theme text-muted-theme mb-3 flex h-12 w-12 items-center justify-center rounded-full border">
              <Bell className="h-5 w-5" />
            </span>
            <p className="text-body-theme text-xs font-bold">
              Пока уведомлений нет
            </p>
            <p className="text-muted-theme mt-1 text-[11px]">
              Здесь появятся новые события
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="border-theme group rounded-xl border bg-[var(--surface-hover)] p-3 transition-colors hover:border-[var(--primary)]/40"
              >
                <div className="flex items-start gap-2.5">
                  <span className="surface-card mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border">
                    {item.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-body-theme text-xs font-semibold leading-snug">
                      {item.title}
                    </p>
                    <p className="text-muted-theme mt-0.5 text-[11px] leading-snug">
                      {item.description}
                    </p>
                    <span
                      className={`mt-1.5 inline-block text-[10px] font-medium ${
                        item.read ? "text-muted-theme" : "accent-text"
                      }`}
                    >
                      {item.time}
                    </span>
                  </div>
                  {!item.read && (
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--primary)]" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-theme flex items-center justify-between gap-3 border-t px-4 py-2.5">
        <button
          type="button"
          onClick={markAllAsRead}
          className="accent-text flex items-center gap-1.5 text-[11px] font-semibold hover:opacity-80"
        >
          <Check className="h-3 w-3" />
          Прочитать все
        </button>
        <Link
          href="/settings?tab=notifications"
          onClick={onClose}
          className="text-muted-theme flex items-center gap-1.5 text-[11px] font-semibold transition-colors hover:text-body-theme"
        >
          <Settings className="h-3 w-3" />
          Настройки уведомлений
        </Link>
      </div>
    </div>
  );
}
