"use client";

import { useState } from "react";
import Link from "next/link";
import { Star, BookOpen, Bookmark, Check } from "lucide-react";
import { Novel } from "@/types";

interface NovelCardProps {
  novel: Novel;
  rank?: number;
  showRank?: boolean;
}

export function NovelCard({ novel, rank, showRank = false }: NovelCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleBookmarkToggle = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSaving(true);
    const nextStatus = isBookmarked ? "remove" : "reading";
    try {
      await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          novelId: novel.id,
          status: nextStatus,
        }),
      });
      setIsBookmarked(!isBookmarked);
    } catch (err) {
      console.error("Bookmark toggle failed", err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="group relative flex flex-col w-full text-left">
      {/* Cover Image Container */}
      <div className="relative aspect-[2/3] w-full rounded-xl overflow-hidden bg-[#151926] border border-white/10 shadow-lg shadow-black/40 transition-all duration-300 group-hover:shadow-emerald-950/40 group-hover:border-emerald-500/50">
        {/* Cover Image */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={novel.coverUrl}
          alt={novel.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
        />

        {/* Top Badges (Always Visible when not hovering) */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-1.5 z-10 transition-opacity duration-200 group-hover:opacity-0 pointer-events-none">
          {/* Left group: Rank + Rating, spaced apart to avoid overlap */}
          <div className="flex items-center gap-1.5 min-w-0">
            {showRank && rank !== undefined && (
              <div
                className={`flex-shrink-0 w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center font-black text-[10px] sm:text-xs shadow-md ${
                  rank === 1
                    ? "bg-gradient-to-br from-amber-300 to-amber-600 text-black shadow-amber-500/30"
                    : rank === 2
                    ? "bg-gradient-to-br from-slate-200 to-slate-400 text-black shadow-slate-400/30"
                    : rank === 3
                    ? "bg-gradient-to-br from-amber-600 to-amber-800 text-white shadow-amber-700/30"
                    : "bg-black/80 backdrop-blur-md text-slate-300 border border-white/10"
                }`}
              >
                #{rank}
              </div>
            )}

            {/* Rating Badge */}
            <div className="flex items-center gap-1 bg-black/75 backdrop-blur-md px-2 py-0.5 rounded-md text-xs font-bold text-amber-400 border border-white/10 shadow-sm flex-shrink-0">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{novel.rating.toFixed(1)}</span>
            </div>
          </div>

          {/* Age Rating Badge */}
          {novel.ageRating && (
            <div className="bg-black/75 backdrop-blur-md px-1.5 py-0.5 rounded-md text-[11px] font-semibold text-slate-300 border border-white/10 shadow-sm flex-shrink-0">
              {novel.ageRating}
            </div>
          )}
        </div>

        {/* Fully Free Badge (bottom-left, always visible) */}
        {novel.fullyFree && (
          <div className="absolute bottom-2.5 left-2.5 z-10 flex items-center gap-1 rounded-md border border-emerald-500/40 bg-emerald-500/90 px-1.5 py-0.5 text-[10px] font-bold text-black shadow-sm transition-opacity duration-200 group-hover:opacity-0">
            Бесплатно
          </div>
        )}

        {/* EXACT NOVELGO HOVER OVERLAY: Description Snippet, Tags, Rating & Quick Actions */}
        <div className="absolute inset-0 z-20 flex flex-col p-2 sm:p-3.5 bg-gradient-to-t from-slate-950/98 via-slate-950/90 to-slate-950/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-300 card-hover-overlay">
          {/* Overlay Top: Badges (fixed height, never shrinks) */}
          <div className="flex items-center justify-between gap-1 flex-shrink-0">
            <div className="flex items-center gap-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 px-1.5 sm:px-2 py-0.5 rounded-md text-[11px] sm:text-xs font-bold">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{novel.rating.toFixed(1)}</span>
            </div>

            <div className="flex items-center gap-1">
              {novel.fullyFree && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500 text-black">
                  Бесплатно
                </span>
              )}
              <span className="hidden sm:inline text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {novel.status}
              </span>
              <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-white/10 text-slate-300">
                {novel.ageRating}
              </span>
            </div>
          </div>

          {/* Overlay Middle: Title & Snippet of Description (flexible, clips instead of overflowing) */}
          <div className="flex-1 min-h-0 overflow-hidden py-1.5 sm:py-2">
            <div className="text-[10px] sm:text-[11px] font-medium text-emerald-400/90 tracking-wide line-clamp-1 mb-0.5">
              {novel.type} • {novel.country}
            </div>
            <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-2 leading-tight drop-shadow-sm mb-1 sm:mb-1.5">
              {novel.title}
            </h4>

            {/* Description Snippet */}
            <p className="hidden sm:block text-xs text-slate-300/95 leading-relaxed line-clamp-3 font-normal">
              {novel.description}
            </p>

            {/* Tags Pills */}
            <div className="hidden sm:flex flex-wrap gap-1 mt-2">
              {novel.genres.slice(0, 2).map((g) => (
                <span
                  key={g}
                  className="text-[10px] text-slate-300 bg-white/10 px-1.5 py-0.5 rounded"
                >
                  {g}
                </span>
              ))}
              {novel.tags && novel.tags.length > 0 && (
                <span className="text-[10px] text-cyan-300 bg-cyan-950/60 border border-cyan-800/40 px-1.5 py-0.5 rounded">
                  {novel.tags[0]}
                </span>
              )}
            </div>
          </div>

          {/* Overlay Bottom: Chapters count & Action Buttons (fixed height, always visible) */}
          <div className="flex-shrink-0 pt-1.5 sm:pt-2 border-t border-white/10">
            <div className="hidden sm:flex items-center justify-between text-[11px] text-slate-400 mb-2">
              <span>{novel.chaptersCount} глав</span>
              <span>{novel.releaseYear} г.</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Link
                href={`/novel/${novel.slug}`}
                className="flex-1 min-w-0 py-1.5 px-1.5 sm:px-2 bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] sm:text-xs font-semibold rounded-lg flex items-center justify-center gap-1 sm:gap-1.5 shadow-md shadow-emerald-950 transition-colors"
              >
                <BookOpen className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">Читать</span>
              </Link>

              <button
                type="button"
                onClick={handleBookmarkToggle}
                disabled={isSaving}
                title={isBookmarked ? "В закладках" : "Добавить в закладки"}
                className={`flex-shrink-0 p-1.5 rounded-lg border transition-all ${
                  isBookmarked
                    ? "bg-rose-500/20 border-rose-500/50 text-rose-400 hover:bg-rose-500/30"
                    : "bg-white/10 border-white/10 text-slate-300 hover:text-white hover:bg-white/20"
                }`}
              >
                {isBookmarked ? (
                  <Check className="w-3.5 h-3.5 text-rose-400" />
                ) : (
                  <Bookmark className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Info Details Below Cover - NovelGo Style */}
      <Link href={`/novel/${novel.slug}`} className="mt-2.5 flex flex-col gap-1">
        {/* Origin / Type Pill */}
        <div className="text-[11px] font-semibold text-emerald-400 tracking-wide truncate">
          {novel.type} • {novel.country}
        </div>

        {/* Genres line */}
        <div className="text-xs text-slate-400 truncate">
          {novel.genres.join(", ")}
        </div>

        {/* Novel Title */}
        <h3 className="text-sm font-semibold text-slate-100 group-hover:text-emerald-400 transition-colors line-clamp-2 leading-snug">
          {novel.title}
        </h3>
      </Link>
    </div>
  );
}
