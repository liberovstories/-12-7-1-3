"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Star, BookOpen, Bookmark, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import { Novel } from "@/types";

interface FeaturedCarouselProps {
  novels: Novel[];
}

export function FeaturedCarousel({ novels }: FeaturedCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (novels.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % novels.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [novels.length]);

  if (!novels || novels.length === 0) return null;

  const current = novels[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? novels.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % novels.length);
  };

  return (
    <div className="surface-card relative w-full rounded-2xl sm:rounded-3xl overflow-hidden border shadow-2xl my-6 group">
      {/* Background Ambient Glow Image */}
      <div
        className="absolute inset-0 bg-cover bg-center filter blur-3xl opacity-30 scale-110 pointer-events-none transition-all duration-700"
        style={{ backgroundImage: `url(${current.bannerUrl || current.coverUrl})` }}
      />
      <div className="hero-fade-x absolute inset-0 z-0 pointer-events-none" />

      {/* Hero Content Grid */}
      <div className="relative z-10 flex flex-col-reverse md:flex-row items-center justify-between p-6 sm:p-8 md:p-10 gap-8 min-h-[380px]">
        {/* Left Info Column */}
        <div className="flex-1 max-w-2xl text-left space-y-4">
          {/* Top Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="accent-soft inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border">
              <Sparkles className="w-3.5 h-3.5" />
              Топ Китая и Кореи
            </span>

            <div className="flex items-center gap-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full text-xs font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{current.rating.toFixed(1)}</span>
            </div>

            <span className="surface-card text-xs font-medium px-2.5 py-1 rounded-full border text-muted-theme">
              {current.ageRating}
            </span>

            <span className="accent-soft text-xs font-semibold px-2.5 py-1 rounded-full border">
              {current.type} • {current.country}
            </span>
          </div>

          {/* Title */}
          <div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-body-theme tracking-tight leading-tight">
              {current.title}
            </h2>
            {current.englishTitle && (
              <p className="text-sm font-medium text-muted-theme mt-1">
                {current.englishTitle}
              </p>
            )}
          </div>

          {/* Description Excerpt */}
          <p className="text-sm text-muted-theme leading-relaxed line-clamp-3 md:line-clamp-4 font-normal">
            {current.description}
          </p>

          {/* Genres Chips */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {current.genres.map((genre) => (
              <span
                key={genre}
                className="surface-card surface-card-hover text-xs font-medium px-2.5 py-1 rounded-lg text-muted-theme border transition-colors"
              >
                {genre}
              </span>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-3">
            <Link
              href={`/novel/${current.slug}`}
              className="accent-bg px-6 py-3 font-extrabold text-sm rounded-xl flex items-center gap-2 shadow-lg transition-all transform active:scale-95 hover:brightness-110"
            >
              <BookOpen className="w-4 h-4" />
              <span>Читать онлайн</span>
            </Link>

            <Link
              href={`/novel/${current.slug}#chapters`}
              className="surface-card surface-card-hover px-4 py-3 text-body-theme font-semibold text-sm rounded-xl flex items-center gap-2 border transition-colors"
            >
              <Bookmark className="w-4 h-4 text-rose-400" />
              <span>Оглавление ({current.chaptersCount})</span>
            </Link>
          </div>
        </div>

        {/* Right Cover Column */}
        <div className="relative flex-shrink-0 w-44 sm:w-52 md:w-60">
          <div className="relative aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl border-2 border-theme group-hover:border-[var(--primary)]/50 transition-all duration-300 transform group-hover:scale-[1.02]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={current.coverUrl}
              alt={current.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-3 left-3 right-3 text-center">
              <span className="text-[11px] font-bold text-white bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/20">
                {current.chaptersCount} глав переведено
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Carousel Navigation Arrows & Indicators */}
      <div className="absolute bottom-4 right-6 z-20 flex items-center gap-2">
        <button
          onClick={handlePrev}
          className="p-2 rounded-xl bg-black/50 hover:bg-black/80 backdrop-blur-md text-white border border-white/10 transition-colors"
          title="Предыдущая"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 px-2">
          {novels.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-1.5 rounded-full transition-all ${
                index === currentIndex
                  ? "w-6 bg-[var(--primary)]"
                  : "w-2 bg-white/30 hover:bg-white/60"
              }`}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          className="p-2 rounded-xl bg-black/50 hover:bg-black/80 backdrop-blur-md text-white border border-white/10 transition-colors"
          title="Следующая"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
