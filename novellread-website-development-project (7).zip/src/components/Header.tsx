"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bell,
  BookOpen,
  Bookmark,
  ChevronDown,
  Coins,
  Compass,
  History,
  Languages,
  Layers,
  MoreHorizontal,
  PenLine,
  Search,
  Send,
  Settings,
  Shuffle,
  Sparkles,
  Star,
  User,
  Wallet,
  X,
} from "lucide-react";
import { SearchModal } from "@/components/SearchModal";
import { BALANCE_EVENT, TopUpModal } from "@/components/TopUpModal";
import { AiAssistantModal } from "@/components/AiAssistantModal";
import { NotificationsPanel } from "@/components/NotificationsPanel";

export function Header() {
  const router = useRouter();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isOtherMenuOpen, setIsOtherMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isQuickActionsOpen, setIsQuickActionsOpen] = useState(false);
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [assistantOpeningLine, setAssistantOpeningLine] = useState<string | null>(null);
  const [assistantNudge, setAssistantNudge] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [lastBookmark, setLastBookmark] = useState<{
    slug: string;
    chapter: number;
  } | null>(null);
  const [profile, setProfile] = useState({
    displayName: "Dmitry",
    username: "dmitry575882",
    avatarUrl: "https://api.dicebear.com/7.x/bottts/svg?seed=Reader575882",
  });
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const quickActionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        userMenuRef.current &&
        !userMenuRef.current.contains(event.target as Node)
      ) {
        setIsUserMenuOpen(false);
        setIsOtherMenuOpen(false);
      }
      if (
        notificationsRef.current &&
        !notificationsRef.current.contains(event.target as Node)
      ) {
        setIsNotificationsOpen(false);
      }
      if (
        quickActionsRef.current &&
        !quickActionsRef.current.contains(event.target as Node)
      ) {
        setIsQuickActionsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const handleSearchShortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handleSearchShortcut);
    return () => window.removeEventListener("keydown", handleSearchShortcut);
  }, []);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const response = await fetch("/api/settings");
        const data = await response.json();
        if (data.settings) {
          setProfile({
            displayName: data.settings.displayName,
            username: data.settings.username,
            avatarUrl: data.settings.avatarUrl,
          });
          setBalance(data.settings.balance);
        }
      } catch {
        // The default profile remains visible if settings are temporarily unavailable.
      }
    };

    const loadLastBookmark = async () => {
      try {
        const response = await fetch("/api/bookmarks");
        const data = await response.json();
        const readingBookmarks = (data.bookmarks ?? []).filter(
          (bookmark: { status: string }) => bookmark.status === "reading"
        );
        const mostRecent = readingBookmarks.sort(
          (a: { updatedAt: string }, b: { updatedAt: string }) =>
            new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        )[0];
        if (mostRecent) {
          setLastBookmark({
            slug: mostRecent.novel.slug,
            chapter: mostRecent.lastReadChapter || 1,
          });
        }
      } catch {
        // No continue-reading shortcut if bookmarks cannot be loaded.
      }
    };

    const handleProfileChange = (event: Event) => {
      const detail = (event as CustomEvent<typeof profile>).detail;
      if (detail) setProfile(detail);
    };

    const handleBalanceChange = (event: Event) => {
      const detail = (event as CustomEvent<{ balance: number }>).detail;
      if (detail) setBalance(detail.balance);
    };

    void loadProfile();
    void loadLastBookmark();
    window.addEventListener("novellread-profile-change", handleProfileChange);
    window.addEventListener(BALANCE_EVENT, handleBalanceChange);
    return () => {
      window.removeEventListener("novellread-profile-change", handleProfileChange);
      window.removeEventListener(BALANCE_EVENT, handleBalanceChange);
    };
  }, []);

  const handleRandomNovel = async () => {
    setIsQuickActionsOpen(false);
    try {
      const response = await fetch("/api/novels");
      const data = await response.json();
      if (data.items?.length) {
        const randomNovel =
          data.items[Math.floor(Math.random() * data.items.length)];
        router.push(`/novel/${randomNovel.slug}`);
      }
    } catch {
      router.push("/catalog");
    }
  };

  const openSearch = () => {
    setIsSearchOpen(true);
  };

  // Proactively invite the reader to chat with Nova if they've been
  // browsing for a while without opening the assistant. This is fully
  // client-driven (no push notifications/websockets available), using a
  // simple timer plus localStorage so the nudge doesn't reappear on every
  // page navigation within the same session.
  useEffect(() => {
    const NUDGE_MESSAGES = [
      "Привет! Я Нова 👋 Если не знаете, что почитать дальше — просто спросите, помогу подобрать новеллу.",
      "Заметила, что вы уже давно листаете каталог. Хотите, подберу что-то по вашему вкусу?",
      "Кстати, я умею не только советовать книги, но и подсказывать по функциям сайта — спрашивайте!",
    ];

    const alreadyShown = window.sessionStorage.getItem(
      "novellread-ai-nudge-shown"
    );
    if (alreadyShown) return;

    const lastInteraction = Number(
      window.localStorage.getItem("novellread-ai-last-interaction") || 0
    );
    const msSinceInteraction = Date.now() - lastInteraction;
    // Only skip the nudge if the reader talked to Nova very recently.
    if (lastInteraction && msSinceInteraction < 5 * 60 * 1000) return;

    const timer = window.setTimeout(() => {
      setAssistantNudge(
        NUDGE_MESSAGES[Math.floor(Math.random() * NUDGE_MESSAGES.length)]
      );
      window.sessionStorage.setItem("novellread-ai-nudge-shown", "true");

      window.setTimeout(() => {
        setAssistantNudge((current) => current);
      }, 100);
    }, 60000);

    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!assistantNudge) return;
    const autoHide = window.setTimeout(() => setAssistantNudge(null), 12000);
    return () => window.clearTimeout(autoHide);
  }, [assistantNudge]);

  const openAssistantFromNudge = () => {
    setAssistantOpeningLine(assistantNudge);
    setAssistantNudge(null);
    setIsAssistantOpen(true);
  };

  return (
    <>
      <header className="glass-nav sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-3 sm:gap-5">
            <Link
              href="/"
              className="group flex shrink-0 items-center gap-2.5"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 shadow-lg shadow-emerald-500/20 transition-transform duration-200 group-hover:scale-105">
                <span className="text-sm font-black tracking-tighter text-black">
                  NR
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-body-theme text-lg font-extrabold tracking-tight transition-colors group-hover:text-[var(--primary)]">
                  Novell<span className="accent-text">Read</span>
                </span>
                <span className="text-muted-theme -mt-1 text-[10px] font-bold uppercase tracking-wider">
                  Книги & Ранобэ
                </span>
              </div>
            </Link>

            <nav className="no-scrollbar flex min-w-0 items-center gap-1 overflow-x-auto">
              <Link
                href="/catalog"
                className="text-body-theme flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors hover:bg-[var(--surface-hover)]"
              >
                <Layers className="h-4 w-4 text-emerald-400" />
                <span className="hidden lg:inline">Каталог</span>
              </Link>
              <Link
                href="/top"
                className="text-body-theme flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors hover:bg-[var(--surface-hover)]"
              >
                <Star className="h-4 w-4 text-amber-400" />
                <span className="hidden lg:inline">Топ</span>
              </Link>
              <Link
                href="/collections"
                className="text-body-theme flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors hover:bg-[var(--surface-hover)]"
              >
                <Compass className="h-4 w-4 text-cyan-400" />
                <span className="hidden lg:inline">Подборки</span>
              </Link>
              <Link
                href="/fandoms"
                className="text-body-theme flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors hover:bg-[var(--surface-hover)]"
              >
                <Sparkles className="h-4 w-4 text-purple-400" />
                <span className="hidden lg:inline">Фандомы</span>
              </Link>
              <Link
                href="/bookmarks"
                className="text-body-theme flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors hover:bg-[var(--surface-hover)]"
              >
                <Bookmark className="h-4 w-4 text-rose-400" />
                <span className="hidden lg:inline">Закладки</span>
              </Link>
            </nav>

            <button
              type="button"
              onClick={openSearch}
              className="border-theme text-muted-theme group hidden h-10 min-w-0 max-w-[310px] flex-1 items-center gap-2.5 rounded-[20px] border bg-[var(--surface-hover)] px-3.5 text-left text-[13px] font-semibold transition-colors hover:bg-[var(--surface-active)] sm:flex"
              aria-label="Открыть поиск"
            >
              <Search className="text-body-theme h-4 w-4 shrink-0" />
              <span className="truncate">Что ищем, семпай?</span>
              <span className="border-theme text-muted-theme ml-auto hidden rounded-md border bg-[var(--surface-active)] px-1.5 py-0.5 text-[10px] lg:inline">
                Ctrl K
              </span>
            </button>

            <div className="flex shrink-0 items-center gap-1 sm:gap-2">
              <button
                type="button"
                onClick={openSearch}
                title="Поиск"
                className="text-body-theme rounded-xl p-2 transition-colors hover:bg-[var(--surface-hover)] sm:hidden"
              >
                <Search className="h-5 w-5" />
              </button>

              <div ref={quickActionsRef} className="relative hidden md:block">
                <button
                  type="button"
                  onClick={() => setIsQuickActionsOpen(!isQuickActionsOpen)}
                  title="Быстрые действия"
                  className="text-muted-theme rounded-xl p-2 transition-colors hover:bg-[var(--surface-hover)] hover:text-body-theme"
                >
                  <Shuffle className="h-5 w-5" />
                </button>

                {isQuickActionsOpen && (
                  <div className="surface-card absolute right-0 z-50 mt-2 w-64 rounded-xl border p-2 shadow-2xl">
                    <div className="text-muted-theme px-2 pb-1.5 pt-1 text-[11px] font-bold uppercase tracking-wider">
                      Быстрые действия
                    </div>
                    <button
                      type="button"
                      onClick={handleRandomNovel}
                      className="text-body-theme flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-colors hover:bg-[var(--surface-hover)]"
                    >
                      <Shuffle className="h-4 w-4 text-emerald-400" />
                      Случайная новелла
                    </button>
                    {lastBookmark && (
                      <Link
                        href={`/novel/${lastBookmark.slug}/chapter/${lastBookmark.chapter}`}
                        onClick={() => setIsQuickActionsOpen(false)}
                        className="text-body-theme flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <BookOpen className="h-4 w-4 text-cyan-400" />
                        Продолжить чтение
                      </Link>
                    )}
                    <Link
                      href="/top"
                      onClick={() => setIsQuickActionsOpen(false)}
                      className="text-body-theme flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-semibold transition-colors hover:bg-[var(--surface-hover)]"
                    >
                      <Star className="h-4 w-4 text-amber-400" />
                      Топ новелл
                    </Link>
                  </div>
                )}
              </div>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setAssistantOpeningLine(null);
                    setAssistantNudge(null);
                    setIsAssistantOpen(true);
                  }}
                  title="ИИ-помощник по книгам"
                  className={`relative h-9 w-9 shrink-0 overflow-hidden rounded-full border-2 shadow-md transition-transform hover:scale-105 ${
                    assistantNudge
                      ? "assistant-avatar-ring border-transparent"
                      : "border-[var(--primary)]/50"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/images/assistant/ai-girl-avatar.png"
                    alt="ИИ-помощник"
                    className="h-full w-full object-cover"
                  />
                  <span className="absolute -bottom-0.5 -right-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-emerald-500 ring-2 ring-[var(--background)]">
                    <Sparkles className="h-2 w-2 text-white" />
                  </span>
                </button>

                {/* Proactive "Nova" nudge bubble: appears if the reader has
                    been idle for a while without talking to the assistant. */}
                {assistantNudge && (
                  <div className="assistant-nudge-in surface-card border-theme absolute right-0 top-12 z-50 w-64 rounded-2xl border p-3 shadow-2xl">
                    <div className="flex items-start gap-2">
                      <div className="h-7 w-7 shrink-0 overflow-hidden rounded-full border border-[var(--border-light)]">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src="/images/assistant/ai-girl-avatar.png"
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-body-theme text-[11px] font-bold">
                          Нова
                        </p>
                        <p className="text-muted-theme mt-0.5 text-[11px] leading-snug">
                          {assistantNudge}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setAssistantNudge(null)}
                        className="text-muted-theme shrink-0 rounded-md p-0.5 hover:bg-[var(--surface-hover)]"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={openAssistantFromNudge}
                      className="accent-bg mt-2.5 w-full rounded-lg py-1.5 text-[11px] font-extrabold"
                    >
                      Ответить
                    </button>
                  </div>
                )}
              </div>

              <div ref={notificationsRef} className="relative">
                <button
                  type="button"
                  onClick={() =>
                    setIsNotificationsOpen(!isNotificationsOpen)
                  }
                  className="text-body-theme relative rounded-xl p-2 transition-colors hover:bg-[var(--surface-hover)]"
                  title="Уведомления"
                >
                  <Bell className="h-5 w-5" />
                  <span className="absolute right-1.5 top-1.5 h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                </button>

                {isNotificationsOpen && (
                  <NotificationsPanel
                    onClose={() => setIsNotificationsOpen(false)}
                  />
                )}
              </div>

              <div ref={userMenuRef} className="relative">
                <button
                  type="button"
                  onClick={() => {
                    const nextOpen = !isUserMenuOpen;
                    setIsUserMenuOpen(nextOpen);
                    if (!nextOpen) setIsOtherMenuOpen(false);
                  }}
                  className="flex flex-col items-center gap-1 rounded-xl border border-transparent px-1 py-1 transition-colors hover:border-theme hover:bg-[var(--surface-hover)]"
                >
                  <span className="flex items-center gap-1.5">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={profile.avatarUrl}
                      alt={profile.displayName}
                      className="h-8 w-8 rounded-lg border border-[var(--primary)]/30 bg-[var(--surface-hover)] object-cover"
                    />
                    <ChevronDown className="text-muted-theme hidden h-3.5 w-3.5 sm:block" />
                  </span>
                  <span className="accent-soft flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[9px] font-bold leading-none">
                    <Coins className="h-2.5 w-2.5 text-amber-400" />
                    {balance !== null ? balance.toLocaleString("ru-RU") : "…"}
                  </span>
                </button>

                {isUserMenuOpen && (
                  <div className="surface-card divide-theme absolute right-0 z-50 mt-2 w-64 divide-y rounded-xl border py-2 shadow-2xl">
                    <div className="px-4 py-3">
                      <p className="text-body-theme flex items-center justify-between gap-2 text-sm font-bold">
                        <span className="truncate">{profile.displayName}</span>
                        <span className="accent-soft max-w-[112px] truncate rounded px-1.5 py-0.5 font-mono text-[10px]">
                          @{profile.username}
                        </span>
                      </p>
                      <p className="text-muted-theme mt-0.5 text-xs">
                        Статус:{" "}
                        <span className="accent-text font-medium">
                          Мастер переводов
                        </span>
                      </p>
                      <div className="text-muted-theme mt-2 flex items-center gap-3 text-[11px]">
                        <span>
                          Карма: <strong className="accent-text">+482</strong>
                        </span>
                        <span>
                          Глав:{" "}
                          <strong className="text-body-theme">1,420</strong>
                        </span>
                      </div>
                    </div>

                    <div className="px-3 pb-1 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setIsTopUpOpen(true);
                          setIsUserMenuOpen(false);
                          setIsOtherMenuOpen(false);
                        }}
                        className="accent-soft flex w-full items-center justify-between rounded-xl border px-3 py-2 text-xs font-extrabold"
                      >
                        <span className="flex items-center gap-2">
                          <Wallet className="h-4 w-4" />
                          Пополнить
                        </span>
                        <span className="flex items-center gap-1 text-[11px] font-bold">
                          <Coins className="h-3.5 w-3.5 text-amber-400" />
                          {balance !== null ? balance.toLocaleString("ru-RU") : "…"}
                        </span>
                      </button>
                    </div>

                    <div className="py-1">
                      <Link
                        href="/bookmarks"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="text-body-theme flex items-center gap-2.5 px-4 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <Bookmark className="h-4 w-4 text-rose-400" />
                        Мои закладки
                      </Link>
                      <Link
                        href="/bookmarks"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="text-body-theme flex items-center gap-2.5 px-4 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <History className="h-4 w-4 text-cyan-400" />
                        История чтения
                      </Link>
                      <Link
                        href="/profile"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="text-body-theme flex items-center gap-2.5 px-4 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <User className="h-4 w-4 text-amber-400" />
                        Профиль читателя
                      </Link>
                      <Link
                        href="/profile?tab=translations"
                        onClick={() => setIsUserMenuOpen(false)}
                        className="text-body-theme flex items-center gap-2.5 px-4 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <Languages className="h-4 w-4 text-emerald-400" />
                        Мои переводы
                      </Link>
                    </div>

                    <div className="py-1">
                      <button
                        type="button"
                        onClick={() => setIsOtherMenuOpen(!isOtherMenuOpen)}
                        className="text-body-theme flex w-full items-center gap-2.5 px-4 py-2 text-xs font-semibold transition-colors hover:bg-[var(--surface-hover)]"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                        <span>Другое</span>
                        <ChevronDown
                          className={`ml-auto h-3.5 w-3.5 transition-transform ${
                            isOtherMenuOpen ? "rotate-180" : ""
                          }`}
                        />
                      </button>

                      {isOtherMenuOpen && (
                        <div className="mx-2 mb-1 overflow-hidden rounded-xl bg-[var(--surface-hover)] py-1">
                          <Link
                            href="/settings?tab=profile"
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              setIsOtherMenuOpen(false);
                            }}
                            className="text-body-theme flex items-center gap-2.5 px-3 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-active)]"
                          >
                            <Settings className="h-4 w-4" />
                            Настройки
                          </Link>
                          <Link
                            href="/translation/suggest"
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              setIsOtherMenuOpen(false);
                            }}
                            className="text-body-theme flex items-center gap-2.5 px-3 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-active)]"
                          >
                            <Send className="h-4 w-4" />
                            Предложить перевод
                          </Link>
                          <Link
                            href="/publish/start"
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              setIsOtherMenuOpen(false);
                            }}
                            className="text-body-theme flex items-center gap-2.5 px-3 py-2 text-xs font-medium transition-colors hover:bg-[var(--surface-active)]"
                          >
                            <PenLine className="h-4 w-4" />
                            Начать публиковать
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <SearchModal
        open={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />

      <TopUpModal
        open={isTopUpOpen}
        onClose={() => setIsTopUpOpen(false)}
        onSuccess={(newBalance) => setBalance(newBalance)}
      />

      <AiAssistantModal
        open={isAssistantOpen}
        onClose={() => {
          setIsAssistantOpen(false);
          setAssistantOpeningLine(null);
        }}
        openingLine={assistantOpeningLine}
      />
    </>
  );
}
