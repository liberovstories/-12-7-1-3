import Link from "next/link";
import { Clock, BookOpen, ArrowRight, Flame } from "lucide-react";
import { Novel } from "@/types";

interface PopularUpdatesSectionProps {
  novels: Novel[];
}

export function PopularUpdatesSection({ novels }: PopularUpdatesSectionProps) {
  const updates = [
    {
      novel: novels[0],
      chapter: "Том 5. Глава 551 (Финал)",
      time: "10 минут назад",
      translator: "Rainbow Turtle & NovellRead",
    },
    {
      novel: novels[1] || novels[0],
      chapter: "Том 2. Глава 340: Прощай, Академия!",
      time: "42 минуты назад",
      translator: "NovellRead Team",
    },
    {
      novel: novels[2] || novels[0],
      chapter: "Том 8. Глава 1200: Чернокнижник 9 ранга",
      time: "2 часа назад",
      translator: "Dark Magus TL",
    },
    {
      novel: novels[3] || novels[0],
      chapter: "Том 10. Глава 1463: Механическая империя",
      time: "3 часа назад",
      translator: "MechEmpire",
    },
    {
      novel: novels[4] || novels[0],
      chapter: "Том 3. Глава 231: Выбор Каллисто",
      time: "5 часов назад",
      translator: "Imperial Garden",
    },
    {
      novel: novels[5] || novels[0],
      chapter: "Том 1. Глава 270: Теневой Монарх",
      time: "Вчера",
      translator: "D&C Media / Rulate Team",
    },
  ];

  return (
    <section className="my-12">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
            <Flame className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Популярные обновления
            </h3>
            <p className="text-xs text-slate-400">
              Свежие главы, переведенные сегодня
            </p>
          </div>
        </div>

        <Link
          href="/catalog?sortBy=updates"
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
        >
          <span>Все обновления</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {updates.map((item, index) => {
          if (!item.novel) return null;
          return (
            <div
              key={index}
              className="group bg-[#131722] hover:bg-[#181e30] border border-white/5 hover:border-emerald-500/40 rounded-xl p-3 sm:p-4 transition-all duration-300 shadow-md flex items-center gap-3.5"
            >
              {/* Cover */}
              <Link
                href={`/novel/${item.novel.slug}`}
                className="relative w-16 h-22 flex-shrink-0 rounded-lg overflow-hidden border border-white/10 group-hover:scale-105 transition-transform"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.novel.coverUrl}
                  alt={item.novel.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-1 left-1 bg-rose-600 text-[9px] font-black uppercase text-white px-1 py-0.2 rounded shadow">
                  NEW
                </span>
              </Link>

              {/* Details */}
              <div className="flex-1 min-w-0">
                <Link
                  href={`/novel/${item.novel.slug}`}
                  className="text-sm font-bold text-slate-100 group-hover:text-emerald-400 truncate block transition-colors"
                >
                  {item.novel.title}
                </Link>

                <Link
                  href={`/novel/${item.novel.slug}`}
                  className="text-xs text-emerald-400/90 hover:text-emerald-300 font-medium truncate block mt-1 flex items-center gap-1"
                >
                  <BookOpen className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                  <span className="truncate">{item.chapter}</span>
                </Link>

                <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                  <span className="truncate max-w-[140px] text-slate-500">
                    {item.translator}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] text-slate-400 flex-shrink-0">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {item.time}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
