"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeft,
  BookOpenText,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Coins,
  Download,
  Gauge,
  Lock,
  MessageSquare,
  Palette,
  Pause,
  Pencil,
  PlusCircle,
  Trash2,
  Play,
  List as ListIcon,
  RotateCcw,
  Send,
  Settings as SettingsIcon,
  Sparkles,
  Type,
  X,
  Zap,
} from "lucide-react";
import type { Chapter, ChapterComment, ChapterNote, Novel } from "@/types";
import {
  darkReaderThemes,
  lightReaderThemes,
  getReaderThemeById,
} from "@/data/reader-themes";
import {
  applyReaderThemeOverride,
  clearReaderThemeOverride,
} from "@/components/ThemeProvider";
import { BALANCE_EVENT } from "@/components/TopUpModal";
import { ToggleSwitch } from "@/components/ui/ToggleSwitch";

interface ReaderViewProps {
  novel: Novel;
  chapter: Chapter;
  allChapters: Chapter[];
  purchasedChapterIds: number[];
  initialComments: ChapterComment[];
  initialBalance: number;
}

type ReaderPanel = "comments" | "toc" | "settings" | "notes" | null;

interface FontOption {
  id: string;
  label: string;
  family: string;
}

const FONT_OPTIONS: FontOption[] = [
  {
    id: "geist",
    label: "Geist (по умолчанию)",
    family:
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
  },
  { id: "roboto", label: "Roboto", family: "Roboto, Arial, sans-serif" },
  {
    id: "inter",
    label: "Inter",
    family: "Inter, -apple-system, BlinkMacSystemFont, sans-serif",
  },
  { id: "nunito", label: "Nunito", family: "Nunito, sans-serif" },
  { id: "lora", label: "Lora", family: "Lora, Georgia, serif" },
  {
    id: "merriweather",
    label: "Merriweather",
    family: "Merriweather, Georgia, serif",
  },
  {
    id: "georgia",
    label: "Georgia",
    family: "Georgia, 'Times New Roman', serif",
  },
  {
    id: "geist-mono",
    label: "Geist Mono",
    family:
      "ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace",
  },
];

function getFontFamily(id: string) {
  return FONT_OPTIONS.find((f) => f.id === id)?.family ?? FONT_OPTIONS[0].family;
}

interface ReaderSettingsState {
  themeId: string;
  fontId: string;
  fontSizePercent: number;
  widthPercent: number;
  textAlign: "left" | "center" | "right";
  progressBarEnabled: boolean;
  bionicReading: boolean;
  autoscrollSpeed: number;
  readingMode: "paged" | "scroll";
}

const DEFAULT_READER_SETTINGS: ReaderSettingsState = {
  themeId: "reader-dark",
  fontId: "geist",
  fontSizePercent: 100,
  widthPercent: 100,
  textAlign: "left",
  progressBarEnabled: true,
  bionicReading: false,
  autoscrollSpeed: 4,
  readingMode: "paged",
};

const STORAGE_KEY = "novellread-reader-settings-v2";
const BASE_FONT_PX = 18;
const BASE_WIDTH_REM = 44;

function loadStoredSettings(): ReaderSettingsState {
  if (typeof window === "undefined") return DEFAULT_READER_SETTINGS;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return DEFAULT_READER_SETTINGS;
    const parsed = JSON.parse(stored) as Partial<ReaderSettingsState>;
    return { ...DEFAULT_READER_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_READER_SETTINGS;
  }
}

interface PurchaseTarget {
  chapter: Chapter;
  navigateAfter: boolean;
}

/** Renders a single word with its leading portion bolded ("bionic reading"),
 * which is meant to give the eye a fixation anchor so the rest of the word
 * can be inferred, speeding up reading. */
function renderBionicWord(word: string, key: number) {
  if (!/[a-zA-Zа-яА-ЯёЁ]/.test(word)) {
    return <span key={key}>{word}</span>;
  }
  const boldLength = Math.max(1, Math.ceil(word.length * 0.45));
  return (
    <span key={key}>
      <strong className="font-bold">{word.slice(0, boldLength)}</strong>
      {word.slice(boldLength)}
    </span>
  );
}

/**
 * Bolds only the leading letters of the FIRST word in a paragraph, giving
 * the eye a single fixation anchor at the start of each paragraph rather
 * than bolding every word throughout it.
 */
function renderParagraphText(text: string, bionic: boolean) {
  if (!bionic) return text;
  const tokens = text.split(/(\s+)/);
  let firstWordBolded = false;
  return tokens.map((token, i) => {
    if (/^\s+$/.test(token) || token.length === 0) {
      return <span key={i}>{token}</span>;
    }
    if (!firstWordBolded) {
      firstWordBolded = true;
      return renderBionicWord(token, i);
    }
    return <span key={i}>{token}</span>;
  });
}

/** Range slider with a colored fill track (matches the reference reader's
 * sliders) built from a computed linear-gradient rather than relying on
 * browser-default track styling. */
function ReaderRange({
  value,
  min,
  max,
  step = 1,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
}) {
  const percent = ((value - min) / (max - min)) * 100;
  return (
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="reader-range w-full"
      style={{
        background: `linear-gradient(to right, var(--primary) ${percent}%, var(--surface-active) ${percent}%)`,
      }}
    />
  );
}

function PanelHeader({
  icon,
  title,
  onClose,
  extra,
}: {
  icon: React.ReactNode;
  title: string;
  onClose: () => void;
  extra?: React.ReactNode;
}) {
  return (
    <div className="border-theme sticky top-0 z-10 flex items-center justify-between gap-2 border-b bg-[var(--surface)]/95 px-4 py-3.5 backdrop-blur-md">
      <div className="flex min-w-0 items-center gap-2.5">
        <span className="accent-soft flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border">
          {icon}
        </span>
        <h2 className="text-body-theme truncate text-sm font-extrabold">
          {title}
        </h2>
      </div>
      <div className="flex shrink-0 items-center gap-1">
        {extra}
        <button
          onClick={onClose}
          className="text-muted-theme rounded-lg p-1.5 hover:bg-[var(--surface-hover)]"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function ReaderView({
  novel,
  chapter,
  allChapters,
  purchasedChapterIds,
  initialComments,
  initialBalance,
}: ReaderViewProps) {
  const router = useRouter();

  const [readerSettings, setReaderSettings] = useState<ReaderSettingsState>(
    DEFAULT_READER_SETTINGS
  );
  const readerSettingsRef = useRef(readerSettings);
  useEffect(() => {
    readerSettingsRef.current = readerSettings;
  }, [readerSettings]);

  useEffect(() => {
    setReaderSettings(loadStoredSettings());
  }, []);

  const persistSettings = useCallback((next: ReaderSettingsState) => {
    setReaderSettings(next);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const updateSetting = useCallback(
    <K extends keyof ReaderSettingsState>(key: K, value: ReaderSettingsState[K]) => {
      persistSettings({ ...readerSettingsRef.current, [key]: value });
    },
    [persistSettings]
  );

  const resetSettings = useCallback(() => {
    persistSettings(DEFAULT_READER_SETTINGS);
  }, [persistSettings]);

  const [activePanel, setActivePanel] = useState<ReaderPanel>(null);
  const [isFontMenuOpen, setIsFontMenuOpen] = useState(false);
  const fontMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        fontMenuRef.current &&
        !fontMenuRef.current.contains(event.target as Node)
      ) {
        setIsFontMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const [scrollProgress, setScrollProgress] = useState(0);
  const [purchasedIds, setPurchasedIds] = useState<Set<number>>(
    () => new Set(purchasedChapterIds)
  );
  const [balance, setBalance] = useState(initialBalance);
  const [purchaseTarget, setPurchaseTarget] = useState<PurchaseTarget | null>(
    null
  );
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState("");

  const [comments, setComments] = useState<ChapterComment[]>(initialComments);
  const [commentText, setCommentText] = useState("");
  const [commentSpoiler, setCommentSpoiler] = useState(false);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [revealedSpoilers, setRevealedSpoilers] = useState<Set<number>>(
    new Set()
  );
  // Comments no longer ask the reader to type their name or send one from
  // the client at all — the server always attaches the reader's real
  // NovellRead profile name and avatar (including any custom uploaded
  // photo) when a comment is created, so it can never drift out of sync
  // with what's shown in the header/profile.

  const [notes, setNotes] = useState<ChapterNote[]>([]);
  const [notesLoaded, setNotesLoaded] = useState(false);
  const [isNotesLoading, setIsNotesLoading] = useState(false);
  const [isCreatingNote, setIsCreatingNote] = useState(false);
  const [noteDraft, setNoteDraft] = useState("");
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [isSavingNote, setIsSavingNote] = useState(false);

  const loadNotes = useCallback(async () => {
    setIsNotesLoading(true);
    try {
      const response = await fetch(`/api/chapters/${chapter.id}/notes`);
      const data = await response.json();
      setNotes(data.notes ?? []);
    } catch (err) {
      console.error("Failed to load notes", err);
    } finally {
      setIsNotesLoading(false);
      setNotesLoaded(true);
    }
  }, [chapter.id]);

  useEffect(() => {
    setNotes([]);
    setNotesLoaded(false);
    setIsCreatingNote(false);
    setEditingNoteId(null);
    setNoteDraft("");
  }, [chapter.id]);

  const openNoteEditor = (existing?: ChapterNote) => {
    if (existing) {
      setEditingNoteId(existing.id);
      setNoteDraft(existing.text);
    } else {
      setEditingNoteId(null);
      setNoteDraft("");
    }
    setIsCreatingNote(true);
  };

  const closeNoteEditor = () => {
    setIsCreatingNote(false);
    setEditingNoteId(null);
    setNoteDraft("");
  };

  const saveNote = async () => {
    const text = noteDraft.trim();
    if (!text) return;
    setIsSavingNote(true);
    try {
      if (editingNoteId) {
        const response = await fetch(
          `/api/chapters/${chapter.id}/notes/${editingNoteId}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text }),
          }
        );
        const data = await response.json();
        if (response.ok && data.note) {
          setNotes((prev) =>
            prev.map((n) => (n.id === data.note.id ? data.note : n))
          );
        }
      } else {
        const response = await fetch(`/api/chapters/${chapter.id}/notes`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        const data = await response.json();
        if (response.ok && data.note) {
          setNotes((prev) => [data.note, ...prev]);
        }
      }
      closeNoteEditor();
    } catch (err) {
      console.error("Failed to save note", err);
    } finally {
      setIsSavingNote(false);
    }
  };

  const deleteNote = async (noteId: number) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId));
    if (editingNoteId === noteId) closeNoteEditor();
    try {
      await fetch(`/api/chapters/${chapter.id}/notes/${noteId}`, {
        method: "DELETE",
      });
    } catch (err) {
      console.error("Failed to delete note", err);
    }
  };

  const originalThemeRef = useRef<{ mode: string; scheme: string } | null>(
    null
  );

  useEffect(() => {
    if (originalThemeRef.current === null) {
      originalThemeRef.current = {
        mode: document.documentElement.dataset.themeMode || "dark",
        scheme: document.documentElement.dataset.colorScheme || "sakura",
      };
    }
    return () => {
      if (originalThemeRef.current) {
        clearReaderThemeOverride(
          originalThemeRef.current.mode,
          originalThemeRef.current.scheme
        );
      }
    };
  }, []);

  useEffect(() => {
    const theme = getReaderThemeById(readerSettings.themeId);
    applyReaderThemeOverride(theme.vars, theme.mode);
  }, [readerSettings.themeId]);

  useEffect(() => {
    fetch("/api/bookmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        novelId: novel.id,
        status: "reading",
        lastReadChapter: chapter.chapterNumber,
      }),
    }).catch((err) => console.error("Auto bookmark failed", err));
  }, [novel.id, chapter.chapterNumber]);

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight =
        document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const currentProgress = (window.scrollY / totalHeight) * 100;
        setScrollProgress(Math.min(100, Math.max(0, currentProgress)));
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const autoscrollTimerRef = useRef<number | null>(null);
  const [isAutoscrolling, setIsAutoscrolling] = useState(false);

  const stopAutoscroll = useCallback(() => {
    if (autoscrollTimerRef.current) {
      window.clearInterval(autoscrollTimerRef.current);
      autoscrollTimerRef.current = null;
    }
    setIsAutoscrolling(false);
  }, []);

  const startAutoscroll = useCallback(() => {
    if (autoscrollTimerRef.current) return;
    setIsAutoscrolling(true);
    autoscrollTimerRef.current = window.setInterval(() => {
      const pxPerTick = Math.max(1, readerSettingsRef.current.autoscrollSpeed);
      window.scrollBy({ top: pxPerTick, behavior: "auto" });
      const atBottom =
        window.innerHeight + window.scrollY >=
        document.documentElement.scrollHeight - 4;
      if (atBottom) stopAutoscroll();
    }, 40);
  }, [stopAutoscroll]);

  const toggleAutoscroll = useCallback(() => {
    if (isAutoscrolling) stopAutoscroll();
    else startAutoscroll();
  }, [isAutoscrolling, startAutoscroll, stopAutoscroll]);

  useEffect(() => stopAutoscroll, [stopAutoscroll]);

  useEffect(() => {
    setComments(initialComments);
    setPurchasedIds(new Set(purchasedChapterIds));
    setBalance(initialBalance);
    setRevealedSpoilers(new Set());
    setActivePanel(null);
  }, [chapter.id, initialComments, purchasedChapterIds, initialBalance]);

  const isChapterUnlocked = useCallback(
    (target: Chapter) => target.isFree || purchasedIds.has(target.id),
    [purchasedIds]
  );

  const currentIndex = allChapters.findIndex((c) => c.id === chapter.id);
  const prevChapter = currentIndex > 0 ? allChapters[currentIndex - 1] : null;

  const chaptersToRender = useMemo(() => {
    if (readerSettings.readingMode !== "scroll") return [chapter];
    const list: Chapter[] = [];
    for (
      let i = currentIndex;
      i < allChapters.length && list.length < 5;
      i++
    ) {
      const item = allChapters[i];
      list.push(item);
      if (!isChapterUnlocked(item)) break;
    }
    return list;
  }, [
    readerSettings.readingMode,
    currentIndex,
    allChapters,
    chapter,
    isChapterUnlocked,
  ]);

  const lastRenderedChapter = chaptersToRender[chaptersToRender.length - 1];
  const lastRenderedIndex = allChapters.findIndex(
    (c) => c.id === lastRenderedChapter.id
  );
  const nextChapter =
    lastRenderedIndex >= 0 && lastRenderedIndex < allChapters.length - 1
      ? allChapters[lastRenderedIndex + 1]
      : null;

  const handlePurchase = async (target: PurchaseTarget) => {
    setIsPurchasing(true);
    setPurchaseError("");
    try {
      const response = await fetch(
        `/api/chapters/${target.chapter.id}/purchase`,
        { method: "POST" }
      );
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Не удалось купить главу");
      }
      setPurchasedIds((prev) => new Set(prev).add(target.chapter.id));
      if (typeof data.balance === "number") {
        setBalance(data.balance);
        window.dispatchEvent(
          new CustomEvent(BALANCE_EVENT, { detail: { balance: data.balance } })
        );
      }
      setPurchaseTarget(null);
      if (target.navigateAfter) {
        router.push(
          `/novel/${novel.slug}/chapter/${target.chapter.chapterNumber}`
        );
      }
    } catch (err) {
      setPurchaseError((err as Error).message);
    } finally {
      setIsPurchasing(false);
    }
  };

  const handleChapterRowClick = (target: Chapter) => {
    if (isChapterUnlocked(target)) {
      setActivePanel(null);
      router.push(`/novel/${novel.slug}/chapter/${target.chapterNumber}`);
    } else {
      setPurchaseError("");
      setPurchaseTarget({ chapter: target, navigateAfter: true });
    }
  };

  // Downloading now navigates to a real server endpoint
  // (/api/chapters/[id]/download) that responds with
  // `Content-Disposition: attachment`, instead of synthesizing a `blob:`
  // URL and clicking it via JS. The blob approach is silently blocked by
  // several browsers and, critically, by sandboxed preview iframes that
  // don't grant `allow-downloads` — which is exactly the environment this
  // app is often previewed in, and the likely reason downloads previously
  // appeared to do nothing. A genuine <a href> navigation is the most
  // broadly reliable way to trigger a file download.
  const handleDownloadClick = (target: Chapter, event: React.MouseEvent) => {
    // Always stop the click from bubbling to the parent chapter row (which
    // navigates to the chapter instead of downloading it).
    event.stopPropagation();
    if (!isChapterUnlocked(target)) {
      event.preventDefault();
      setPurchaseError("");
      setPurchaseTarget({ chapter: target, navigateAfter: false });
    }
    // If unlocked, let the browser follow the link's href normally.
  };

  const submitComment = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!commentText.trim()) return;
    setIsSubmittingComment(true);
    try {
      const response = await fetch(`/api/chapters/${chapter.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: commentText,
          isSpoiler: commentSpoiler,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось отправить");
      setComments((prev) => [data.comment, ...prev]);
      setCommentText("");
      setCommentSpoiler(false);
    } catch (err) {
      console.error("Comment submit failed", err);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const toggleSpoilerReveal = (id: number) => {
    setRevealedSpoilers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const togglePanel = (panel: Exclude<ReaderPanel, null>) => {
    setActivePanel((current) => (current === panel ? null : panel));
    setIsFontMenuOpen(false);
    if (panel === "notes" && !notesLoaded) {
      void loadNotes();
    }
  };

  const closePanel = () => {
    setActivePanel(null);
    setIsFontMenuOpen(false);
  };

  const selectedFont = FONT_OPTIONS.find((f) => f.id === readerSettings.fontId) ?? FONT_OPTIONS[0];

  const articleStyle: React.CSSProperties = {
    fontFamily: getFontFamily(readerSettings.fontId),
    fontSize: `${(BASE_FONT_PX * readerSettings.fontSizePercent) / 100}px`,
    lineHeight: 1.85,
    textAlign: readerSettings.textAlign,
  };

  const contentWidthStyle: React.CSSProperties = {
    maxWidth: `${(BASE_WIDTH_REM * readerSettings.widthPercent) / 100}rem`,
  };

  const isAnyPanelOpen = activePanel !== null;

  const panelBaseClass =
    "surface-card border-theme fixed right-0 top-0 z-50 h-full w-full max-w-sm overflow-y-auto border-l shadow-2xl transition-transform duration-300 ease-out";

  return (
    <div className="text-body-theme min-h-screen bg-[var(--background)] transition-colors duration-150">
      {/* Top Reading Progress Bar (contained strictly within the viewport
          width via left/right anchoring, never overflowing the edges) */}
      {readerSettings.progressBarEnabled && (
        <div className="fixed inset-x-0 top-0 z-50 h-1 overflow-hidden bg-black/20">
          <div
            className="h-full transition-all duration-150"
            style={{ width: `${scrollProgress}%`, background: "var(--primary)" }}
          />
        </div>
      )}

      {/* Reader Top Bar */}
      <header className="border-theme surface-card sticky top-0 z-40 border-b backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4">
          <Link
            href={`/novel/${novel.slug}`}
            className="text-body-theme flex min-w-0 items-center gap-2 text-xs font-semibold transition-colors hover:opacity-80 sm:text-sm"
          >
            <ArrowLeft className="h-4 w-4 shrink-0" />
            <span className="hidden truncate sm:inline sm:max-w-[240px]">
              {novel.title}
            </span>
            <span className="sm:hidden">Назад</span>
          </Link>

          <div className="flex min-w-0 flex-1 items-center justify-center gap-2 px-1">
            {prevChapter && (
              <Link
                href={`/novel/${novel.slug}/chapter/${prevChapter.chapterNumber}`}
                className="text-muted-theme shrink-0 rounded-lg p-1 hover:bg-[var(--surface-hover)]"
                title="Предыдущая глава"
              >
                <ChevronLeft className="h-4 w-4" />
              </Link>
            )}
            <span className="text-body-theme truncate text-xs font-bold sm:text-sm">
              {chapter.title}
            </span>
            {nextChapter && (
              <Link
                href={`/novel/${novel.slug}/chapter/${nextChapter.chapterNumber}`}
                className="text-muted-theme shrink-0 rounded-lg p-1 hover:bg-[var(--surface-hover)]"
                title="Следующая глава"
              >
                <ChevronRight className="h-4 w-4" />
              </Link>
            )}
          </div>

          <div className="w-16 shrink-0 sm:w-[240px]" />
        </div>
      </header>

      {/* Click-anywhere-to-close overlay for the side panels */}
      {isAnyPanelOpen && (
        <button
          type="button"
          aria-label="Закрыть панель"
          onClick={closePanel}
          className="fixed inset-0 z-40 cursor-default bg-black/20 backdrop-blur-[1px] transition-opacity"
        />
      )}

      {/* Floating side action buttons (4 buttons, matches the reference reader) */}
      <div className="fixed right-3 top-1/2 z-50 flex -translate-y-1/2 flex-col gap-2 sm:right-5">
        <button
          type="button"
          onClick={() => togglePanel("comments")}
          title="Комментарии"
          className={`surface-card flex h-11 w-11 items-center justify-center rounded-2xl border shadow-lg transition-all hover:scale-105 ${
            activePanel === "comments" ? "accent-bg border-transparent" : "text-body-theme hover:bg-[var(--surface-hover)]"
          }`}
        >
          <MessageSquare className="h-4.5 w-4.5" />
        </button>
        <button
          type="button"
          onClick={() => togglePanel("toc")}
          title="Оглавление"
          className={`surface-card flex h-11 w-11 items-center justify-center rounded-2xl border shadow-lg transition-all hover:scale-105 ${
            activePanel === "toc" ? "accent-bg border-transparent" : "text-body-theme hover:bg-[var(--surface-hover)]"
          }`}
        >
          <ListIcon className="h-4.5 w-4.5" />
        </button>
        <button
          type="button"
          onClick={() => togglePanel("settings")}
          title="Настройки"
          className={`surface-card flex h-11 w-11 items-center justify-center rounded-2xl border shadow-lg transition-all hover:scale-105 ${
            activePanel === "settings" ? "accent-bg border-transparent" : "text-body-theme hover:bg-[var(--surface-hover)]"
          }`}
        >
          <SettingsIcon className="h-4.5 w-4.5" />
        </button>
        <button
          type="button"
          onClick={() => togglePanel("notes")}
          title="Заметки"
          className={`surface-card relative flex h-11 w-11 items-center justify-center rounded-2xl border shadow-lg transition-all hover:scale-105 ${
            activePanel === "notes" ? "accent-bg border-transparent" : "text-body-theme hover:bg-[var(--surface-hover)]"
          }`}
        >
          <Pencil className="h-4.5 w-4.5" />
          {notesLoaded && notes.length > 0 && (
            <span className="accent-bg absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[9px] font-bold leading-none text-white">
              {notes.length}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={toggleAutoscroll}
          title={isAutoscrolling ? "Остановить автоскролл" : "Автоскролл"}
          className={`surface-card flex h-11 w-11 items-center justify-center rounded-2xl border shadow-lg transition-all hover:scale-105 ${
            isAutoscrolling ? "accent-bg border-transparent" : "text-body-theme hover:bg-[var(--surface-hover)]"
          }`}
        >
          {isAutoscrolling ? (
            <Pause className="h-4.5 w-4.5" />
          ) : (
            <Play className="h-4.5 w-4.5" />
          )}
        </button>
      </div>

      {/* Comments Panel */}
      <aside
        className={`${panelBaseClass} ${
          activePanel === "comments" ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <PanelHeader
          icon={<MessageSquare className="h-4 w-4" />}
          title={`Комментарии (${comments.length})`}
          onClose={closePanel}
        />

        <form onSubmit={submitComment} className="border-theme space-y-2.5 border-b p-4">
          <textarea
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            placeholder="Оставьте комментарий к главе..."
            rows={3}
            maxLength={1000}
            className="border-theme text-body-theme w-full resize-none rounded-xl border bg-[var(--surface-hover)] p-3 text-xs outline-none transition-colors placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
          />
          <div className="flex items-center justify-between">
            <label className="text-muted-theme flex items-center gap-1.5 text-[11px] font-medium">
              <input
                type="checkbox"
                checked={commentSpoiler}
                onChange={(e) => setCommentSpoiler(e.target.checked)}
                className="accent-[var(--primary)]"
              />
              Спойлер
            </label>
            <button
              type="submit"
              disabled={isSubmittingComment || !commentText.trim()}
              className="accent-bg flex items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-[11px] font-extrabold shadow-md transition-opacity disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" />
              Отправить
            </button>
          </div>
        </form>

        <div className="space-y-3 p-4">
          {comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <MessageSquare className="text-muted-theme mb-2 h-8 w-8 opacity-40" />
              <p className="text-muted-theme text-xs">
                Пока нет комментариев. Будьте первым!
              </p>
            </div>
          ) : (
            comments.map((comment) => {
              const revealed = revealedSpoilers.has(comment.id);
              return (
                <div
                  key={comment.id}
                  className="border-theme rounded-xl border bg-[var(--surface-hover)] p-3"
                >
                  <div className="mb-1.5 flex items-center gap-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={comment.userAvatar}
                      alt={comment.userName}
                      className="h-6 w-6 rounded-full bg-[var(--surface-active)]"
                    />
                    <span className="text-body-theme text-xs font-bold">
                      {comment.userName}
                    </span>
                    {comment.isSpoiler && (
                      <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[9px] font-bold text-amber-400">
                        Спойлер
                      </span>
                    )}
                  </div>
                  {comment.isSpoiler && !revealed ? (
                    <button
                      type="button"
                      onClick={() => toggleSpoilerReveal(comment.id)}
                      className="text-muted-theme w-full rounded-lg border border-dashed border-[var(--border)] py-2 text-[11px] font-semibold hover:bg-[var(--surface-active)]"
                    >
                      Показать спойлер
                    </button>
                  ) : (
                    <p className="text-body-theme text-xs leading-relaxed">
                      {comment.text}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>
      </aside>

      {/* Table of Contents Panel */}
      <aside
        className={`${panelBaseClass} ${
          activePanel === "toc" ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <PanelHeader
          icon={<ListIcon className="h-4 w-4" />}
          title={`Оглавление (${allChapters.length})`}
          onClose={closePanel}
        />

        <div className="space-y-1 p-3">
          {[...allChapters].reverse().map((item) => {
            const unlocked = isChapterUnlocked(item);
            const isHere = item.id === chapter.id;
            return (
              <div
                key={item.id}
                role="button"
                tabIndex={0}
                onClick={() => handleChapterRowClick(item)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    handleChapterRowClick(item);
                  }
                }}
                className={`flex w-full cursor-pointer items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left text-xs transition-colors ${
                  isHere
                    ? "accent-soft border font-bold"
                    : "text-body-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                <span className="flex min-w-0 items-center gap-1.5">
                  {!unlocked && (
                    <Lock className="h-3 w-3 shrink-0 text-amber-400" />
                  )}
                  <span className="truncate">
                    Том {item.volumeNumber} Глава {item.chapterNumber} —{" "}
                    {item.title}
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-2">
                  {isHere && (
                    <span className="accent-bg rounded px-1.5 py-0.5 text-[9px] font-bold">
                      Вы здесь
                    </span>
                  )}
                  <a
                    href={`/api/chapters/${item.id}/download`}
                    download
                    onClick={(event) => handleDownloadClick(item, event)}
                    title={unlocked ? "Скачать главу" : "Купить и скачать"}
                    className="text-muted-theme rounded-lg p-1.5 transition-colors hover:bg-[var(--surface-active)] hover:text-body-theme"
                  >
                    <Download className="h-3.5 w-3.5" />
                  </a>
                </span>
              </div>
            );
          })}
        </div>
      </aside>

      {/* Settings Panel */}
      <aside
        className={`${panelBaseClass} ${
          activePanel === "settings" ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <PanelHeader
          icon={<SettingsIcon className="h-4 w-4" />}
          title="Настройки"
          onClose={closePanel}
          extra={
            <button
              onClick={resetSettings}
              title="Сбросить настройки"
              className="text-muted-theme flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold hover:bg-[var(--surface-hover)]"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Сбросить
            </button>
          }
        />

        <div className="space-y-7 p-4">
          {/* Reading mode */}
          <div>
            <label className="text-muted-theme mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
              <BookOpenText className="h-3.5 w-3.5" />
              Режим чтения
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => updateSetting("readingMode", "paged")}
                className={`rounded-xl border px-3 py-2.5 text-xs font-bold transition-colors ${
                  readerSettings.readingMode === "paged"
                    ? "accent-soft"
                    : "text-body-theme border-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                По главам
              </button>
              <button
                onClick={() => updateSetting("readingMode", "scroll")}
                className={`rounded-xl border px-3 py-2.5 text-xs font-bold transition-colors ${
                  readerSettings.readingMode === "scroll"
                    ? "accent-soft"
                    : "text-body-theme border-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                Лента
              </button>
            </div>
          </div>

          <div className="border-theme space-y-5 rounded-2xl border p-3.5">
            {/* Progress bar toggle */}
            <div className="flex items-center justify-between gap-3">
              <span className="text-body-theme text-xs font-bold">
                Прогресс-бар чтения
              </span>
              <ToggleSwitch
                checked={readerSettings.progressBarEnabled}
                onChange={(value) => updateSetting("progressBarEnabled", value)}
                label="Прогресс-бар чтения"
              />
            </div>

            {/* Bionic reading toggle */}
            <div className="flex items-center justify-between gap-3 border-t border-[var(--border-light)] pt-4">
              <div className="min-w-0 pr-3">
                <span className="text-body-theme flex items-center gap-1.5 text-xs font-bold">
                  <Zap className="h-3.5 w-3.5 text-amber-400" />
                  Бионическое чтение
                </span>
                <p className="text-muted-theme mt-0.5 text-[10px] leading-snug">
                  Первые буквы слов — жирным, чтобы читать быстрее
                </p>
              </div>
              <ToggleSwitch
                checked={readerSettings.bionicReading}
                onChange={(value) => updateSetting("bionicReading", value)}
                label="Бионическое чтение"
              />
            </div>

            {/* Autoscroll */}
            <div className="border-t border-[var(--border-light)] pt-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-body-theme flex items-center gap-1.5 text-xs font-bold">
                  <Gauge className="h-3.5 w-3.5" />
                  Автоскролл
                </span>
                <span className="text-muted-theme text-[11px]">
                  Скорость: {readerSettings.autoscrollSpeed}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <ReaderRange
                  value={readerSettings.autoscrollSpeed}
                  min={1}
                  max={10}
                  onChange={(value) => updateSetting("autoscrollSpeed", value)}
                />
                <button
                  type="button"
                  onClick={toggleAutoscroll}
                  className="accent-bg flex h-8 w-8 shrink-0 items-center justify-center rounded-full shadow-md"
                >
                  {isAutoscrolling ? (
                    <Pause className="h-3.5 w-3.5" />
                  ) : (
                    <Play className="h-3.5 w-3.5" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Reader theme swatches */}
          <div>
            <label className="text-muted-theme mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
              <Palette className="h-3.5 w-3.5" />
              Тема читалки
            </label>
            <p className="text-muted-theme mb-1.5 text-[10px] font-semibold">
              Тёмные
            </p>
            <div className="mb-3 flex flex-wrap gap-2">
              {darkReaderThemes.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  title={preset.label}
                  onClick={() => updateSetting("themeId", preset.id)}
                  className="relative flex h-9 w-9 items-center justify-center rounded-full border-2 text-xs font-black transition-transform hover:scale-110"
                  style={{
                    backgroundColor: preset.vars.background,
                    color: preset.vars.textPrimary,
                    borderColor:
                      readerSettings.themeId === preset.id
                        ? preset.vars.primary
                        : "transparent",
                  }}
                >
                  A
                  {readerSettings.themeId === preset.id && (
                    <span
                      className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full text-white"
                      style={{ backgroundColor: preset.vars.primary }}
                    >
                      <Check className="h-2.5 w-2.5" />
                    </span>
                  )}
                </button>
              ))}
            </div>
            <p className="text-muted-theme mb-1.5 text-[10px] font-semibold">
              Светлые
            </p>
            <div className="flex flex-wrap gap-2">
              {lightReaderThemes.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  title={preset.label}
                  onClick={() => updateSetting("themeId", preset.id)}
                  className="relative flex h-9 w-9 items-center justify-center rounded-full border-2 text-xs font-black transition-transform hover:scale-110"
                  style={{
                    backgroundColor: preset.vars.background,
                    color: preset.vars.textPrimary,
                    borderColor:
                      readerSettings.themeId === preset.id
                        ? preset.vars.primary
                        : "rgba(0,0,0,0.15)",
                  }}
                >
                  A
                  {readerSettings.themeId === preset.id && (
                    <span
                      className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full text-white"
                      style={{ backgroundColor: preset.vars.primary }}
                    >
                      <Check className="h-2.5 w-2.5" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Font family — custom dropdown with a checkmark on the active
              item (matches the reference reader's dropdown design). */}
          <div ref={fontMenuRef} className="relative">
            <label className="text-muted-theme mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider">
              <Type className="h-3.5 w-3.5" />
              Шрифт текста главы
            </label>
            <button
              type="button"
              onClick={() => setIsFontMenuOpen((v) => !v)}
              className="border-theme text-body-theme flex h-11 w-full items-center justify-between rounded-xl border bg-[var(--surface-hover)] px-3.5 text-xs font-semibold outline-none transition-colors hover:bg-[var(--surface-active)]"
              style={{ fontFamily: selectedFont.family }}
            >
              <span className="truncate">{selectedFont.label}</span>
              <ChevronDown
                className={`h-4 w-4 shrink-0 transition-transform ${
                  isFontMenuOpen ? "rotate-180" : ""
                }`}
              />
            </button>

            {isFontMenuOpen && (
              <div className="surface-card border-theme absolute left-0 right-0 top-full z-20 mt-1.5 max-h-64 overflow-y-auto rounded-xl border p-1.5 shadow-2xl">
                {FONT_OPTIONS.map((font) => (
                  <button
                    key={font.id}
                    type="button"
                    onClick={() => {
                      updateSetting("fontId", font.id);
                      setIsFontMenuOpen(false);
                    }}
                    style={{ fontFamily: font.family }}
                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                      readerSettings.fontId === font.id
                        ? "accent-soft font-bold"
                        : "text-body-theme hover:bg-[var(--surface-hover)]"
                    }`}
                  >
                    <span className="truncate">{font.label}</span>
                    {readerSettings.fontId === font.id && (
                      <Check className="h-3.5 w-3.5 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Font size */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-body-theme text-xs font-bold">
                Размер шрифта
              </span>
              <span className="text-muted-theme text-[11px] font-bold">
                {readerSettings.fontSizePercent}%
              </span>
            </div>
            <ReaderRange
              value={readerSettings.fontSizePercent}
              min={70}
              max={160}
              step={5}
              onChange={(value) => updateSetting("fontSizePercent", value)}
            />
          </div>

          {/* Text width */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-body-theme text-xs font-bold">
                Ширина текста
              </span>
              <span className="text-muted-theme text-[11px] font-bold">
                {readerSettings.widthPercent}%
              </span>
            </div>
            <ReaderRange
              value={readerSettings.widthPercent}
              min={70}
              max={140}
              step={5}
              onChange={(value) => updateSetting("widthPercent", value)}
            />
          </div>

          {/* Text alignment */}
          <div>
            <label className="text-muted-theme mb-2 block text-[11px] font-bold uppercase tracking-wider">
              Распределение слов в строке
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => updateSetting("textAlign", "left")}
                className={`flex items-center justify-center rounded-xl border py-2.5 transition-colors ${
                  readerSettings.textAlign === "left"
                    ? "accent-soft"
                    : "border-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                <AlignLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() => updateSetting("textAlign", "center")}
                className={`flex items-center justify-center rounded-xl border py-2.5 transition-colors ${
                  readerSettings.textAlign === "center"
                    ? "accent-soft"
                    : "border-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                <AlignCenter className="h-4 w-4" />
              </button>
              <button
                onClick={() => updateSetting("textAlign", "right")}
                className={`flex items-center justify-center rounded-xl border py-2.5 transition-colors ${
                  readerSettings.textAlign === "right"
                    ? "accent-soft"
                    : "border-theme hover:bg-[var(--surface-hover)]"
                }`}
              >
                <AlignRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <button
            onClick={closePanel}
            className="accent-bg w-full rounded-xl py-3 text-xs font-extrabold shadow-lg"
          >
            Готово
          </button>
        </div>
      </aside>

      {/* Notes Panel */}
      <aside
        className={`${panelBaseClass} ${
          activePanel === "notes" ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <PanelHeader
          icon={<Pencil className="h-4 w-4" />}
          title="Заметки"
          onClose={closePanel}
          extra={
            notesLoaded && notes.length > 0 && !isCreatingNote ? (
              <button
                type="button"
                onClick={() => openNoteEditor()}
                className="accent-soft flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-semibold"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                Создать заметку
              </button>
            ) : null
          }
        />

        <div className="p-4">
          {isNotesLoading && !notesLoaded ? (
            <p className="text-muted-theme py-10 text-center text-xs">
              Загрузка заметок...
            </p>
          ) : isCreatingNote || (notesLoaded && notes.length === 0) ? (
            <div className="border-theme surface-card rounded-2xl border p-4">
              <div className="mb-2.5 flex items-center justify-between">
                <h3 className="text-body-theme text-sm font-extrabold">
                  {editingNoteId ? "Изменить заметку" : "Создать заметку"}
                </h3>
                {notes.length > 0 && (
                  <button
                    type="button"
                    onClick={closeNoteEditor}
                    className="text-muted-theme rounded-lg p-1 hover:bg-[var(--surface-hover)]"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <textarea
                value={noteDraft}
                onChange={(e) => setNoteDraft(e.target.value)}
                placeholder="Ваша заметка к этой главе..."
                rows={5}
                maxLength={2000}
                className="border-theme text-body-theme w-full resize-none rounded-xl border bg-[var(--surface-hover)] p-3 text-xs outline-none transition-colors placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]"
              />
              <div className="mt-3 flex items-center gap-2">
                <button
                  type="button"
                  onClick={saveNote}
                  disabled={isSavingNote || !noteDraft.trim()}
                  className="accent-bg flex-1 rounded-xl py-2.5 text-xs font-extrabold shadow-md disabled:opacity-50"
                >
                  {isSavingNote ? "Сохранение..." : "Сохранить"}
                </button>
                {editingNoteId && (
                  <button
                    type="button"
                    onClick={() => deleteNote(editingNoteId)}
                    title="Удалить заметку"
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-500/15 text-red-400 hover:bg-red-500/25"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-2.5">
              {notes.map((note) => (
                <div
                  key={note.id}
                  className="border-theme surface-card group rounded-2xl border p-3.5"
                >
                  <p className="text-body-theme whitespace-pre-wrap text-xs leading-relaxed">
                    {note.text}
                  </p>
                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="text-muted-theme text-[10px]">
                      {new Date(note.updatedAt).toLocaleString("ru-RU", {
                        day: "2-digit",
                        month: "2-digit",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openNoteEditor(note)}
                        title="Редактировать"
                        className="text-muted-theme rounded-lg p-1.5 hover:bg-[var(--surface-hover)] hover:text-body-theme"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteNote(note.id)}
                        title="Удалить"
                        className="rounded-lg p-1.5 text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* Reader Chapter Body */}
      <main
        className="mx-auto px-5 py-10 sm:px-8 sm:py-16"
        style={contentWidthStyle}
      >
        {chaptersToRender.map((item, index) => {
          const unlocked = isChapterUnlocked(item);
          const paragraphs = item.content.split("\n\n");

          return (
            <div key={item.id} className={index > 0 ? "mt-16" : ""}>
              <div className="border-theme mb-10 border-b pb-6 text-center">
                {index === 0 && (
                  <Link
                    href={`/novel/${novel.slug}`}
                    className="accent-text mb-2 inline-block text-xs font-bold uppercase tracking-wider hover:underline"
                  >
                    {novel.title}
                  </Link>
                )}
                <h1 className="text-body-theme text-xl font-extrabold tracking-tight sm:text-2xl md:text-3xl">
                  {item.title}
                </h1>
                <div className="text-muted-theme mt-3 flex items-center justify-center gap-4 text-xs">
                  <span>{item.wordsCount} слов</span>
                  <span>•</span>
                  <span>Перевод: {novel.translator}</span>
                </div>
              </div>

              {unlocked ? (
                <article
                  className="text-body-theme select-text space-y-6 transition-all duration-150"
                  style={articleStyle}
                >
                  {paragraphs.map((para, i) => (
                    <p key={i} className="whitespace-pre-wrap">
                      {renderParagraphText(para, readerSettings.bionicReading)}
                    </p>
                  ))}
                </article>
              ) : (
                <div className="relative max-h-[420px] overflow-hidden rounded-2xl">
                  <article
                    className="text-body-theme select-none space-y-6 opacity-60 transition-all duration-150"
                    style={articleStyle}
                  >
                    {paragraphs.slice(0, 4).map((para, i) => (
                      <p key={i} className="whitespace-pre-wrap">
                        {para}
                      </p>
                    ))}
                  </article>
                  <div className="reader-paywall-fade absolute inset-0" />
                  <div className="absolute inset-0 flex items-center justify-center p-4">
                    <div className="surface-card border-theme w-full max-w-xs rounded-2xl border p-6 text-center shadow-2xl">
                      <div className="accent-soft mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-full border">
                        <Lock className="h-5 w-5" />
                      </div>
                      <h3 className="text-body-theme mb-3 text-sm font-extrabold">
                        Платная глава
                      </h3>
                      <button
                        type="button"
                        onClick={() =>
                          handlePurchase({
                            chapter: item,
                            navigateAfter: false,
                          })
                        }
                        disabled={isPurchasing}
                        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-2.5 text-xs font-extrabold text-white shadow-lg disabled:opacity-60"
                      >
                        <Coins className="h-4 w-4" />
                        {isPurchasing
                          ? "Покупка..."
                          : `Купить за ${item.price} монет`}
                      </button>
                      {purchaseError && (
                        <p className="mt-2 text-[11px] font-semibold text-red-400">
                          {purchaseError}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Bottom Navigation Buttons */}
        <div className="border-theme mt-16 flex items-center justify-between gap-3 border-t pt-8">
          {prevChapter ? (
            <Link
              href={`/novel/${novel.slug}/chapter/${prevChapter.chapterNumber}`}
              className="text-body-theme flex items-center gap-1.5 rounded-xl bg-[var(--surface-hover)] px-4 py-2.5 text-xs font-semibold transition-colors hover:bg-[var(--surface-active)] sm:text-sm"
            >
              <ChevronLeft className="h-4 w-4" />
              <span>Предыдущая</span>
            </Link>
          ) : (
            <span />
          )}

          <Link
            href={`/novel/${novel.slug}`}
            className="accent-soft rounded-xl px-4 py-2.5 text-xs font-semibold transition-colors sm:text-sm"
          >
            К оглавлению
          </Link>

          {nextChapter ? (
            <Link
              href={`/novel/${novel.slug}/chapter/${nextChapter.chapterNumber}`}
              className="accent-bg flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-extrabold shadow-lg transition-colors sm:text-sm"
            >
              <span>Следующая</span>
              <ChevronRight className="h-4 w-4" />
            </Link>
          ) : (
            <span className="text-muted-theme text-xs">
              Это последняя глава
            </span>
          )}
        </div>
      </main>

      {/* Purchase confirmation modal (used from the TOC / paywall preview) */}
      {purchaseTarget && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setPurchaseTarget(null);
              setPurchaseError("");
            }
          }}
        >
          <div className="surface-card border-theme w-full max-w-xs rounded-2xl border p-6 text-center shadow-2xl">
            <div className="accent-soft mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-full border">
              <Lock className="h-5 w-5" />
            </div>
            <h3 className="text-body-theme mb-1 text-sm font-extrabold">
              Платная глава
            </h3>
            <p className="text-muted-theme mb-4 text-xs leading-relaxed">
              {purchaseTarget.chapter.title}
            </p>
            <button
              type="button"
              onClick={() => handlePurchase(purchaseTarget)}
              disabled={isPurchasing}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 py-2.5 text-xs font-extrabold text-white shadow-lg disabled:opacity-60"
            >
              <Coins className="h-4 w-4" />
              {isPurchasing
                ? "Покупка..."
                : `Купить за ${purchaseTarget.chapter.price} монет`}
            </button>
            {purchaseError && (
              <p className="mt-2 text-[11px] font-semibold text-red-400">
                {purchaseError}
              </p>
            )}
            <button
              type="button"
              onClick={() => {
                setPurchaseTarget(null);
                setPurchaseError("");
              }}
              className="text-muted-theme mt-3 text-[11px] font-semibold hover:underline"
            >
              Отмена
            </button>
          </div>
        </div>
      )}

      {/* Floating balance indicator while reading */}
      <div className="accent-soft fixed left-3 top-[68px] z-30 flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold shadow-lg sm:left-5">
        <Coins className="h-3.5 w-3.5 text-amber-400" />
        {balance.toLocaleString("ru-RU")}
      </div>
    </div>
  );
}
