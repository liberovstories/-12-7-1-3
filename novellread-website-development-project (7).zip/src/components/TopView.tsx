"use client";

import Link from "next/link";
import { Star, Trophy } from "lucide-react";
import type { Novel } from "@/types";

interface TopViewProps {
  novels: Novel[];
}

function RankBadge({ rank }: { rank: number }) {
  const palette =
    rank === 1
      ? "bg-gradient-to-br from-amber-300 to-amber-600 text-black shadow-amber-500/30"
      : rank === 2
      ? "bg-gradient-to-br from-slate-200 to-slate-400 text-black shadow-slate-400/30"
      : rank === 3
      ? "bg-gradient-to-br from-amber-600 to-amber-800 text-white shadow-amber-700/30"
      : "surface-card text-body-theme border";

  return (
    <div
      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-sm font-black shadow-md ${palette}`}
    >
      {rank}
    </div>
  );
}

export function TopView({ novels }: TopViewProps) {
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-7 flex items-center gap-2.5">
        <div className="accent-soft flex h-9 w-9 items-center justify-center rounded-xl border">
          <Trophy className="h-4.5 w-4.5" />
        </div>
        <div>
          <h1 className="text-body-theme text-2xl font-extrabold tracking-tight">
            Топ 100
          </h1>
          <p className="text-muted-theme text-xs">
            Абсолютный рейтинг читателей NovellRead по всем новеллам и фанфикам
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        {novels.map((novel, index) => (
          <Link
            key={novel.id}
            href={`/novel/${novel.slug}`}
            className="surface-card surface-card-hover group flex gap-3 rounded-2xl border p-3 transition-colors hover:border-[var(--primary)]/40"
          >
            <RankBadge rank={index + 1} />

            <div className="h-[124px] w-[84px] shrink-0 overflow-hidden rounded-xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={novel.coverUrl}
                alt={novel.title}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <span className="text-muted-theme text-[11px] font-semibold">
                    {novel.type} • {novel.country}
                  </span>
                  <h3 className="text-body-theme truncate text-[15px] font-extrabold transition-colors group-hover:text-[var(--primary)]">
                    {novel.title}
                  </h3>
                </div>
                <div className="flex shrink-0 flex-col items-end">
                  <span className="flex items-center gap-1 text-sm font-extrabold text-amber-400">
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                    {novel.rating.toFixed(1)}
                  </span>
                  <span className="text-muted-theme text-[10px]">
                    {novel.ratingCount.toLocaleString("ru-RU")} оценок
                  </span>
                </div>
              </div>

              <p className="text-muted-theme mt-1.5 line-clamp-2 text-xs leading-relaxed">
                {novel.description}
              </p>

              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="accent-soft rounded px-1.5 py-0.5 text-[10px] font-bold">
                  {novel.ageRating}
                </span>
                {novel.genres.slice(0, 3).map((genre) => (
                  <span
                    key={genre}
                    className="text-muted-theme rounded bg-[var(--surface-hover)] px-1.5 py-0.5 text-[10px] font-medium"
                  >
                    {genre}
                  </span>
                ))}
                {novel.tags.slice(0, 1).map((tag) => (
                  <span
                    key={tag}
                    className="rounded bg-cyan-500/10 px-1.5 py-0.5 text-[10px] font-medium text-cyan-400"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
