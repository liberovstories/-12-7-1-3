"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  ArrowRight,
  Clock3,
  LoaderCircle,
  Search,
  Users,
  UserRound,
  X,
} from "lucide-react";
import type {
  Novel,
  SearchCategory,
  SearchDirectoryItem,
  SearchResponse,
} from "@/types";

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
}

const tabs: Array<{ id: SearchCategory; label: string }> = [
  { id: "novels", label: "Новеллы" },
  { id: "teams", label: "Команды" },
  { id: "characters", label: "Персонажи" },
  { id: "creators", label: "Создатели" },
  { id: "users", label: "Пользователи" },
];

const emptyResponse: SearchResponse = {
  query: "",
  novels: [],
  teams: [],
  characters: [],
  creators: [],
  users: [],
  popular: [],
};

function NovelSearchCard({
  novel,
  onSelect,
}: {
  novel: Novel;
  onSelect: () => void;
}) {
  return (
    <Link
      href={`/novel/${novel.slug}`}
      onClick={onSelect}
      className="surface-card group flex min-w-0 items-center gap-3 rounded-[20px] border p-2.5 transition-colors hover:border-[var(--primary)]/60 surface-card-hover"
    >
      <div className="surface-card h-[68px] w-[48px] shrink-0 overflow-hidden rounded-[12px] border-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={novel.coverUrl}
          alt={novel.title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="min-w-0 pr-1">
        <div className="text-muted-theme mb-0.5 truncate text-[11px] font-semibold">
          {novel.type}
        </div>
        <div className="text-body-theme line-clamp-2 text-[14px] font-bold leading-[18px]">
          {novel.title}
        </div>
      </div>
    </Link>
  );
}

function DirectorySearchCard({
  item,
  onSelect,
}: {
  item: SearchDirectoryItem;
  onSelect: () => void;
}) {
  const categoryLabel = {
    teams: "Команда",
    characters: "Персонаж",
    creators: "Создатель",
    users: "Пользователь",
  }[item.category];

  return (
    <Link
      href={item.href}
      onClick={onSelect}
      className="surface-card group flex min-w-0 items-center gap-3 rounded-[20px] border p-2.5 transition-colors hover:border-[var(--primary)]/60 surface-card-hover"
    >
      <div className="border-theme h-[58px] w-[58px] shrink-0 overflow-hidden rounded-[16px] border bg-[var(--surface-hover)]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.image}
          alt={item.title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="min-w-0 pr-1">
        <div className="text-muted-theme mb-0.5 truncate text-[11px] font-semibold">
          {categoryLabel}
        </div>
        <div className="text-body-theme truncate text-[14px] font-bold">
          {item.title}
        </div>
        <div className="text-muted-theme mt-0.5 truncate text-[11px]">
          {item.subtitle}
        </div>
      </div>
    </Link>
  );
}

export function SearchModal({ open, onClose }: SearchModalProps) {
  const router = useRouter();
  const pathname = usePathname();
  const inputRef = useRef<HTMLInputElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const [query, setQuery] = useState("");
  const [activeTab, setActiveTab] = useState<SearchCategory>("novels");
  const [results, setResults] = useState<SearchResponse>(emptyResponse);
  const [loading, setLoading] = useState(false);
  const [resultLimit, setResultLimit] = useState(10);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  useEffect(() => {
    if (!open) return;
    const stored = window.localStorage.getItem("novellread-recent-searches");
    if (stored) {
      try {
        setRecentSearches(JSON.parse(stored));
      } catch {
        setRecentSearches([]);
      }
    }
    const focusTimer = window.setTimeout(() => inputRef.current?.focus(), 80);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.clearTimeout(focusTimer);
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLoading(true);
      try {
        const response = await fetch(
          `/api/search?q=${encodeURIComponent(query.trim())}&limit=${resultLimit}`,
          { signal: controller.signal }
        );
        if (!response.ok) throw new Error("Search request failed");
        setResults(await response.json());
      } catch (error) {
        if ((error as Error).name !== "AbortError") {
          setResults(emptyResponse);
        }
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, query.trim() ? 220 : 0);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [open, query, resultLimit]);

  useEffect(() => {
    if (!open) return;
    setQuery("");
    setActiveTab("novels");
    setResultLimit(10);
  }, [pathname, open]);

  const saveRecentSearch = useCallback(
    (value: string) => {
      const cleanValue = value.trim();
      if (!cleanValue) return;
      const next = [
        cleanValue,
        ...recentSearches.filter(
          (item) => item.toLocaleLowerCase("ru-RU") !== cleanValue.toLocaleLowerCase("ru-RU")
        ),
      ].slice(0, 5);
      setRecentSearches(next);
      window.localStorage.setItem(
        "novellread-recent-searches",
        JSON.stringify(next)
      );
    },
    [recentSearches]
  );

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!query.trim()) return;
    saveRecentSearch(query);
  };

  const handleSelectResult = () => {
    saveRecentSearch(query);
    onClose();
  };

  const handleRecentClick = (value: string) => {
    setQuery(value);
    setActiveTab("novels");
    setResultLimit(10);
    inputRef.current?.focus();
  };

  const removeRecent = (value: string) => {
    const next = recentSearches.filter((item) => item !== value);
    setRecentSearches(next);
    window.localStorage.setItem(
      "novellread-recent-searches",
      JSON.stringify(next)
    );
  };

  const activeResults = useMemo(() => {
    if (activeTab === "novels") return results.novels;
    return results[activeTab];
  }, [activeTab, results]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[120] overflow-y-auto bg-black/70 px-3 pb-8 pt-3 backdrop-blur-[3px] sm:px-5 sm:pt-4"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="mx-auto flex w-full max-w-[666px] items-start gap-2">
        <div
          ref={dialogRef}
          role="dialog"
          aria-modal="true"
          aria-label="Поиск по NovellRead"
          className="surface-card min-w-0 flex-1 overflow-hidden rounded-[28px] border shadow-[0_24px_90px_rgba(0,0,0,0.45)]"
        >
          <div className="p-2 pb-0 sm:p-3 sm:pb-0">
            <form onSubmit={handleSubmit} className="relative">
              <Search className="text-muted-theme pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2" />
              <input
                ref={inputRef}
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setResultLimit(10);
                }}
                placeholder="Что ищем, семпай?"
                autoComplete="off"
                className="border-theme text-body-theme h-[44px] w-full rounded-[24px] border bg-[var(--surface-hover)] pl-11 pr-10 text-[14px] font-semibold caret-[var(--primary)] outline-none transition-colors placeholder:font-semibold placeholder:text-[var(--text-muted)] focus:border-[var(--primary)]/70"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery("");
                    setActiveTab("novels");
                    inputRef.current?.focus();
                  }}
                  aria-label="Очистить поиск"
                  className="text-muted-theme absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 transition-colors hover:bg-[var(--surface-active)] hover:text-body-theme"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </form>
          </div>

          {!query.trim() ? (
            <div className="px-4 pb-4 pt-4 sm:px-5 sm:pb-5">
              {recentSearches.length > 0 && (
                <div className="mb-6 space-y-1">
                  {recentSearches.map((item) => (
                    <div
                      key={item}
                      className="text-body-theme group flex h-8 items-center justify-between rounded-lg px-1.5 text-[13px] font-semibold hover:bg-[var(--surface-hover)]"
                    >
                      <button
                        type="button"
                        onClick={() => handleRecentClick(item)}
                        className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                      >
                        <Clock3 className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{item}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => removeRecent(item)}
                        aria-label={`Удалить запрос ${item}`}
                        className="text-muted-theme p-1 hover:text-body-theme"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <h2 className="text-body-theme mb-3 text-[13px] font-extrabold">
                Часто ищут
              </h2>
              {loading && results.popular.length === 0 ? (
                <div className="text-muted-theme flex h-36 items-center justify-center">
                  <LoaderCircle className="h-5 w-5 animate-spin" />
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {results.popular.map((novel) => (
                    <NovelSearchCard
                      key={novel.id}
                      novel={novel}
                      onSelect={onClose}
                    />
                  ))}
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="mx-2 mt-2 flex h-[42px] items-center gap-1 overflow-x-auto rounded-[22px] bg-[var(--surface-hover)] p-1 sm:mx-3">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`h-[34px] flex-1 whitespace-nowrap rounded-[18px] px-3 text-[12px] font-extrabold transition-colors ${
                      activeTab === tab.id
                        ? "accent-bg shadow-[0_4px_14px_rgba(var(--primary-rgb),0.28)]"
                        : "text-muted-theme hover:bg-[var(--surface-active)] hover:text-body-theme"
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="px-2 pb-2 pt-2 sm:px-3 sm:pb-3">
                {loading ? (
                  <div className="text-muted-theme flex h-[268px] flex-col items-center justify-center gap-2">
                    <LoaderCircle className="h-6 w-6 animate-spin text-[var(--primary)]" />
                    <span className="text-xs font-semibold">Ищем совпадения…</span>
                  </div>
                ) : activeResults.length > 0 ? (
                  <>
                    <div className="grid max-h-[438px] grid-cols-1 gap-2 overflow-y-auto pr-0.5 sm:grid-cols-2">
                      {activeTab === "novels"
                        ? (activeResults as Novel[]).map((novel) => (
                            <NovelSearchCard
                              key={novel.id}
                              novel={novel}
                              onSelect={handleSelectResult}
                            />
                          ))
                        : (activeResults as SearchDirectoryItem[]).map((item) => (
                            <DirectorySearchCard
                              key={item.id}
                              item={item}
                              onSelect={handleSelectResult}
                            />
                          ))}
                    </div>

                    <div className="mt-2 flex justify-end">
                      {resultLimit < 20 ? (
                        <button
                          type="button"
                          onClick={() => setResultLimit(20)}
                          className="text-body-theme flex h-9 items-center gap-1.5 rounded-[18px] bg-[var(--surface-hover)] px-4 text-[12px] font-extrabold transition-colors hover:bg-[var(--surface-active)]"
                        >
                          Больше
                          <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      ) : activeTab === "novels" ? (
                        <button
                          type="button"
                          onClick={() => {
                            saveRecentSearch(query);
                            onClose();
                            router.push(
                              `/catalog?search=${encodeURIComponent(query.trim())}`
                            );
                          }}
                          className="text-body-theme flex h-9 items-center gap-1.5 rounded-[18px] bg-[var(--surface-hover)] px-4 text-[12px] font-extrabold transition-colors hover:bg-[var(--surface-active)]"
                        >
                          Открыть в каталоге
                          <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      ) : null}
                    </div>
                  </>
                ) : (
                  <div className="flex h-[268px] flex-col items-center justify-center px-6 text-center">
                    <div className="text-muted-theme mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-[var(--surface-hover)]">
                      {activeTab === "teams" ? (
                        <Users className="h-5 w-5" />
                      ) : activeTab === "novels" ? (
                        <Search className="h-5 w-5" />
                      ) : (
                        <UserRound className="h-5 w-5" />
                      )}
                    </div>
                    <div className="text-body-theme text-[14px] font-extrabold">
                      Ничего не найдено
                    </div>
                    <div className="text-muted-theme mt-1 max-w-sm text-xs leading-5">
                      Во вкладке «{tabs.find((tab) => tab.id === activeTab)?.label}» нет совпадений по запросу «{query.trim()}»
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          aria-label="Закрыть поиск"
          className="surface-card text-body-theme flex h-12 w-12 shrink-0 items-center justify-center rounded-full border shadow-xl transition-colors hover:bg-[var(--surface-hover)] sm:h-14 sm:w-14"
        >
          <X className="h-5 w-5" strokeWidth={2.4} />
        </button>
      </div>
    </div>
  );
}
