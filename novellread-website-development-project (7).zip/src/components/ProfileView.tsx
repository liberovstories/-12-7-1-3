"use client";

import { useState } from "react";
import Link from "next/link";
import {
  User,
  Star,
  BookOpen,
  Bookmark,
  Award,
  Languages,
  Calendar,
  Layers,
  Sparkles,
  TrendingUp,
  Clock,
} from "lucide-react";
import { Bookmark as BookmarkType, Novel } from "@/types";
import { TopUpModal, BALANCE_EVENT } from "@/components/TopUpModal";
import { useEffect } from "react";
import { Coins } from "lucide-react";

interface ProfileViewProps {
  bookmarks: (BookmarkType & { novel: Novel })[];
  translatedNovels: Novel[];
  profile: {
    displayName: string;
    username: string;
    bio: string;
    avatarUrl: string;
    bannerUrl: string | null;
    privateProfile: boolean;
    balance: number;
  };
}

export function ProfileView({
  bookmarks,
  translatedNovels,
  profile,
}: ProfileViewProps) {
  const [activeTab, setActiveTab] = useState<
    "bookmarks" | "translations" | "achievements"
  >("bookmarks");
  const [balance, setBalance] = useState(profile.balance);
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);

  useEffect(() => {
    const handleBalanceChange = (event: Event) => {
      const detail = (event as CustomEvent<{ balance: number }>).detail;
      if (detail) setBalance(detail.balance);
    };
    window.addEventListener(BALANCE_EVENT, handleBalanceChange);
    return () => window.removeEventListener(BALANCE_EVENT, handleBalanceChange);
  }, []);

  const achievements = [
    {
      title: "Книжный червь",
      desc: "Прочитано более 1 000 глав восточных новелл",
      icon: BookOpen,
      color: "text-emerald-400 bg-emerald-500/20 border-emerald-500/30",
    },
    {
      title: "Знаток Сянься",
      desc: "Прочитано более 20 новелл в жанре культивации",
      icon: Sparkles,
      color: "text-cyan-400 bg-cyan-500/20 border-cyan-500/30",
    },
    {
      title: "Трудолюбивый переводчик",
      desc: "Опубликовано свыше 500 глав на NovellRead",
      icon: Languages,
      color: "text-amber-400 bg-amber-500/20 border-amber-500/30",
    },
    {
      title: "Рецензент месяца",
      desc: "Написано 10+ подробных рецензий с высокими оценками",
      icon: Award,
      color: "text-purple-400 bg-purple-500/20 border-purple-500/30",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Banner (Rulate user 575882 inspired) */}
      <div className="relative mb-8 overflow-hidden rounded-3xl border border-white/10 shadow-2xl">
        {profile.bannerUrl ? (
          <>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={profile.bannerUrl}
              alt=""
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 profile-banner-fade" />
          </>
        ) : (
          <div className="absolute inset-0 bg-[#131722]" />
        )}

        <div className="relative flex flex-col gap-6 p-6 sm:p-8 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-5 sm:gap-6">
          <div className="flex flex-col items-center gap-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={profile.avatarUrl}
              alt={profile.displayName}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-emerald-950/70 border-2 border-emerald-500/40 p-1 object-cover shadow-xl"
            />
            <div className="flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-400">
              <Coins className="h-3.5 w-3.5" />
              {balance.toLocaleString("ru-RU")}
            </div>
            <button
              type="button"
              onClick={() => setIsTopUpOpen(true)}
              className="text-[10px] font-bold text-emerald-400 hover:underline"
            >
              Пополнить баланс
            </button>
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-black text-white">
                {profile.displayName}
              </h1>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800/50 px-2.5 py-1 rounded-lg">
                @{profile.username}
              </span>
              {profile.privateProfile && (
                <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-bold text-slate-300">
                  Приватный профиль
                </span>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">
              Статус: <strong className="text-emerald-400">Мастер перевода и культивации</strong>
            </p>

            {profile.bio && (
              <p className="mt-3 max-w-xl text-xs leading-5 text-slate-300">
                {profile.bio}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-3 text-xs">
              <span className="text-emerald-400 font-bold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/30">
                Карма: +482
              </span>
              <span className="text-slate-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Регистрация: Ноябрь 2021
              </span>
              <span className="text-slate-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> 348 часов чтения
              </span>
            </div>
          </div>
        </div>

        {/* Reader Stats Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full md:w-auto">
          <button
            type="button"
            onClick={() => setIsTopUpOpen(true)}
            className="bg-[#0b0e14] border border-amber-500/30 hover:border-amber-500/60 rounded-2xl px-4 py-3 text-center transition-colors"
          >
            <span className="text-[11px] text-slate-400 block">Баланс</span>
            <strong className="text-lg font-black text-amber-400 flex items-center justify-center gap-1">
              <Coins className="h-4 w-4" />
              {balance.toLocaleString("ru-RU")}
            </strong>
          </button>
          <div className="bg-[#0b0e14] border border-white/5 rounded-2xl px-4 py-3 text-center">
            <span className="text-[11px] text-slate-400 block">Глав прочитано</span>
            <strong className="text-lg font-black text-white">1,420</strong>
          </div>
          <div className="bg-[#0b0e14] border border-white/5 rounded-2xl px-4 py-3 text-center">
            <span className="text-[11px] text-slate-400 block">В закладках</span>
            <strong className="text-lg font-black text-emerald-400">
              {bookmarks.length}
            </strong>
          </div>
          <div className="bg-[#0b0e14] border border-white/5 rounded-2xl px-4 py-3 text-center">
            <span className="text-[11px] text-slate-400 block">Репутация</span>
            <strong className="text-lg font-black text-amber-400">ТОП 5%</strong>
          </div>
        </div>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center gap-2 border-b border-white/10 mb-6">
        <button
          onClick={() => setActiveTab("bookmarks")}
          className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === "bookmarks"
              ? "border-emerald-400 text-emerald-400"
              : "border-transparent text-slate-400 hover:text-white"
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Закладки читателя ({bookmarks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("translations")}
          className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === "translations"
              ? "border-emerald-400 text-emerald-400"
              : "border-transparent text-slate-400 hover:text-white"
          }`}
        >
          <Languages className="w-4 h-4" />
          <span>Мои переводы (Rulate TL)</span>
        </button>

        <button
          onClick={() => setActiveTab("achievements")}
          className={`pb-3 px-4 text-sm font-bold transition-all border-b-2 flex items-center gap-2 ${
            activeTab === "achievements"
              ? "border-emerald-400 text-emerald-400"
              : "border-transparent text-slate-400 hover:text-white"
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Достижения ({achievements.length})</span>
        </button>
      </div>

      {/* Tab 1: Bookmarks */}
      {activeTab === "bookmarks" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {bookmarks.map((item) => (
            <div
              key={item.id}
              className="bg-[#131722] border border-white/5 rounded-2xl p-4 flex gap-4"
            >
              <Link
                href={`/novel/${item.novel.slug}`}
                className="relative w-20 aspect-[2/3] rounded-lg overflow-hidden flex-shrink-0 border border-white/10"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.novel.coverUrl}
                  alt={item.novel.title}
                  className="w-full h-full object-cover"
                />
              </Link>
              <div className="flex-1 min-w-0 flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-semibold text-emerald-400">
                    {item.novel.type} • {item.novel.country}
                  </span>
                  <Link
                    href={`/novel/${item.novel.slug}`}
                    className="text-sm font-bold text-white hover:text-emerald-400 truncate block mt-0.5"
                  >
                    {item.novel.title}
                  </Link>
                  <p className="text-xs text-slate-400 mt-1">
                    Прогресс: Глава {item.lastReadChapter || 1} из{" "}
                    {item.novel.chaptersCount}
                  </p>
                </div>
                <Link
                  href={`/novel/${item.novel.slug}/chapter/${
                    item.lastReadChapter || 1
                  }`}
                  className="py-1 px-3 bg-emerald-500 hover:bg-emerald-600 text-black text-xs font-bold rounded-lg text-center"
                >
                  Читать дальше
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Translations (Rulate functionality) */}
      {activeTab === "translations" && (
        <div className="space-y-4">
          <div className="bg-[#131722] border border-white/5 rounded-2xl p-5 mb-4">
            <h3 className="text-base font-bold text-white mb-1">
              Проекты команды перевода
            </h3>
            <p className="text-xs text-slate-400">
              Новеллы, находящиеся под кураторством и переводом команды Rulate
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {translatedNovels.map((novel) => (
              <div
                key={novel.id}
                className="bg-[#131722] border border-white/5 rounded-2xl p-4 flex gap-4"
              >
                <Link
                  href={`/novel/${novel.slug}`}
                  className="relative w-20 aspect-[2/3] rounded-lg overflow-hidden flex-shrink-0 border border-white/10"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={novel.coverUrl}
                    alt={novel.title}
                    className="w-full h-full object-cover"
                  />
                </Link>
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                      Переводчик
                    </span>
                    <Link
                      href={`/novel/${novel.slug}`}
                      className="text-sm font-bold text-white hover:text-emerald-400 truncate block mt-1"
                    >
                      {novel.title}
                    </Link>
                    <p className="text-xs text-slate-400 mt-1">
                      Переведено: {novel.chaptersCount} глав
                    </p>
                  </div>
                  <Link
                    href={`/novel/${novel.slug}`}
                    className="text-xs text-emerald-400 font-semibold hover:underline"
                  >
                    Управление проектом →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Achievements */}
      {activeTab === "achievements" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {achievements.map((ach) => {
            const Icon = ach.icon;
            return (
              <div
                key={ach.title}
                className="bg-[#131722] border border-white/5 rounded-2xl p-5 flex items-center gap-4"
              >
                <div
                  className={`w-12 h-12 rounded-2xl border flex items-center justify-center flex-shrink-0 ${ach.color}`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{ach.title}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{ach.desc}</p>
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider mt-1 inline-block">
                    Получено
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <TopUpModal
        open={isTopUpOpen}
        onClose={() => setIsTopUpOpen(false)}
        onSuccess={(newBalance) => setBalance(newBalance)}
      />
    </div>
  );
}
