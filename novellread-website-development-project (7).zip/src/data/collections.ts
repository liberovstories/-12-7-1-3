export interface CollectionItem {
  id: string;
  title: string;
  subtitle: string;
  count: number;
  covers: string[];
  filterTag: string;
}

export const collectionsData: CollectionItem[] = [
  {
    id: "cult-novels",
    title: "Культовые новеллы",
    subtitle: "Тайтлы с миллионами фанатов по всему миру!",
    count: 22,
    filterTag: "Система",
    covers: [
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "op-mc",
    title: "Непобедимый ГГ",
    subtitle: "Герои, которые сокрушают врагов одним ударом",
    count: 14,
    filterTag: "Непобедимый ГГ",
    covers: [
      "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "cultivation",
    title: "Культивация и Дао",
    subtitle: "Восхождение к бессмертию, секты и небесные кары",
    count: 19,
    filterTag: "Культивация",
    covers: [
      "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "reincarnation",
    title: "Перерождение и Регрессия",
    subtitle: "Второй шанс исправить былые ошибки с памятью будущего",
    count: 28,
    filterTag: "Перерождение",
    covers: [
      "https://images.unsplash.com/photo-1544717305-2782549b5136?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1532012164546-f432f2e3edd4?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "chill-life",
    title: "Размеренная жизнь",
    subtitle: "Уютные истории без излишней спешки и бесконечных войн",
    count: 8,
    filterTag: "Повседневность",
    covers: [
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1544717305-2782549b5136?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "apocalypse-nightmare",
    title: "Ужасы и Выживание",
    subtitle: "Апокалипсис, лабиринты страха и цена человечности",
    count: 11,
    filterTag: "Выживание",
    covers: [
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "villainess",
    title: "Злодейки корейских романов",
    subtitle: "Героини, которым суждено было погибнуть — но не в этот раз",
    count: 17,
    filterTag: "Дворянство",
    covers: [
      "https://images.unsplash.com/photo-1544717305-2782549b5136?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1532012164546-f432f2e3edd4?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "tower-climbers",
    title: "Восхождение по башне",
    subtitle: "Опасные испытания, этажи силы и гонка за вершиной",
    count: 13,
    filterTag: "Прокачка",
    covers: [
      "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "regressors",
    title: "Регрессоры",
    subtitle: "Герои, вернувшиеся в прошлое, чтобы всё исправить",
    count: 21,
    filterTag: "Перерождение",
    covers: [
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "hidden-power",
    title: "Скрытая сила",
    subtitle: "Герои, чью истинную мощь недооценивают окружающие",
    count: 16,
    filterTag: "Умный ГГ",
    covers: [
      "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "academy-magic",
    title: "Магические академии",
    subtitle: "Школы волшебства, дуэли заклинаний и студенческие интриги",
    count: 15,
    filterTag: "Академия",
    covers: [
      "https://images.unsplash.com/photo-1532012164546-f432f2e3edd4?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1514894780887-121968d00567?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&auto=format&fit=crop&q=80",
    ],
  },
  {
    id: "guild-masters",
    title: "Гильдии и охотники",
    subtitle: "Врата, подземелья и охота на монстров ради выживания",
    count: 12,
    filterTag: "Гильдии",
    covers: [
      "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=300&auto=format&fit=crop&q=80",
    ],
  },
];
