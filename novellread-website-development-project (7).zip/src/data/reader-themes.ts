export interface ReaderThemeVars {
  background: string;
  surface: string;
  surfaceHover: string;
  surfaceActive: string;
  border: string;
  borderLight: string;
  primary: string;
  primaryHover: string;
  primaryRgb: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
}

export interface ReaderTheme {
  id: string;
  label: string;
  mode: "dark" | "light";
  vars: ReaderThemeVars;
}

// Dark reader themes ("Тёмные"). Each surface tone is kept a step lighter
// than its background so buttons/icons placed on `surface` remain legible
// (this is what fixes the low-contrast OLED buttons issue).
export const darkReaderThemes: ReaderTheme[] = [
  {
    id: "reader-dark",
    label: "Классическая",
    mode: "dark",
    vars: {
      background: "#12151c",
      surface: "#1b1f28",
      surfaceHover: "#232834",
      surfaceActive: "#2b3140",
      border: "#323847",
      borderLight: "rgba(255,255,255,0.09)",
      primary: "#22c55e",
      primaryHover: "#34d873",
      primaryRgb: "34, 197, 94",
      textPrimary: "#eef0f4",
      textSecondary: "#a7adba",
      textMuted: "#767c89",
    },
  },
  {
    id: "reader-oled",
    label: "OLED",
    mode: "dark",
    vars: {
      background: "#000000",
      surface: "#151515",
      surfaceHover: "#1e1e1e",
      surfaceActive: "#282828",
      border: "#333333",
      borderLight: "rgba(255,255,255,0.12)",
      primary: "#8b5cf6",
      primaryHover: "#a279f7",
      primaryRgb: "139, 92, 246",
      textPrimary: "#f5f5f5",
      textSecondary: "#b7b7b7",
      textMuted: "#818181",
    },
  },
  {
    id: "reader-graphite",
    label: "Графит",
    mode: "dark",
    vars: {
      background: "#1e2126",
      surface: "#282c33",
      surfaceHover: "#31363e",
      surfaceActive: "#3b414b",
      border: "#454c57",
      borderLight: "rgba(255,255,255,0.09)",
      primary: "#38bdf8",
      primaryHover: "#5cc9f9",
      primaryRgb: "56, 189, 248",
      textPrimary: "#eceef1",
      textSecondary: "#a7aebb",
      textMuted: "#767e8c",
    },
  },
  {
    id: "reader-coffee",
    label: "Кофе",
    mode: "dark",
    vars: {
      background: "#1e1811",
      surface: "#2a2118",
      surfaceHover: "#342920",
      surfaceActive: "#3f3227",
      border: "#4a3b2c",
      borderLight: "rgba(255,255,255,0.08)",
      primary: "#d97706",
      primaryHover: "#ec8b1c",
      primaryRgb: "217, 119, 6",
      textPrimary: "#f1e7d8",
      textSecondary: "#c1b09a",
      textMuted: "#8c7c68",
    },
  },
  {
    id: "reader-emerald",
    label: "Изумруд",
    mode: "dark",
    vars: {
      background: "#0c1e16",
      surface: "#122d21",
      surfaceHover: "#17392a",
      surfaceActive: "#1d4633",
      border: "#255a41",
      borderLight: "rgba(255,255,255,0.08)",
      primary: "#10b981",
      primaryHover: "#2ecb98",
      primaryRgb: "16, 185, 129",
      textPrimary: "#e8f5ee",
      textSecondary: "#a9c9ba",
      textMuted: "#78988a",
    },
  },
  {
    id: "reader-midnight",
    label: "Полночь",
    mode: "dark",
    vars: {
      background: "#0a0f1f",
      surface: "#111832",
      surfaceHover: "#161f3f",
      surfaceActive: "#1c274d",
      border: "#26315e",
      borderLight: "rgba(255,255,255,0.09)",
      primary: "#6366f1",
      primaryHover: "#7c7ff4",
      primaryRgb: "99, 102, 241",
      textPrimary: "#e8eaf7",
      textSecondary: "#a7acc9",
      textMuted: "#767c9c",
    },
  },
  {
    id: "reader-cherry",
    label: "Вишня",
    mode: "dark",
    vars: {
      background: "#1c0f12",
      surface: "#2a161a",
      surfaceHover: "#351b21",
      surfaceActive: "#432229",
      border: "#522a32",
      borderLight: "rgba(255,255,255,0.08)",
      primary: "#f43f5e",
      primaryHover: "#f65b76",
      primaryRgb: "244, 63, 94",
      textPrimary: "#f6e9eb",
      textSecondary: "#c7a7ac",
      textMuted: "#93777c",
    },
  },
  {
    id: "reader-amethyst",
    label: "Аметист",
    mode: "dark",
    vars: {
      background: "#150f1f",
      surface: "#20192e",
      surfaceHover: "#29213b",
      surfaceActive: "#332a49",
      border: "#3d3358",
      borderLight: "rgba(255,255,255,0.09)",
      primary: "#a855f7",
      primaryHover: "#b975f9",
      primaryRgb: "168, 85, 247",
      textPrimary: "#f0eaf9",
      textSecondary: "#bcaed0",
      textMuted: "#8a7d9d",
    },
  },
];

// Light reader themes ("Светлые"). Surfaces are a step darker than the page
// background so buttons stay visible on white/cream tones too.
export const lightReaderThemes: ReaderTheme[] = [
  {
    id: "reader-light",
    label: "Светлая",
    mode: "light",
    vars: {
      background: "#ffffff",
      surface: "#f1f2f4",
      surfaceHover: "#e7e8eb",
      surfaceActive: "#dcdee2",
      border: "#d7d9dd",
      borderLight: "rgba(20,20,25,0.08)",
      primary: "#16a34a",
      primaryHover: "#12873d",
      primaryRgb: "22, 163, 74",
      textPrimary: "#1c1f24",
      textSecondary: "#565c66",
      textMuted: "#868c96",
    },
  },
  {
    id: "reader-paper",
    label: "Бумага",
    mode: "light",
    vars: {
      background: "#f6ecd9",
      surface: "#efe0bf",
      surfaceHover: "#e8d5ac",
      surfaceActive: "#dfc898",
      border: "#d8bd8b",
      borderLight: "rgba(59,47,34,0.12)",
      primary: "#a15c1f",
      primaryHover: "#8a4d19",
      primaryRgb: "161, 92, 31",
      textPrimary: "#3b2f22",
      textSecondary: "#6b5a45",
      textMuted: "#96866f",
    },
  },
  {
    id: "reader-cool",
    label: "Прохладная",
    mode: "light",
    vars: {
      background: "#eef2f7",
      surface: "#dfe6ef",
      surfaceHover: "#d2dbe8",
      surfaceActive: "#c4cfe0",
      border: "#c1cbdb",
      borderLight: "rgba(20,30,50,0.08)",
      primary: "#2563eb",
      primaryHover: "#1d4fc4",
      primaryRgb: "37, 99, 235",
      textPrimary: "#182233",
      textSecondary: "#4d5b70",
      textMuted: "#7c8899",
    },
  },
  {
    id: "reader-mint",
    label: "Мятная",
    mode: "light",
    vars: {
      background: "#ecfaf2",
      surface: "#d9f2e3",
      surfaceHover: "#c8ecd6",
      surfaceActive: "#b5e4c7",
      border: "#b3ddc4",
      borderLight: "rgba(10,50,30,0.08)",
      primary: "#059669",
      primaryHover: "#047a56",
      primaryRgb: "5, 150, 105",
      textPrimary: "#0f2b1e",
      textSecondary: "#3c5d4d",
      textMuted: "#6f9080",
    },
  },
  {
    id: "reader-blossom",
    label: "Розовая",
    mode: "light",
    vars: {
      background: "#fdf1f5",
      surface: "#f9dfe8",
      surfaceHover: "#f5cedd",
      surfaceActive: "#efbccf",
      border: "#eebdd0",
      borderLight: "rgba(60,10,35,0.08)",
      primary: "#db2777",
      primaryHover: "#bd1f65",
      primaryRgb: "219, 39, 119",
      textPrimary: "#2f1420",
      textSecondary: "#5e3446",
      textMuted: "#8f6779",
    },
  },
  {
    id: "reader-vanilla",
    label: "Ваниль",
    mode: "light",
    vars: {
      background: "#fdf8e8",
      surface: "#f7edc4",
      surfaceHover: "#f2e4ab",
      surfaceActive: "#ecda92",
      border: "#e9d597",
      borderLight: "rgba(55,45,10,0.08)",
      primary: "#b45309",
      primaryHover: "#96460a",
      primaryRgb: "180, 83, 9",
      textPrimary: "#332608",
      textSecondary: "#5f5230",
      textMuted: "#8c8058",
    },
  },
];

export const allReaderThemes: ReaderTheme[] = [
  ...darkReaderThemes,
  ...lightReaderThemes,
];

export function getReaderThemeById(id: string): ReaderTheme {
  return allReaderThemes.find((theme) => theme.id === id) ?? darkReaderThemes[0];
}
