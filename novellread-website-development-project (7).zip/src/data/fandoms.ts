export interface FandomItem {
  id: string;
  name: string;
  count: string;
  chaptersLabel: string;
  image: string;
  accent: string;
}

export const fandomsData: FandomItem[] = [
  {
    id: "harry-potter",
    name: "Гарри Поттер",
    count: "+2.4K",
    chaptersLabel: "2 400 глав",
    image: "https://images.unsplash.com/photo-1532012164546-f432f2e3edd4?w=400&auto=format&fit=crop&q=80",
    accent: "from-amber-600/30 to-amber-900/10",
  },
  {
    id: "naruto",
    name: "Наруто",
    count: "+3.7K",
    chaptersLabel: "3 700 глав",
    image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&auto=format&fit=crop&q=80",
    accent: "from-orange-600/30 to-orange-900/10",
  },
  {
    id: "marvel",
    name: "Marvel Comics",
    count: "+1.8K",
    chaptersLabel: "1 800 глав",
    image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&auto=format&fit=crop&q=80",
    accent: "from-red-600/30 to-red-900/10",
  },
  {
    id: "douluo-dalu",
    name: "Боевой континент",
    count: "+384",
    chaptersLabel: "384 главы",
    image: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=400&auto=format&fit=crop&q=80",
    accent: "from-blue-600/30 to-blue-900/10",
  },
  {
    id: "bleach",
    name: "Блич",
    count: "+334",
    chaptersLabel: "334 главы",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&auto=format&fit=crop&q=80",
    accent: "from-slate-600/30 to-slate-900/10",
  },
  {
    id: "high-school-dxd",
    name: "Демоны старшей школы",
    count: "+320",
    chaptersLabel: "320 глав",
    image: "https://images.unsplash.com/photo-1544717305-2782549b5136?w=400&auto=format&fit=crop&q=80",
    accent: "from-rose-600/30 to-rose-900/10",
  },
  {
    id: "jujutsu-kaisen",
    name: "Магическая битва",
    count: "+177",
    chaptersLabel: "177 глав",
    image: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&auto=format&fit=crop&q=80",
    accent: "from-purple-600/30 to-purple-900/10",
  },
  {
    id: "star-wars",
    name: "Звёздные Войны",
    count: "+159",
    chaptersLabel: "159 глав",
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&auto=format&fit=crop&q=80",
    accent: "from-cyan-600/30 to-cyan-900/10",
  },
  {
    id: "one-piece",
    name: "Ван Пис",
    count: "+912",
    chaptersLabel: "912 глав",
    image: "https://images.unsplash.com/photo-1563089145-599997674d42?w=400&auto=format&fit=crop&q=80",
    accent: "from-blue-600/30 to-sky-900/10",
  },
  {
    id: "pokemon",
    name: "Pokémon",
    count: "+241",
    chaptersLabel: "241 глава",
    image: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&auto=format&fit=crop&q=80",
    accent: "from-yellow-600/30 to-yellow-900/10",
  },
  {
    id: "fairy-tail",
    name: "Хвост Феи",
    count: "+209",
    chaptersLabel: "209 глав",
    image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400&auto=format&fit=crop&q=80",
    accent: "from-pink-600/30 to-pink-900/10",
  },
  {
    id: "game-of-thrones",
    name: "Игра Престолов",
    count: "+188",
    chaptersLabel: "188 глав",
    image: "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=400&auto=format&fit=crop&q=80",
    accent: "from-gray-600/30 to-gray-900/10",
  },
];
